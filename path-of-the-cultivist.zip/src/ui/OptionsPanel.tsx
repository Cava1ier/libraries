



import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { ServiceFactory } from '../core/ServiceFactory';
import { LocalizationService } from '../services/LocalizationService';

interface OptionsPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  pluginManager: PluginManager;
}

export class OptionsPanel extends Component<OptionsPanelProps, {}> {
  prefix = 'options-panel';
  styles = [
      'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
      'justify-content', 'margin-bottom', 'border-bottom', 'width', 'background-color', 'height',
      'overflow-y', 'gap', 'align-items'
  ];
  classnames = ['container', 'option-row', 'option-label', 'button-group', 'lang-button'];
  styleValues = [
    ['flex', 'column', '1rem', this.nl, this.nl, '#ccc', this.nl, this.nl, this.nl, this.nl, this.nl, 'auto', 'auto', '1rem', 'flex-start'], // container
    ['flex', 'row', '0.5rem 0', 'sans-serif', '1rem', this.nl, 'space-between', this.nl, '1px solid rgba(212,175,55,0.1)', '100%', this.nl, this.nl, this.nl, this.nl, 'center'], // option-row
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#d4af37', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // option-label
    ['flex', 'row', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '0.5rem', this.nl], // button-group
    [this.nl, this.nl, '0.5rem 1rem', this.nl, '0.9rem', '#fff', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // lang-button
  ];

  // FIX: Converted to a standard class method.
  private setLanguage = (lang: string) => {
    localStorage.setItem('language', lang);
    window.location.reload();
  }

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render = () => {
    if (!this.props.isVisible) {
      return null;
    }

    const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
    const currentLang = localizationService.language;

    const baseButtonCls = this.cls('lang-button');
    const buttonStyle = (isActive: boolean) => ({
      backgroundColor: isActive ? '#d4af37' : 'rgba(255,255,255,0.1)',
      color: isActive ? '#1a1a2e' : '#fff',
      border: `1px solid ${isActive ? '#a08428' : '#555'}`,
      cursor: 'pointer',
      borderRadius: '5px'
    });

    return React.createElement('div', { className: this.cls('container') },
      React.createElement('h3', { className: this.cls('option-label'), style:{fontSize: '1.2rem'} }, localizationService.get('panel_options_title')),
      React.createElement('div', { className: this.cls('option-row') },
        React.createElement('span', { className: this.cls('option-label') }, localizationService.get('panel_options_language_label')),
        React.createElement('div', { className: this.cls('button-group') },
          React.createElement('button', { 
            className: baseButtonCls, 
            style: buttonStyle(currentLang === 'English'), 
            onClick: () => this.setLanguage('English') 
          }, 'English'),
          React.createElement('button', { 
            className: baseButtonCls, 
            style: buttonStyle(currentLang === 'Spanish'), 
            onClick: () => this.setLanguage('Spanish') 
          }, 'Español')
        )
      )
    );
  }
}