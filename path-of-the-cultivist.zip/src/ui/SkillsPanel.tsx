





import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
// FIX: Updated to use SkillService instead of the deprecated dSkillSystem to resolve type incompatibility.
import { SkillService } from '../services/SkillService';
import { GameDatabase } from '../systems/database/Database';
import { SkillType } from '../types/AdventureTypes';

interface SkillsPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  skillSystem: SkillService;
  database: GameDatabase;
}

export class SkillsPanel extends Component<SkillsPanelProps, {}> {
  prefix = 'skills-panel';
  styles = [
      'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
      'justify-content', 'margin-bottom', 'border-bottom', 'width', 'background-color', 'height',
      'overflow-y'
  ];
  classnames = ['container', 'skill-item', 'skill-name', 'skill-level', 'xp-bar-container', 'xp-bar-fill'];
  styleValues = [
    ['flex', 'column', '1rem', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '150px', 'auto'], // container
    ['flex', 'row', '0.5rem 0', 'sans-serif', '0.9rem', '#ccc', 'space-between', '0.5rem', '1px solid rgba(212,175,55,0.1)', this.nl, this.nl, this.nl, this.nl], // skill-item
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#fff', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // skill-name
    [this.nl, this.nl, this.nl, this.nl, '1rem', '#d4af37', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl],  // skill-level
    [this.nl, this.nl, '0', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '100%', 'rgba(212,175,55,0.1)', '4px', this.nl], // xp-bar-container
    [this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '#d4af37', '100%', this.nl],  // xp-bar-fill
  ];

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    
    const { skillSystem, database } = this.props;
    const skillRecords = database.getTable('tblSkillTypes').findAll();

    return React.createElement('div', { className: this.cls('container') },
        ...skillRecords.map(record => {
            const skillId = Number(record.id) as SkillType;
            const level = skillSystem.getSkillLevel(skillId);
            const xp = skillSystem.getSkillExperience(skillId);
            const xpPercent = (xp.current / xp.required) * 100;

            return React.createElement('div', { key: record.id, className: this.cls('skill-item') },
                React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', width: '100%' } },
                    React.createElement('span', { className: this.cls('skill-name') }, record.name),
                    React.createElement('span', { className: this.cls('skill-level') }, `Lvl ${level}`)
                ),
                React.createElement('div', { className: this.cls('xp-bar-container') },
                    React.createElement('div', { 
                        className: this.cls('xp-bar-fill'),
                        style: { width: `${xpPercent}%` }
                    })
                )
            );
        })
    );
  }
}