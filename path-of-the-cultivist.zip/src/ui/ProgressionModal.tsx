



import React from 'react';
import { Component } from '../core/Component';
import { Character } from '../data/dCharacter';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

interface ProgressionModalProps {
  character: Character;
  onSpendPoint: (stat: string) => void;
  onClose: () => void;
}

export class ProgressionModal extends Component<ProgressionModalProps, {}> {
  prefix = 'progression-modal';
  styles = [
    'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
    'justify-content', 'margin-bottom', 'border-bottom', 'font-style', 'margin-top',
    'background', 'border-radius', 'border', 'align-items', 'width', 'gap',
    'cursor', 'transition', 'font-weight'
  ];
  classnames = ['title', 'points-display', 'stat-row', 'stat-name', 'stat-value', 'spend-button'];
  styleValues = [
    [this.nl, this.nl, this.nl, 'serif', '1.8rem', '#d4af37', this.nl, '1rem', '1px solid rgba(212,175,55,0.2)', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // title
    [this.nl, this.nl, '0 1rem 1rem 1rem', this.nl, '1.2rem', '#fff', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '100%', this.nl, this.nl, this.nl, this.nl], // points-display
    ['flex', 'row', '0.5rem 1rem', 'sans-serif', '1rem', '#ccc', 'space-between', '0.5rem', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, 'center', '100%', '0.5rem', this.nl, this.nl, this.nl], // stat-row
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#fff', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // stat-name
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#d4af37', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, 'bold'], // stat-value
    ['flex', this.nl, '0.1rem 0.5rem', this.nl, '1rem', '#1a1a2e', 'center', this.nl, this.nl, this.nl, this.nl, '#d4af37', '50%', '1px solid #a08428', 'center', 'auto', this.nl, 'pointer', 'background-color 0.2s', 'bold'], // spend-button
  ];

  // FIX: Converted to a standard class method as it's a render helper.
  renderStat = (label: string, value: number, statKey: string) => {
    const { onSpendPoint, character } = this.props;
    return React.createElement('div', { key: statKey, className: this.cls('stat-row') },
      React.createElement('span', { className: this.cls('stat-name') }, label),
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '0.5rem' }},
        React.createElement('span', { className: this.cls('stat-value') }, value),
        React.createElement('button', {
          className: this.cls('spend-button'),
          onClick: () => onSpendPoint(statKey),
          disabled: character.attribute_points === 0,
          style: { opacity: character.attribute_points > 0 ? 1 : 0.5 }
        }, '+')
      )
    );
  }

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render = () => {
    const { character, onClose } = this.props;
    const modalCls = (clsName: string) => AppComponentLoader.styleRegistry.cls('modal', clsName);

    const statsToUpgrade = [
      { label: 'Body Tempering', key: 'body_tempering', value: character.body_tempering },
      { label: 'Soul Strength', key: 'soul_strength', value: character.soul_strength },
      { label: 'Dao Comprehension', key: 'dao_comprehension', value: character.dao_comprehension },
      { label: 'Mental Fortitude', key: 'mental_fortitude', value: character.data.mental_fortitude },
      { label: 'Physical Resilience', key: 'physical_resilience', value: character.data.physical_resilience },
    ];

    return React.createElement('div', { className: modalCls('overlay') },
      React.createElement('div', { className: modalCls('panel-base'), style: { maxWidth: '400px' } },
        React.createElement('h2', { className: this.cls('title') }, 'Cultivation Breakthrough'),
        React.createElement('p', { className: this.cls('points-display') }, `Attribute Points: ${character.attribute_points}`),
        ...statsToUpgrade.map(s => this.renderStat(s.label, s.value, s.key)),
        React.createElement('button', { 
            className: modalCls('button'), 
            style: { marginTop: '1.5rem' },
            onClick: onClose 
        }, 'Done')
      )
    );
  }
}