





import React from 'react';
import { Component } from '../core/Component';
import { TabSpec } from '../data/dTabData';

interface TabBaseProps {
  spec: TabSpec;
  isActive: boolean;
  onClick: (panelId: string) => void;
}

export class TabBase extends Component<TabBaseProps, {}> {
  prefix = 'tab-base';
  styles = [
      'padding', 'font-size', 'font-weight', 'color', 'background-color', 
      'border', 'border-radius', 'cursor', 'transition', 'display', 'align-items', 'gap'
    ];
  classnames = ['tab', 'tab-active'];
  styleValues = [
    [
        '0.5rem 1rem', '0.9rem', 'bold', '#888', 'rgba(0,0,0,0.2)', 
        '1px solid transparent', '5px 5px 0 0', 'pointer', 'background-color 0.3s, color 0.3s',
        'flex', 'center', '0.5rem'
    ], // tab
    [
        this.nl, this.nl, this.nl, '#d4af37', 'rgba(0,0,0,0.4)', 
        '1px solid rgba(212,175,55,0.3)', this.nl, this.nl, this.nl,
        this.nl, this.nl, this.nl
    ]  // tab-active
  ];

  // FIX: Kept as an arrow function as it is passed directly to onClick, ensuring 'this' is correctly bound.
  private handleClick = () => {
    this.props.onClick(this.props.spec.panelId);
  };

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    const { spec, isActive } = this.props;
    const containerClass = this.cls('tab') + (isActive ? ` ${this.cls('tab-active')}` : '');
    
    return React.createElement('div', { className: containerClass, onClick: this.handleClick },
      React.createElement('span', { 'aria-hidden': 'true' }, spec.icon),
      spec.label
    );
  }
}