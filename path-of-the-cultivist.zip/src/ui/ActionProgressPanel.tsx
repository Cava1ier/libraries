



import React from 'react';
import { Component } from '../core/Component';

interface ActionProgressPanelProps {
  actionProgress: {
    startTime: number;
    duration: number;
    actionId: string;
  };
}

interface ActionProgressPanelState {
  progress: number;
}

export class ActionProgressPanel extends Component<ActionProgressPanelProps, ActionProgressPanelState> {
  private animationFrameId: number = 0;

  prefix = 'action-progress';
  styles = [
    'position', 'bottom', 'left', 'width', 'padding', 'background-color', 'display', 'flex-direction',
    'align-items', 'color', 'font-size', 'height', 'border-radius', 'border', 'transition', 'text-shadow', 'z-index'
  ];
  classnames = ['container', 'label', 'progress-bar-container', 'progress-bar-fill'];
  styleValues = [
    ['fixed', '2rem', '50%', '300px', '1rem', 'rgba(0,0,0,0.7)', 'flex', 'column', 'center', '#fff', '1rem', this.nl, '8px', '1px solid rgba(212,175,55,0.3)', 'transform 0.3s ease', '1px 1px 2px #000', '20'], // container
    [this.nl, this.nl, this.nl, this.nl, '0 0 0.5rem 0', this.nl, this.nl, this.nl, this.nl, '#d4af37', '0.9rem', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // label
    [this.nl, this.nl, this.nl, '100%', this.nl, 'rgba(212,175,55,0.1)', this.nl, this.nl, this.nl, this.nl, this.nl, '8px', '4px', '1px solid rgba(212,175,55,0.3)', this.nl, this.nl, this.nl], // progress-bar-container
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#d4af37', this.nl, this.nl, this.nl, this.nl, this.nl, '100%', '4px', this.nl, 'width 0.1s linear', this.nl, this.nl], // progress-bar-fill
  ];

    // FIX: Replaced constructor with a direct state initializer.
    state: ActionProgressPanelState = {
        progress: 0,
    };
  
  // FIX: Converted to a standard class method for lifecycle events.
  componentDidMount() {
    this.startAnimation();
  }
  
  // FIX: Converted to a standard class method for lifecycle events.
  componentWillUnmount() {
    this.stopAnimation();
  }
  
  // FIX: Kept as an arrow function as it's used as a callback for requestAnimationFrame.
  startAnimation = () => {
    const loop = () => {
      const { startTime, duration } = this.props.actionProgress;
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / duration) * 100);
      this.setState({ progress });
      this.animationFrameId = requestAnimationFrame(loop);
    };
    this.animationFrameId = requestAnimationFrame(loop);
  };
  
  // FIX: Kept as an arrow function to ensure correct 'this' context when called.
  stopAnimation = () => {
    cancelAnimationFrame(this.animationFrameId);
  };

  // FIX: Converted to a standard class method for lifecycle events.
  render = () => {
    const { actionId } = this.props.actionProgress;
    const labelText = `${actionId.charAt(0).toUpperCase() + actionId.slice(1)}...`;

    return React.createElement('div', { className: this.cls('container'), style: { transform: 'translateX(-50%)' } },
      React.createElement('label', { className: this.cls('label') }, labelText),
      React.createElement('div', { className: this.cls('progress-bar-container') },
        React.createElement('div', {
          className: this.cls('progress-bar-fill'),
          style: { width: `${this.state.progress}%` }
        })
      )
    );
  }
}