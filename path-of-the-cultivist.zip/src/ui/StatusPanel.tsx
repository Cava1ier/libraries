
import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { Character } from '../data/dCharacter';
import { GameWorldMapData } from '../components/GameWorld/dataGameWorldMap';
import { WeatherService } from '../services/WeatherService';
import { GameCoordinatorService } from '../services/GameCoordinatorService';
import { TileConfigRegistry } from '../systems/tiles/TileConfigRegistry';
import { GameDatabase } from '../systems/database/Database';
import { SkillType } from '../types/AdventureTypes';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface StatusPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  character: Character;
  mapData: GameWorldMapData;
  playerState: string;
  pluginManager: PluginManager;
  weatherSystem: WeatherService;
  gameCoordinator: GameCoordinatorService;
  database: GameDatabase;
}

export class StatusPanel extends Component<StatusPanelProps, {}> {
  prefix = 'status-panel';
  styles = ['display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 'justify-content', 'margin-bottom', 'border-bottom', 'text-transform', 'text-align', 'font-style', 'width', 'background-color', 'height', 'border-radius', 'position', 'animation', 'cursor', 'border', 'margin-top'];
  classnames = ['container', 'stat-item', 'stat-label', 'stat-value', 'status-text', 'xp-bar-container', 'xp-bar-fill', 'level-up-button', 'inspected-container', 'inspected-title', 'inspected-text'];
  styleValues = [
    ['flex', 'column', '1rem', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // container
    ['flex', 'row', '0.2rem 0', 'sans-serif', '0.9rem', '#ccc', 'space-between', '0.2rem', '1px solid rgba(212,175,55,0.1)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // stat-item
    [nl, nl, nl, nl, nl, '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // stat-label
    [nl, nl, nl, nl, nl, '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],  // stat-value
    [nl, nl, '0.2rem 0', nl, '1rem', '#40E0D0', 'center', '0.5rem', '1px solid rgba(64, 224, 208, 0.2)', 'capitalize', 'center', 'italic', nl, nl, nl, nl, nl, nl, nl, nl, nl], // status-text
    [nl, nl, '0', nl, nl, nl, nl, nl, '1px solid rgba(212,175,55,0.1)', nl, nl, nl, '100%', 'rgba(0,0,0,0.3)', '4px', '4px', 'relative', nl, nl, nl, nl], // xp-bar-container
    [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '100%', '#d4af37', '100%', '4px', nl, nl, nl, nl, nl], // xp-bar-fill
    ['block', nl, '0.8rem 1rem', 'sans-serif', '1rem', '#1a1a2e', nl, '1rem', 'none', 'capitalize', 'center', nl, '100%', '#d4af37', nl, '5px', nl, 'pulse 2s infinite', 'pointer', '1px solid #d4af37', nl], // level-up-button
    [nl, 'column', '0.5rem 1rem', nl, nl, '#eee', nl, nl, '1px solid rgba(212,175,55,0.2)', nl, 'center', nl, '100%', 'rgba(0,0,0,0.3)', nl, '8px', nl, nl, nl, nl, '1rem'], // inspected-container
    [nl, nl, '0 0 0.5rem 0', 'serif', '1.1rem', '#d4af37', nl, nl, '1px solid rgba(212,175,55,0.1)', 'capitalize', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.5rem'], // inspected-title
    ['flex', 'row', '0.2rem 0', nl, '0.9rem', '#ccc', 'space-between', nl, nl, nl, 'left', nl, '100%', nl, nl, nl, nl, nl, nl, nl, nl], // inspected-text
  ];

  private renderInspectedTileInfo() {
    const { mapData, database } = this.props;
    const { inspectedTile } = mapData;

    if (!inspectedTile) return null;

    const config = TileConfigRegistry.get(inspectedTile.type);
    const requirements = [];

    if (config?.properties?.interaction?.type === 'skill_check_gather') {
        const interaction = config.properties.interaction;
        const skillRecord = database.getTable('tblSkillTypes').find(interaction.skill as SkillType);
        const skillName = skillRecord ? skillRecord.name : 'Unknown Skill';
        requirements.push(`Requires: ${skillName} (DC ${interaction.difficulty})`);
    }

    return React.createElement('div', { className: this.cls('inspected-container') },
      React.createElement('h4', { className: this.cls('inspected-title') }, inspectedTile.type.replace(/_/g, ' ')),
      React.createElement('div', { className: this.cls('inspected-text') }, `Biome: ${inspectedTile.biome}`),
      React.createElement('div', { className: this.cls('inspected-text') }, `Coords: (${inspectedTile.x}, ${inspectedTile.y}, ${inspectedTile.z})`),
      ...requirements.map((req, i) => React.createElement('div', { key: i, className: this.cls('inspected-text'), style: { color: '#FFD700' } }, req))
    );
  }

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    
    const { character, mapData, playerState, weatherSystem, gameCoordinator } = this.props;

    if (mapData.mode === 'look') {
        return React.createElement('div', { className: this.cls('container') }, this.renderInspectedTileInfo());
    }

    const xpForNextLevel = character.getExperienceForNextLevel();
    const xpPercent = xpForNextLevel > 0 ? (character.experience / xpForNextLevel) * 100 : 0;
    
    const stats = [
        { label: 'Time', value: weatherSystem.getFormattedTime() },
        { label: 'Weather', value: weatherSystem.getFormattedWeather() },
        { label: 'Name', value: character.name },
        { label: 'Realm', value: character.realm },
        { label: 'Position', value: `(${character.x}, ${character.y}, ${character.z})`},
        { label: 'View Z-Level', value: mapData.viewZ },
        { label: 'Qi Points', value: `${character.qi_points}/1000` },
        { label: 'Attribute Points', value: character.attribute_points },
    ];

    const playerStatus = playerState !== 'idle' 
        ? React.createElement('div', {className: this.cls('stat-item')}, 
            React.createElement('span', {
                className: this.cls('status-text'), 
                style: {width: '100%'}
            }, `${playerState}...`)
          ) 
        : null;
        
    const levelUpButton = character.attribute_points > 0
        ? React.createElement('button', {
            className: this.cls('level-up-button'),
            onClick: () => gameCoordinator.eventService.addEvent('ui', 'open_progression_modal')
        }, `Distribute Points (${character.attribute_points})`)
        : null;

    return React.createElement('div', { className: this.cls('container') },
        playerStatus,
        levelUpButton,
        ...stats.map(stat => 
            React.createElement('div', { key: stat.label, className: this.cls('stat-item') },
                React.createElement('span', { className: this.cls('stat-label') }, stat.label),
                React.createElement('span', { className: this.cls('stat-value') }, stat.value)
            )
        ),
        React.createElement('div', { key: 'level', className: this.cls('stat-item') },
            React.createElement('span', { className: this.cls('stat-label') }, `Cultivation Lvl`),
            React.createElement('span', { className: this.cls('stat-value') }, character.cultivation_level)
        ),
        React.createElement('div', { key: 'xp-bar', className: this.cls('xp-bar-container') },
            React.createElement('div', { className: this.cls('xp-bar-fill'), style: { width: `${xpPercent}%` } })
        )
    );
  }
}