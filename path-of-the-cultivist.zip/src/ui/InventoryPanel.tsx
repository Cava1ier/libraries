





import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { ItemData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';

interface InventoryPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  items: ItemData[];
  database: GameDatabase;
  pluginManager: PluginManager;
}

export class InventoryPanel extends Component<InventoryPanelProps, {}> {
  prefix = 'inventory-panel';
  styles = [
    'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
    'justify-content', 'margin-bottom', 'border-bottom', 'height', 'overflow-y'
  ];
  classnames = ['container', 'item', 'item-name', 'item-quantity'];
  styleValues = [
    ['flex', 'column', '1rem', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '150px', 'auto'], // container
    ['flex', 'row', '0.2rem 0', 'sans-serif', '0.9rem', '#ccc', 'space-between', '0.2rem', '1px solid rgba(212,175,55,0.1)', this.nl, this.nl], // item
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#fff', this.nl, this.nl, this.nl, this.nl, this.nl], // item-name
    [this.nl, this.nl, this.nl, this.nl, this.nl, '#888', this.nl, this.nl, this.nl, this.nl, this.nl]  // item-quantity
  ];

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    
    const { items, database } = this.props;

    if (items.length === 0) {
        return React.createElement('div', { className: this.cls('container'), style: {height: 'auto'} },
            React.createElement('p', { style: { color: '#888', padding: '1rem' } }, 'Your satchel is empty.')
        );
    }

    return React.createElement('div', { className: this.cls('container') },
        ...items.map(item => {
            const itemRecord = database.getTable('tblItemTypes').find(item.typeId);
            const qualityRecord = database.getTable('tblItemQualities').find(item.qualityId);
            const itemName = itemRecord ? itemRecord.name : 'Unknown Item';
            const qualityName = qualityRecord ? qualityRecord.name : 'Unknown Quality';

            return React.createElement('div', { key: item.id, className: this.cls('item') },
                React.createElement('span', { className: this.cls('item-name') }, `${itemName} (${qualityName})`),
                React.createElement('span', { className: this.cls('item-quantity') }, `x${item.quantity}`)
            )
        })
    );
  }
}