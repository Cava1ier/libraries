



import React from 'react';
import { Component } from '../core/Component';
import { Character } from '../data/dCharacter';
import { WorldService } from '../services/WorldService';

interface MiniMapProps {
    character: Character;
    worldService: WorldService;
    discoveredTiles: Set<string>;
}

const MAP_SIZE_PX = 150;
const TILE_RENDER_SIZE = 3; // How many pixels per tile on the mini-map
const VIEW_RADIUS_TILES = Math.floor((MAP_SIZE_PX / TILE_RENDER_SIZE) / 2);

const biomeColors: { [key: string]: string } = {
    'Ocean': '#4682B4',
    'Sunken Spirit Lake': '#4682B4',
    'Plains': '#9ACD32',
    'Celestial Plains': '#9ACD32',
    'Forest': '#228B22',
    'Whispering Bamboo Forest': '#228B22',
    'Mountains': '#A9A9A9',
    'Jade Pillar Mountains': '#A9A9A9',
    'RockyPeak': '#696969',
    'SnowyPeak': '#FFFAFA',
    'Frozen Summit': '#FFFAFA',
    'Desert': '#F0E68C',
    'Scorched Sands': '#F0E68C',
    'Swamp': '#556B2F',
    'Misty Swamp': '#556B2F',
    'Hills': '#CD853F',
    'default': '#333333'
};


export class MiniMap extends Component<MiniMapProps, {}> {
    prefix = 'mini-map';
    private canvasRef: React.RefObject<HTMLCanvasElement> = React.createRef();

    // FIX: Converted to a standard class method for lifecycle events.
    componentDidMount = () => {
        this.drawMap();
    }

    // FIX: Converted to a standard class method for lifecycle events.
    componentDidUpdate = () => {
        this.drawMap();
    }
    
    // FIX: Converted to a standard class method.
    drawMap = () => {
        const canvas = this.canvasRef.current;
        const { character, worldService, discoveredTiles } = this.props;
        if (!canvas || !character) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Set canvas size
        canvas.width = MAP_SIZE_PX;
        canvas.height = MAP_SIZE_PX;

        // Clear canvas with a dark background
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, MAP_SIZE_PX, MAP_SIZE_PX);

        const playerX = character.x;
        const playerY = character.y;
        
        // Loop through the tiles that will be visible on the mini-map
        for (let dy = -VIEW_RADIUS_TILES; dy <= VIEW_RADIUS_TILES; dy++) {
            for (let dx = -VIEW_RADIUS_TILES; dx <= VIEW_RADIUS_TILES; dx++) {
                const worldX = playerX + dx;
                const worldY = playerY + dy;
                
                // Check if this tile has been discovered
                if (discoveredTiles.has(`${worldX},${worldY}`)) {
                    const tile = worldService.getVisibleTile(worldX, worldY, 5); // Assuming surface is around z=5
                    if (tile) {
                        const color = biomeColors[tile.biome] || biomeColors['default'];
                        ctx.fillStyle = color;
                        
                        const canvasX = (dx + VIEW_RADIUS_TILES) * TILE_RENDER_SIZE;
                        const canvasY = (dy + VIEW_RADIUS_TILES) * TILE_RENDER_SIZE;
                        
                        ctx.fillRect(canvasX, canvasY, TILE_RENDER_SIZE, TILE_RENDER_SIZE);
                    }
                }
            }
        }
        
        // Draw player marker in the center
        ctx.fillStyle = '#d4af37'; // Golden yellow
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 1;
        const centerX = VIEW_RADIUS_TILES * TILE_RENDER_SIZE;
        const centerY = VIEW_RADIUS_TILES * TILE_RENDER_SIZE;
        ctx.beginPath();
        ctx.arc(centerX + TILE_RENDER_SIZE / 2, centerY + TILE_RENDER_SIZE / 2, TILE_RENDER_SIZE, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
    }

    render = () => {
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('canvas', { ref: this.canvasRef })
        );
    }
}