





import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { GameCoordinatorService } from '../services/GameCoordinatorService';

interface ActionsPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  playerState: string;
  gameWorld: GameCoordinatorService;
  pluginManager: PluginManager;
}

export class ActionsPanel extends Component<ActionsPanelProps, {}> {
  prefix = 'actions-panel';
  styles = [
      'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 'text-align', 'margin-top',
      'background-color', 'border', 'border-radius', 'cursor', 'opacity', 'width', 'margin-bottom', 'transition'
  ];
  classnames = ['container', 'button', 'controls-list', 'control-item'];
  styleValues = [
    ['flex', 'column', '1rem', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // container
    ['block', this.nl, '0.8rem 1rem', 'sans-serif', '1rem', '#d4af37', 'center', '0.5rem', 'rgba(212,175,55,0.1)', '1px solid #d4af37', '5px', 'pointer', '1', '100%', this.nl, 'all 0.2s ease'], // button
    [this.nl, this.nl, '0.5rem', 'monospace', '0.8rem', '#888', 'center', '1rem', this.nl, this.nl, this.nl, this.nl, this.nl, '100%', this.nl, this.nl], // controls-list
    [this.nl, this.nl, '0.2rem', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // control-item
  ];

  // FIX: Converted to a standard class method.
  private createActionButton(label: string, action: string, isBusy: boolean) {
      const { gameWorld } = this.props;
      return React.createElement('button', { 
          key: action,
          className: this.cls('button'), 
          onClick: () => gameWorld.performAction(action),
          disabled: isBusy,
          style: { opacity: isBusy ? 0.5 : 1, cursor: isBusy ? 'not-allowed' : 'pointer' }
      }, label);
  }
  
  // FIX: Converted to a standard class method.
  private createInteractButton(isBusy: boolean) {
      const { gameWorld } = this.props;
      const isAvailable = gameWorld.interactionController.isInteractionAvailable();
      return React.createElement('button', {
          key: 'interact',
          className: this.cls('button'),
          onClick: () => gameWorld.interactionController.interactWithAdjacent(),
          disabled: isBusy || !isAvailable,
          style: {
              opacity: isBusy || !isAvailable ? 0.5 : 1,
              cursor: isBusy || !isAvailable ? 'not-allowed' : 'pointer',
              animation: isAvailable && !isBusy ? 'pulse 2.5s infinite' : 'none',
          }
      }, 'Interact');
  }

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    const { playerState, pluginManager, gameWorld } = this.props;
    const isBusy = playerState !== 'idle';
    
    const controls = [
        'Arrows/WASD: Move', 'Q/E/Z/C: Move Diagonally', 'L: Toggle Look Mode',
        'Shift + </>: Change Z-Level', 'ESC: Cancel Action',
    ];
    
    const mainActions = [
        { label: 'Meditate (Short Rest)', action: 'meditate'},
        { label: 'Cultivate Qi (Long Rest)', action: 'cultivate'},
        { label: 'Auto-Explore Area', action: 'explore'},
        { label: 'Craft Items', action: 'craft' },
        { label: 'Save Game', action: 'save'},
    ];

    return React.createElement('div', { className: this.cls('container'), style: {height: '100%'} },
      isBusy ? React.createElement('div', {className: this.cls('button')}, `... ${playerState} ...`) : null,
      this.createInteractButton(isBusy),
      ...mainActions.map(a => this.createActionButton(a.label, a.action, isBusy)),
      
      React.createElement('div', { className: this.cls('controls-list') },
        ...controls.map(c => React.createElement('div', { key: c, className: this.cls('control-item') }, c))
      ),

      React.createElement('button', {
          className: this.cls('button'),
          style: { marginTop: 'auto', backgroundColor: 'rgba(128,128,128,0.1)', borderColor: '#888', color: '#888'},
          onClick: () => pluginManager.loadPage('menu')
      }, 'Return to Menu')
    );
  }
}