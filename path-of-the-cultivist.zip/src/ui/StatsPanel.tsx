





import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';

interface StatsPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
}

export class StatsPanel extends Component<StatsPanelProps, {}> {
  prefix = 'stats-panel';
  styles = ['display', 'flex-direction', 'color', 'font-size', 'padding', 'border-bottom'];
  classnames = ['container', 'title', 'body'];
  styleValues = [
    ['flex', 'column', '#fff', '1rem', '1rem', '1px solid rgba(212,175,55,0.3)'], // container
    [this.nl, this.nl, '#d4af37', '1.2rem', '0 0 0.5rem 0', this.nl],          // title
    [this.nl, this.nl, '#ccc', '0.9rem', this.nl, this.nl]                      // body
  ];

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    if (!this.props.isVisible) {
      return null;
    }
    return React.createElement('div', { className: this.cls('container') },
      React.createElement('h2', { className: this.cls('title') }, this.props.spec.title),
      React.createElement('p', { className: this.cls('body') }, 'Statistics will be displayed here.')
    );
  }
}