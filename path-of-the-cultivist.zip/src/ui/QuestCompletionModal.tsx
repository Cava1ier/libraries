





import React from 'react';
import { Component } from '../core/Component';
import { QuestData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

interface QuestCompletionModalProps {
  quest: QuestData;
  database: GameDatabase;
  