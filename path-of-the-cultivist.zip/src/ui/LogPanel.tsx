





import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';

interface LogPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  worldEvents: any[];
  pluginManager: PluginManager;
}

interface LogPanelState {
  scrollTop: number;
}

const ITEM_HEIGHT = 38; // Estimated height in pixels for one event item
const PANEL_HEIGHT = 400; // The visible height of the scrollable area

export class LogPanel extends Component<LogPanelProps, LogPanelState> {
  prefix = 'log-panel';
  styles = [
    'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
    'margin-bottom', 'border-bottom', 'height', 'overflow-y', 'position', 'width', 'left', 'top'
  ];
  classnames = ['container', 'event-item', 'event-desc', 'event-consequence', 'sizer', 'item-wrapper'];
  styleValues = [
    ['flex', 'column', '0', 'sans-serif', this.nl, this.nl, this.nl, this.nl, `${PANEL_HEIGHT}px`, 'auto', 'relative', this.nl, this.nl, this.nl], // container
    ['flex', 'column', '0.5rem 1rem', this.nl, '0.9rem', '#ccc', '0.5rem', '1px solid rgba(212,175,55,0.1)', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // event-item
    [this.nl, this.nl, '0 0 0.2rem 0', this.nl, this.nl, '#fff', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl], // event-desc
    [this.nl, this.nl, this.nl, this.nl, '0.8rem', '#888', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl],  // event-consequence
    [this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, 'relative', '100%', this.nl, this.nl], // sizer
    [this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, 'absolute', '100%', '0', '0'], // item-wrapper
  ];

    // FIX: Replaced constructor with a direct state initializer.
    state: LogPanelState = {
        scrollTop: 0
    };

  // FIX: Kept as an arrow function as it's passed directly to onScroll.
  handleScroll = (event: React.UIEvent<HTMLDivElement>) => {
    this.setState({ scrollTop: event.currentTarget.scrollTop });
  }

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    
    const { worldEvents } = this.props;
    const { scrollTop } = this.state;

    const totalHeight = worldEvents.length * ITEM_HEIGHT;
    const startIndex = Math.floor(scrollTop / ITEM_HEIGHT);
    const visibleItemCount = Math.ceil(PANEL_HEIGHT / ITEM_HEIGHT) + 2; // +2 for buffer
    const endIndex = Math.min(worldEvents.length, startIndex + visibleItemCount);
    
    const visibleItems = worldEvents.slice(startIndex, endIndex);

    const itemNodes = visibleItems.map((event, index) => {
        const itemIndex = startIndex + index;
        return React.createElement('div', {
            key: itemIndex,
            className: this.cls('item-wrapper'),
            style: { top: `${itemIndex * ITEM_HEIGHT}px` }
        },
            React.createElement('div', { className: this.cls('event-item') },
                React.createElement('p', { className: this.cls('event-desc') }, `[${event.timestamp}] ${event.description}`),
                React.createElement('small', { className: this.cls('event-consequence') }, event.consequences)
            )
        );
    });

    return React.createElement('div', { 
        className: this.cls('container'),
        onScroll: this.handleScroll
    },
        React.createElement('div', { 
            className: this.cls('sizer'),
            style: { height: `${totalHeight}px` }
        }, ...itemNodes)
    );
  }
}