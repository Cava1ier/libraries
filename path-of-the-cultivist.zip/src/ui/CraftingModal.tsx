



import React from 'react';
import { Component } from '../core/Component';
import { InventoryService } from '../services/InventoryService';
import { DatabaseService } from '../services/DatabaseService';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

interface CraftingModalProps {
  recipes: any[];
  inventory: InventoryService;
  database: DatabaseService;
  onCraft: (recipeId: number) => void;
  onClose: () => void;
}

export class CraftingModal extends Component<CraftingModalProps, {}> {
  prefix = 'crafting-modal';
  styles = [
    'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
    'justify-content', 'margin-bottom', 'border-bottom', 'font-style', 'margin-top',
    'background', 'border-radius', 'border', 'align-items', 'width', 'gap',
    'cursor', 'transition', 'font-weight', 'opacity', 'list-style'
  ];
  classnames = ['title', 'recipe-list', 'recipe-item', 'recipe-name', 'requirements-list', 'requirement-item', 'craft-button'];
  styleValues = [
    [this.nl, this.nl, this.nl, 'serif', '1.8rem', '#d4af37', this.nl, '1rem', '1px solid rgba(212,175,55,0.2)', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl],
    ['flex', 'column', '1rem 0', this.nl, this.nl, '#fff', this.nl, '1rem', this.nl, this.nl, '1rem', 'rgba(0,0,0,0.2)', '8px', this.nl, 'flex-start', '100%', '1rem', this.nl, this.nl, this.nl, this.nl, 'none'],
    ['flex', 'column', '1rem', this.nl, '1rem', '#ccc', this.nl, '1rem', '1px solid rgba(212,175,55,0.1)', this.nl, this.nl, 'rgba(255,255,255,0.05)', '5px', this.nl, 'flex-start', '100%', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl],
    [this.nl, this.nl, '0 0 0.5rem 0', 'serif', '1.2rem', '#d4af37', this.nl, this.nl, '1px solid rgba(212,175,55,0.1)', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, '100%', this.nl, this.nl, this.nl, 'bold', this.nl, this.nl],
    [this.nl, 'column', '0.5rem 0 0.5rem 1rem', this.nl, '0.9rem', '#ddd', this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, 'flex-start', this.nl, '0.2rem', this.nl, this.nl, this.nl, this.nl, 'disc'],
    [this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, this.nl],
    [this.nl, this.nl, '0.5rem 1rem', 'sans-serif', '1rem', '#1a1a2e', this.nl, this.nl, this.nl, this.nl, '0.5rem', '#d4af37', '5px', '1px solid #a08428', 'center', this.nl, this.nl, 'pointer', 'background-color 0.2s', 'bold', '1', this.nl],
  ];

  // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
  render = () => {
    const { recipes, inventory, database, onCraft, onClose } = this.props;
    const modalCls = (clsName: string) => AppComponentLoader.styleRegistry.cls('modal', clsName);
    const allItems = inventory.getItems();

    const checkRequirements = (recipe: any) => {
        for (let i = 1; i <= 2; i++) {
            const reqItemId = recipe[`req_item_id_${i}`];
            const reqQuantity = recipe[`req_quantity_${i}`];
            if (reqItemId) {
                const playerItem = allItems.find(item => item.typeId === reqItemId);
                if (!playerItem || playerItem.quantity < reqQuantity) {
                    return false;
                }
            }
        }
        return true;
    };

    const renderRequirement = (recipe: any, index: number) => {
        const reqItemId = recipe[`req_item_id_${index}`];
        const reqQuantity = recipe[`req_quantity_${index}`];
        if (!reqItemId) return null;

        const itemRecord = database.getTable('tblItemTypes').find(reqItemId);
        if (!itemRecord) return null;

        const playerItem = allItems.find(item => item.typeId === reqItemId);
        const playerQuantity = playerItem ? playerItem.quantity : 0;
        const color = playerQuantity >= reqQuantity ? '#4caf50' : '#f44336';

        return React.createElement('li', { key: index, className: this.cls('requirement-item'), style: { color } },
            `${itemRecord.name}: ${playerQuantity} / ${reqQuantity}`
        );
    };

    return React.createElement('div', { className: modalCls('overlay') },
      React.createElement('div', { className: modalCls('panel-base'), style: { maxWidth: '500px' } },
        React.createElement('h2', { className: this.cls('title') }, 'Ancient Forge'),
        React.createElement('div', { className: this.cls('recipe-list') },
          recipes.length > 0 ? recipes.map(recipe => {
            const canCraft = checkRequirements(recipe);
            const resultItem = database.getTable('tblItemTypes').find(recipe.result_item_id);
            return React.createElement('div', { key: recipe.id, className: this.cls('recipe-item') },
              React.createElement('h3', { className: this.cls('recipe-name') }, `Craft ${resultItem.name}`),
              React.createElement('ul', { className: this.cls('requirements-list') },
                renderRequirement(recipe, 1),
                renderRequirement(recipe, 2)
              ),
              React.createElement('button', {
                  className: this.cls('craft-button'),
                  onClick: () => onCraft(recipe.id),
                  disabled: !canCraft,
                  style: { opacity: canCraft ? 1 : 0.5 }
              }, 'Craft')
            );
          }) : React.createElement('p', {}, 'No recipes available.')
        ),
        React.createElement('button', { 
            className: modalCls('button'), 
            style: { marginTop: '1.5rem' },
            onClick: onClose 
        }, 'Close')
      )
    );
  }
}