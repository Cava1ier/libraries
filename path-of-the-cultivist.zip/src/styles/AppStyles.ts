// src/styles/AppStyles.ts
const nl = null;

const splashScreenStyles = {
    prefix: 'splash',
    styles: ['display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width', 'padding', 'text-align', 'font-family', 'font-size', 'font-weight', 'color', 'background', 'animation', 'text-shadow', 'letter-spacing', 'border', 'border-radius'],
    classnames: ['container', 'title', 'subtitle', 'collaborator-1', 'collaborator-2', 'spinner', 'loading-text'],
    styleValues: [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '1rem', 'center', nl, nl, nl, '#e0e0e0', 'linear-gradient(160deg, #1a1a2e 0%, #2c2c54 100%)', 'fadeIn 1.5s ease-out', nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, 'center', 'serif', '4rem', 'bold', '#d4af37', nl, 'fadeIn 2s ease-out', '0 0 10px #d4af37, 0 0 20px #d4af37', '0.1em', nl, nl],
        [nl, nl, nl, nl, nl, nl, '1rem 0', 'center', 'sans-serif', '1.2rem', 'normal', '#aaa', nl, 'fadeIn 2.5s ease-out', nl, '0.05em', nl, nl],
        [nl, nl, nl, nl, nl, nl, '2rem 0 0.5rem 0', 'center', 'sans-serif', '0.9rem', 'normal', '#888', nl, 'fadeIn 3s ease-out', nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0', 'center', 'sans-serif', '0.9rem', 'normal', '#888', nl, 'fadeIn 3s ease-out', nl, nl, nl, nl],
        [nl, nl, nl, nl, '2rem', nl, nl, nl, nl, nl, nl, nl, nl, 'spin 1.5s linear infinite', nl, nl, '50px solid #333', '50%'],
        [nl, nl, nl, nl, nl, nl, '1rem', 'center', 'sans-serif', '1rem', 'normal', '#d4af37', nl, 'fadeIn 3.5s ease-out', nl, nl, nl, nl]
    ]
};

const mainMenuStyles = {
    prefix: 'main-menu',
    styles: ['display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width', 'padding', 'text-align', 'font-family', 'font-size', 'font-weight', 'color', 'background', 'animation', 'text-shadow', 'letter-spacing', 'border', 'border-radius', 'gap', 'cursor', 'transition', 'opacity'],
    classnames: ['container', 'title-container', 'title', 'subtitle', 'button-container', 'button', 'button-disabled'],
    styleValues: [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '1rem', 'center', nl, nl, nl, '#e0e0e0', 'linear-gradient(160deg, #1a1a2e 0%, #2c2c54 100%)', 'fadeIn 1s ease', nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, 'center', nl, nl, '0 0 3rem 0', 'center', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, 'center', 'serif', '4rem', 'bold', '#d4af37', nl, nl, '0 0 10px #d4af37, 0 0 20px #d4af37', '0.1em', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0.5rem 0 0 0', 'center', 'sans-serif', '1.2rem', 'normal', '#aaa', nl, nl, nl, '0.05em', nl, nl, nl, nl, nl, nl],
        ['flex', 'column', 'center', 'center', nl, '300px', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1rem', nl, nl, nl],
        ['block', nl, nl, nl, nl, nl, '1rem 0', 'center', 'sans-serif', '1.2rem', 'bold', '#d4af37', 'transparent', nl, '0 0 5px rgba(212,175,55,0.5)', nl, '2px solid #d4af37', '8px', nl, 'pointer', 'all 0.3s ease', '1'],
        [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '#888', 'transparent', nl, nl, nl, '2px solid #555', nl, nl, 'not-allowed', nl, '0.5']
    ]
};

const aboutScreenStyles = {
    prefix: 'about',
    styles: ['display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width', 'padding', 'text-align', 'font-family', 'font-size', 'font-weight', 'color', 'background', 'border', 'border-radius', 'list-style', 'max-width', 'margin'],
    classnames: ['container', 'content', 'title', 'text', 'feature-list', 'feature-item', 'button'],
    styleValues: [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '2rem', 'center', nl, nl, nl, '#e0e0e0', 'linear-gradient(160deg, #1a1a2e 0%, #2c2c54 100%)', nl, nl, nl, nl, nl],
        [nl, 'column', nl, 'flex-start', nl, nl, '2rem', 'left', 'sans-serif', '1rem', nl, nl, 'rgba(0,0,0,0.2)', '1px solid #444', '15px', nl, '800px', '0 auto'],
        [nl, nl, nl, nl, nl, nl, '0 0 1.5rem 0', 'center', 'serif', '2.5rem', 'bold', '#d4af37', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0 0 1rem 0', nl, nl, '1.1rem', nl, '#ccc', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0 0 1.5rem 1.5rem', nl, nl, nl, nl, nl, nl, nl, nl, 'disc', nl, nl],
        [nl, nl, nl, nl, nl, nl, '0.5rem 0', nl, nl, nl, nl, '#aaa', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '1rem 0', 'center', 'sans-serif', '1.2rem', 'bold', '#d4af37', 'transparent', '2px solid #d4af37', '8px', nl, '200px', '2rem auto 0 auto']
    ]
};

const oceanQuestionnaireStyles = {
    prefix: 'ocean-q',
    styles: ['display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width', 'padding', 'font-family', 'font-size', 'color', 'background', 'border', 'border-radius', 'text-shadow', 'animation', 'gap', 'text-align', 'cursor', 'transition', 'opacity', 'max-height', 'overflow', 'position'],
    classnames: ['container', 'panel', 'panel-header', 'phase-indicator', 'progress-counter', 'progress-bar-container', 'progress-bar-fill', 'panel-content', 'oracle-thinking-container', 'oracle-spinner', 'question-content', 'question-title', 'question-context', 'choice-container', 'choice-button', 'panel-footer', 'auto-answer-text', 'minigame-container', 'minigame-symbol-display', 'minigame-symbol', 'minigame-message', 'minigame-input-container', 'minigame-input-button'],
    styleValues: [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '1rem', 'sans-serif', nl, '#e0e0e0', 'linear-gradient(160deg, #1a1a2e 0%, #2c2c54 100%)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        ['flex', 'column', nl, nl, 'auto', '95%', nl, nl, nl, nl, 'rgba(0,0,0,0.3)', '1px solid #444', '15px', nl, 'growAndFadeIn 0.8s ease-out', '0.5rem', nl, nl, nl, nl, nl, nl, 'relative'],
        ['flex', 'row', 'space-between', 'center', nl, '100%', '0.5rem 1rem', nl, nl, nl, nl, '0 0 1px 0 rgba(212,175,55,0.3)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, nl, '0.9rem', '#aaa', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, nl, '0.9rem', '#aaa', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        ['block', nl, nl, nl, '4px', '100%', nl, nl, nl, nl, 'rgba(212,175,55,0.1)', '1px solid #555', '3px', nl, nl, nl, nl, nl, nl, nl, nl, 'hidden', nl],
        ['block', nl, nl, nl, '100%', '100%', nl, nl, nl, nl, '#d4af37', nl, nl, nl, nl, nl, nl, nl, 'width 0.5s ease', nl, nl, nl, nl],
        ['flex', 'column', 'center', 'center', nl, nl, '2rem 1rem', nl, nl, nl, nl, nl, nl, nl, 'fadeIn 1s ease-in-out', nl, nl, nl, nl, nl, nl, nl, 'relative'],
        ['flex', 'column', 'center', 'center', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1rem', 'center', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, '40px', '40px', nl, nl, nl, nl, nl, '2px solid #d4af37', '50%', nl, 'spin 1.2s linear infinite', nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, 'column', nl, nl, nl, nl, '1rem', nl, nl, nl, nl, nl, nl, nl, 'fadeIn 0.5s', nl, 'center', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0 0 1rem 0', 'serif', '1.5rem', '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0 0 1.5rem 0', nl, '1.1rem', '#ccc', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        ['flex', 'column', nl, 'center', nl, '100%', nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.5rem', nl, nl, nl, nl, nl, nl, nl],
        ['block', nl, nl, nl, nl, nl, '0.8rem 1rem', 'sans-serif', '1rem', '#d4af37', 'rgba(212,175,55,0.1)', '1px solid #d4af37', '5px', nl, nl, nl, 'center', 'pointer', 'all 0.2s ease', '1', nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '1rem', nl, nl, nl, nl, nl, nl, nl, nl, nl, 'center', nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, nl, '0.9rem', '#888', nl, nl, nl, nl, nl, nl, nl, 'pointer', 'color 0.3s', nl, nl, nl, nl],
        [nl, 'column', 'center', 'center', nl, nl, '1rem', nl, nl, nl, nl, nl, nl, nl, 'fadeIn 0.5s', '1rem', nl, nl, nl, nl, nl, nl, nl],
        ['flex', nl, 'center', 'center', '100px', '100px', nl, nl, nl, nl, 'rgba(0,0,0,0.3)', '1px solid #555', '8px', nl, nl, nl, nl, nl, nl, nl, nl, nl, 'relative'],
        [nl, nl, nl, nl, nl, nl, nl, nl, '2.5rem', '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, 'opacity 0.2s', nl, nl, nl, 'absolute'],
        [nl, nl, nl, nl, nl, nl, '1rem 0 0 0', nl, '1rem', '#aaa', nl, nl, nl, nl, nl, nl, 'center', nl, nl, nl, nl, nl, nl],
        ['flex', 'row', 'center', 'center', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1rem', nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, '50px', '50px', nl, nl, '1.5rem', '#d4af37', 'rgba(212,175,55,0.1)', '1px solid #d4af37', '8px', nl, nl, nl, nl, 'pointer', 'all 0.2s', nl, nl, nl, nl],
    ]
};

const characterCreationStyles = {
    prefix: 'char-create',
    styles: ['display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width', 'padding', 'font-family', 'font-size', 'color', 'background', 'border', 'border-radius', 'gap', 'overflow-y', 'cursor', 'transition', 'max-height', 'opacity', 'margin-top', 'margin-bottom', 'border-top'],
    classnames: ['container', 'panel', 'title', 'stat-web-container', 'button', 'subtitle', 'accordion-container', 'accordion-header', 'accordion-content', 'stat-list-item'],
    styleValues: [
        ['flex', 'row', 'center', 'flex-start', '100vh', '100vw', '2rem', 'sans-serif', nl, '#e0e0e0', 'linear-gradient(160deg, #1a1a2e 0%, #2c2c54 100%)', nl, nl, '2rem', 'auto', nl, nl, nl, nl, nl, nl, nl],
        ['flex', 'column', nl, 'center', '90vh', '45%', '1.5rem', nl, nl, nl, 'rgba(0,0,0,0.3)', '1px solid #444', '15px', nl, 'auto', nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, '0 0 1rem 0', 'serif', '2rem', '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        ['flex', nl, 'center', 'center', nl, '100%', '1rem', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        ['block', nl, nl, nl, nl, nl, '0.8rem 1rem', nl, '1rem', '#d4af37', 'rgba(212,175,55,0.1)', '1px solid #d4af37', '5px', nl, nl, 'pointer', 'all 0.2s ease', nl, nl, '1rem', nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, nl, '1.2rem', '#aaa', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        ['block', nl, nl, nl, nl, '100%', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.5rem', nl],
        ['flex', 'row', 'space-between', 'center', nl, nl, '0.5rem 1rem', nl, '1rem', '#d4af37', 'rgba(212,175,55,0.1)', nl, '5px', nl, nl, 'pointer', 'background-color 0.2s', nl, nl, nl, nl, nl],
        ['block', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, 'rgba(0,0,0,0.2)', nl, '0 0 5px 5px', nl, 'auto', 'pointer', 'max-height 0.35s ease-in-out, padding 0.35s ease-in-out, opacity 0.35s ease-in-out', '1000px', '1', nl, nl, nl],
        ['flex', 'row', 'space-between', nl, nl, nl, '0.3rem 0', nl, nl, '#ccc', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
    ]
};

const statWebStyles = {
    prefix: 'stat-web',
    styles: ['fill', 'stroke', 'stroke-width', 'font-family', 'font-size', 'text-anchor', 'dominant-baseline', 'animation'],
    classnames: ['web-line', 'polygon', 'stat-point', 'label'],
    styleValues: [
        ['none', 'rgba(212,175,55,0.2)', '1', nl, nl, nl, nl, nl],
        ['url(#statGradient)', 'rgba(212,175,55,0.8)', '2', nl, nl, nl, nl, 'growAndFadeIn 1s ease-out'],
        ['#d4af37', '#1a1a2e', '2', nl, nl, nl, nl, nl],
        ['#aaa', nl, '1', 'sans-serif', '0.7rem', 'middle', 'middle', nl],
    ]
};

const statusPanelStyles = {
    prefix: 'status-panel',
    styles: ['display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 'justify-content', 'margin-bottom', 'border-bottom', 'text-transform', 'text-align', 'font-style', 'width', 'background-color', 'height', 'border-radius', 'position', 'animation', 'cursor', 'border', 'margin-top'],
    classnames: ['container', 'stat-item', 'stat-label', 'stat-value', 'status-text', 'xp-bar-container', 'xp-bar-fill', 'level-up-button', 'inspected-container', 'inspected-title', 'inspected-text'],
    styleValues: [
      ['flex', 'column', '1rem', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // container
      ['flex', 'row', '0.2rem 0', 'sans-serif', '0.9rem', '#ccc', 'space-between', '0.2rem', '1px solid rgba(212,175,55,0.1)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // stat-item
      [nl, nl, nl, nl, nl, '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // stat-label
      [nl, nl, nl, nl, nl, '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],  // stat-value
      [nl, nl, '0.2rem 0', nl, '1rem', '#40E0D0', 'center', '0.5rem', '1px solid rgba(64, 224, 208, 0.2)', 'capitalize', 'center', 'italic', nl, nl, nl, nl, nl, nl, nl, nl, nl], // status-text
      [nl, nl, '0', nl, nl, nl, nl, nl, '1px solid rgba(212,175,55,0.1)', nl, nl, nl, '100%', 'rgba(0,0,0,0.3)', '4px', '4px', 'relative', nl, nl, nl, nl], // xp-bar-container
      [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '100%', '#d4af37', '100%', '4px', nl, nl, nl, nl, nl], // xp-bar-fill
      ['block', nl, '0.8rem 1rem', 'sans-serif', '1rem', '#1a1a2e', nl, '1rem', 'none', 'capitalize', 'center', nl, '100%', '#d4af37', nl, '5px', nl, 'pulse 2s infinite', 'pointer', '1px solid #d4af37', nl], // level-up-button
      [nl, 'column', '0.5rem 1rem', nl, nl, '#eee', nl, nl, '1px solid rgba(212,175,55,0.2)', nl, 'center', nl, '100%', 'rgba(0,0,0,0.3)', nl, '8px', nl, nl, nl, nl, '1rem'], // inspected-container
      [nl, nl, '0 0 0.5rem 0', 'serif', '1.1rem', '#d4af37', nl, nl, '1px solid rgba(212,175,55,0.1)', 'capitalize', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.5rem'], // inspected-title
      ['flex', 'row', '0.2rem 0', nl, '0.9rem', '#ccc', 'space-between', nl, nl, nl, 'left', nl, '100%', nl, nl, nl, nl, nl, nl, nl, nl], // inspected-text
    ]
};

const gameWorldStyles = {
    prefix: 'game-world',
    styles: [
        'display', 'flex-direction', 'height', 'width', 'background', 'position', 'flex-basis', 'transition', 'min-width',
        'padding', 'right', 'transform', 'top', 'border-radius', 'font-size', 'color', 'text-shadow'
    ],
    classnames: [
        'container', 'content-area', 'column', 'info-panel-container', 'panel-container', 'tabs-container', 
        'tab-content', 'panel-toggle-button', 'quest-tracker', 'quest-tracker-title', 'quest-tracker-objective',
        'quest-tracker-arrow', 'quest-tracker-distance'
    ],
    styleValues: [
        ['flex', 'column', '100vh', '100vw', 'linear-gradient(160deg, #1a1a2e 0%, #2c2c54 100%)', 'relative', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // container
        ['flex', 'row', '100%', '100%', nl, 'relative', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // content-area
        ['flex', 'column', '100%', nl, nl, 'relative', '70%', 'flex-basis 0.3s ease', nl, nl, nl, nl, nl, nl, nl, nl, nl], // column
        ['flex', 'column', '100%', nl, 'rgba(0,0,0,0.3)', 'relative', '30%', 'all 0.3s ease', '350px', '0 0.5rem', nl, nl, nl, nl, nl, nl, nl], // info-panel-container
        ['flex', 'column', '100%', '100%', nl, 'relative', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // panel-container
        ['flex', 'row', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // tabs-container
        ['block', nl, 'calc(100% - 40px)', nl, nl, 'relative', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // tab-content
        ['flex', nl, '80px', '40px', '#333', 'absolute', nl, nl, nl, '0.5rem', '0', 'translateY(-50%) rotate(180deg)', '50%', '50% 0 0 50%', nl, '#d4af37', nl], // panel-toggle-button
        ['block', nl, nl, nl, 'rgba(0,0,0,0.6)', 'absolute', nl, nl, nl, '1rem', nl, nl, '1rem', '8px', nl, '#fff', '1px 1px 2px #000'], // quest-tracker
        [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1.1rem', '#d4af37', nl], // quest-tracker-title
        [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1rem', '#eee', nl], // quest-tracker-objective
        [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '#d4af37', nl], // quest-tracker-arrow
        [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.9rem', '#888', nl], // quest-tracker-distance
    ]
};

const gameWorldMapStyles = {
    prefix: 'game-world-map',
    styles: ['position', 'top', 'left', 'padding', 'background', 'border-radius', 'color', 'font-size', 'text-transform'],
    classnames: ['container', 'overlay-container', 'mode-indicator'],
    styleValues: [
        ['relative', nl, nl, nl, nl, nl, nl, nl, nl], // container
        ['absolute', '10px', '10px', '0.5rem 1rem', 'rgba(0,0,0,0.6)', '5px', '#d4af37', '1rem', nl], // overlay-container
        [nl, nl, nl, nl, nl, nl, nl, nl, 'capitalize'], // mode-indicator
    ]
};

const miniMapStyles = {
    prefix: 'mini-map',
    styles: ['position', 'top', 'right', 'width', 'height', 'border', 'border-radius', 'background', 'box-shadow'],
    classnames: ['container'],
    styleValues: [
        ['absolute', '10px', '10px', '150px', '150px', '1px solid rgba(212,175,55,0.4)', '8px', 'rgba(0,0,0,0.5)', '0 0 10px rgba(0,0,0,0.5)']
    ]
};

const errorBoundaryStyles = {
    prefix: 'error-boundary',
    styles: ['display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width', 'padding', 'text-align', 'font-family', 'font-size', 'font-weight', 'color', 'background', 'border', 'border-radius', 'cursor', 'margin-top'],
    classnames: ['container', 'title', 'message', 'button'],
    styleValues: [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '2rem', 'center', nl, nl, nl, '#ffcdd2', 'linear-gradient(135deg, #2d1919 0%, #3e1616 50%, #600f0f 100%)', nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, 'center', 'serif', '2.5rem', 'bold', '#d4af37', nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, '80%', '1rem 0', 'center', 'sans-serif', '1.2rem', 'normal', '#e0e0e0', nl, nl, nl, nl],
        ['block', nl, nl, nl, nl, '200px', '1rem', 'center', 'sans-serif', '1rem', 'bold', '#fff', 'transparent', '2px solid #d4af37', '8px', 'pointer', '2rem']
    ]
};

const errorPageStyles = {
    prefix: 'error-page',
    styles: [
        'display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width',
        'padding', 'text-align', 'font-family', 'font-size', 'font-weight', 'color',
        'background', 'border', 'border-radius', 'cursor'
    ],
    classnames: ['container', 'title', 'message', 'button'],
    styleValues: [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '2rem', 'center', nl, nl, nl, '#ffcdd2', 'linear-gradient(135deg, #2d1919 0%, #3e1616 50%, #600f0f 100%)', nl, nl, nl],
        [nl, nl, nl, nl, nl, nl, nl, nl, 'serif', '2.5rem', 'bold', '#d4af37', nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, '80%', '1rem 0', 'center', 'sans-serif', '1.2rem', 'normal', '#e0e0e0', nl, nl, nl, nl],
        ['inline-block', nl, nl, nl, nl, '200px', '1rem', 'center', 'sans-serif', '1rem', 'normal', '#ffffff', 'transparent', '2px solid #d4af37', '8px', 'pointer']
    ]
};

const modalStyles = {
    prefix: 'modal',
    styles: ['position', 'top', 'left', 'width', 'height', 'background', 'display', 'justify-content', 'align-items', 'z-index', 'animation', 'padding', 'border-radius', 'border', 'box-shadow', 'max-width', 'cursor', 'color', 'transition', 'font-size', 'text-align', 'font-weight', 'margin-top'],
    classnames: ['overlay', 'panel-base', 'button'],
    styleValues: [
        ['fixed', '0', '0', '100%', '100%', 'rgba(0,0,0,0.7)', 'flex', 'center', 'center', '1000', 'fadeIn 0.3s', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, '90%', nl, 'rgba(28,28,48,0.95)', nl, nl, nl, '1001', 'growAndFadeIn 0.4s ease-out', '2rem', '15px', '1px solid rgba(212,175,55,0.4)', '0 10px 30px rgba(0,0,0,0.5)', '600px', nl, nl, nl, nl, nl, nl, nl],
        [nl, nl, nl, nl, nl, 'transparent', nl, nl, nl, nl, nl, '1rem 2rem', '8px', '2px solid #d4af37', nl, nl, 'pointer', '#d4af37', 'all 0.3s ease', '1rem', 'center', 'bold', '1.5rem']
    ]
};

const combatButtonStyles = {
    prefix: 'combat-button',
    styles: ['padding', 'font-size', 'font-weight', 'color', 'background', 'border', 'border-radius', 'cursor', 'transition', 'min-width', 'opacity'],
    classnames: ['base'],
    styleValues: [
        ['0.5rem 1rem', '0.9rem', 'bold', '#d4af37', 'rgba(212,175,55,0.1)', '1px solid #d4af37', '5px', 'pointer', 'all 0.2s ease', '120px', '1']
    ]
};


export const ALL_STYLES = [
    splashScreenStyles,
    mainMenuStyles,
    aboutScreenStyles,
    oceanQuestionnaireStyles,
    characterCreationStyles,
    statWebStyles,
    statusPanelStyles,
    gameWorldStyles,
    gameWorldMapStyles,
    miniMapStyles,
    errorBoundaryStyles,
    errorPageStyles,
    modalStyles,
    combatButtonStyles,
];