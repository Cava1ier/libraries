

export const GAME_CONFIG = {
  MOVEMENT: {
    animationSpeed: 200,
    visionRadius: 10,
    autoExploreRadius: 30,
    // FIX: Added missing properties to conform to the expected type.
    pathfindingTimeout: 5000,
    maxPathLength: 100,
  },
  ACTIONS: {
    CULTIVATION_DURATION: 5000,
    MEDITATION_DURATION: 2000,
    EXPLORATION_DELAY: 100,
  },
  LIMITS: {
    MAX_QI: 1000,
    MIN_Z_LEVEL: 0,
    MAX_Z_LEVEL: 10,
  }
} as const;