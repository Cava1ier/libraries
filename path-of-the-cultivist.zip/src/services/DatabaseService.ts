import { BaseService } from '../patterns/BaseService';
import { GameDatabase, DatabaseTable } from '../systems/database/Database';

export class DatabaseService extends BaseService {
 public tables: { [key: string]: DatabaseTable } = {};
 private language: string = 'English';

 constructor() {
  super();
  this.initializeDynamicTables();
 }
 
 public setLanguage(lang: string): void {
     this.language = lang;
 }

 initializeDynamicTables() {
  this.tables.characters = new DatabaseTable('characters', ['name', 'realm', 'cultivation_level', 'qi_points', 'max_qi_points', 'body_tempering', 'soul_strength', 'dao_comprehension', 'spiritual_roots', 'meridian_purity', 'elemental_affinity', 'karmic_burden', 'heavenly_tribulation', 'fate_threads', 'ocean_o', 'ocean_c', 'ocean_e', 'ocean_a', 'ocean_n', 'conflict_strength', 'conflict_like_1', 'conflict_like_2', 'conflict_abhor', 'story_archetype', 'x', 'y', 'z', 'spiritual_roots_value', 'mental_fortitude', 'physical_resilience', 'experience', 'attribute_points']);
  this.tables.events = new DatabaseTable('events', ['character_id', 'location_id', 'event_type', 'description', 'timestamp', 'consequences', 'story_impact']);
  this.tables.cultivation_techniques = new DatabaseTable('cultivation_techniques', ['name', 'grade', 'element', 'requirements', 'effects', 'side_effects']);
  this.tables.factions = new DatabaseTable('factions', ['name', 'type', 'description', 'ideology', 'powerLevel', 'territory']);
  this.tables.faction_members = new DatabaseTable('faction_members', ['factionId', 'characterId', 'rank', 'loyalty']);
  this.tables.relationships = new DatabaseTable('relationships', ['sourceCharacterId', 'targetCharacterId', 'type', 'strength']);
  this.tables.world_sites = new DatabaseTable('world_sites', [ 'x', 'y', 'z', 'type', 'name', 'properties' ]);
  this.tables.world_creatures = new DatabaseTable('world_creatures', [ 'x', 'y', 'z', 'typeId' ]);
  this.tables.recipes = new DatabaseTable('recipes', [ 'name', 'result_item_id', 'result_quantity', 'req_item_id_1', 'req_quantity_1', 'req_item_id_2', 'req_quantity_2' ]);
 }
 
 getTable(name: string) { return this.tables[name.startsWith('tbl') ? name : `tbl${name}`] || this.tables[name]; }

 private _parseAndLoadTable(content: string) {
    const lines = content.trim().replace(/\r/g, '').split('\n').filter(line => line.trim().startsWith(':'));
    if (lines.length === 0) return;
    const headerMatch = lines[0].match(/^:([^:]+):([^:]+):$/);
    if (!headerMatch) return;
    const tableName = headerMatch[1];
    const columnNames = headerMatch[2].split('|');
    const table = new DatabaseTable(tableName, columnNames.filter(c => c !== 'id'));
    for (let i = 1; i < lines.length; i++) {
        const rowMatch = lines[i].match(/^:(.*):$/);
        if (!rowMatch) continue;
        const values = rowMatch[1].split('|');
        const record: { [key: string]: any } = {};
        columnNames.forEach((colName, index) => {
            const value = values[index] || '';
            if (!isNaN(Number(value)) && value.trim() !== '' && !value.includes('.') && colName.toLowerCase() !== 'id' && colName.toLowerCase() !== 'name') record[colName] = parseInt(value, 10);
            else if (!isNaN(parseFloat(value)) && value.trim() !== '' && !value.includes(':')) record[colName] = parseFloat(value);
            else record[colName] = value;
        });
        if (values[columnNames.indexOf('id')]) record.id = values[columnNames.indexOf('id')];
        table.addRecord(record);
    }
    this.tables[tableName] = table;
 }

 public async loadDatabase() {
    const fileNames = ['Alignments.txt', 'Beasts.txt', 'Civilizations.txt', 'Items.txt', 'NamingRules.txt', 'Nouns.txt', 'PersonRoles.txt', 'Places.txt', 'PreNameAdjectives.txt', 'QuestOriginations.txt', 'Ranks.txt', 'Suffixes.txt', 'Verbs.txt', 'AIGoalTypes.txt', 'CreatureTypes.txt', 'GameStates.txt', 'ItemQualities.txt', 'ItemTypes.txt', 'MovementPatterns.txt', 'QuestTypes.txt', 'SkillTypes.txt', 'OCEANQuestions.txt', 'OCEANAnswers.txt', 'Quests.txt', 'NPCs.txt', 'TerrainTypes.txt', 'Biomes.txt', 'OCEAN_ConflictMapping.txt', 'Breakthroughs.txt', 'ConflictNarratives.txt', 'CombatSkills.txt', 'ItemCombatEffects.txt', 'Recipes.txt'];
    for (const fileName of fileNames) {
        try {
            const response = await fetch(`./database/${this.language}/${fileName}`);
            if (response.ok) this._parseAndLoadTable(await response.text());
            else console.error(`Failed to load ${fileName}: ${response.statusText}`);
        } catch (error) { console.error(`Error loading or parsing ${fileName}:`, error); }
    }
 }
}