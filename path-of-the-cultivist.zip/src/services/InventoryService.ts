
import { BaseService } from '../patterns/BaseService';
import { ItemData, ItemQuality, ItemType } from '../types/AdventureTypes';
import { DatabaseService } from './DatabaseService';

export class InventoryService extends BaseService {
    private items: ItemData[] = [];

    constructor(private db: DatabaseService) {
        super();
        const itemsTable = this.db.getTable('tblItems');
        if (itemsTable) {
            const herbRecord = itemsTable.find(1);
            const seedRecord = itemsTable.find(10); 
            if(herbRecord) this.addItem(herbRecord.id, 5, ItemQuality.Common);
            if(seedRecord) this.addItem(seedRecord.id, 1, ItemQuality.Rare);
        } else {
            console.warn("Inventory Service: 'tblItems' not found. Initial items not added.");
        }
    }

    public getItems(): ItemData[] { return this.items; }
    public setItems(items: ItemData[]) { this.items = items; }

    public addItem(typeId: number, quantity: number, qualityId: ItemQuality) {
        const existingItem = this.items.find(i => i.typeId === typeId && i.qualityId === qualityId);
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.items.push({
                id: `item_${typeId}_${Date.now()}`,
                typeId, quantity, qualityId,
            });
        }
    }
    
    public removeItem(typeId: number, quantity: number): boolean {
        const item = this.items.find(i => i.typeId === typeId);
        if (item && item.quantity >= quantity) {
            item.quantity -= quantity;
            if (item.quantity <= 0) {
                this.items = this.items.filter(i => i.id !== item.id);
            }
            return true;
        }
        return false;
    }
}
