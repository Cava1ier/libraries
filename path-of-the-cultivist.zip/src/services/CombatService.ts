

import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';
import { InventoryService } from './InventoryService';
import { DatabaseService } from './DatabaseService';
// FIX: Added CombatParticipant and EntityStats to imports to support the refactored implementation.
import { CombatEncounter, CreatureData, CombatParticipant, EntityStats, StatusEffect } from '../types/AdventureTypes';

export class CombatService extends BaseService {
  public currentCombat: CombatEncounter | null = null;
  // FIX: Added an onUpdate callback to allow UI to refresh when creature turns are processed.
  private onUpdate: () => void = () => {};

  constructor(
    private rngService: RNGService, 
    private inventoryService: InventoryService, 
    private database: DatabaseService
  ) {
    super();
  }

  // FIX: Added method to allow external systems to subscribe to updates.
  public setUpdateCallback(callback: () => void) {
    this.onUpdate = callback;
  }

  // FIX: Rewrote `startCombat` to correctly initialize a CombatEncounter with participants and a turn index.
  public startCombat(player: any, creature: CreatureData): CombatEncounter {
    const playerStats: EntityStats = {
        health: player.qi_points,
        maxHealth: 1000,
        attack: 5 + Math.floor(player.body_tempering / 5),
        defense: 5 + Math.floor(player.physical_resilience / 10),
        speed: 5 + Math.floor(player.fate_threads / 10),
        energy: 100
    };

    const playerParticipant: CombatParticipant = {
      id: 'player',
      entity: player,
      isPlayer: true,
      stats: JSON.parse(JSON.stringify(playerStats)),
      initiative: this.rngService.nextInRange(1, 20) + playerStats.speed,
      statusEffects: [],
    };

    const creatureParticipant: CombatParticipant = {
      id: creature.id,
      entity: creature,
      isPlayer: false,
      stats: JSON.parse(JSON.stringify(creature.stats)),
      initiative: this.rngService.nextInRange(1, 20) + creature.stats.speed,
      statusEffects: [],
    };

    const participants = [playerParticipant, creatureParticipant];
    participants.sort((a, b) => b.initiative - a.initiative);

    this.currentCombat = {
      id: `combat_${Date.now()}`,
      participants,
      turnIndex: -1, // Start at -1, processNextTurn will advance it to the first participant
      log: [`Combat started with ${creature.name}! ${participants[0].entity.name} has the initiative.`],
      isActive: true,
    };

    this.processNextTurn();
    return this.currentCombat;
  }
  
  // FIX: Added a comprehensive handler for player actions, which was missing.
  public handlePlayerAction(action: { type: string, id?: any }) {
    if (!this.currentCombat || !this.currentCombat.isActive) return;
    const participant = this.currentCombat.participants[this.currentCombat.turnIndex];
    if (!participant.isPlayer) {
        this.currentCombat.log.push("It is not your turn!");
        return;
    }

    let result: any;
    switch (action.type) {
        case 'attack': result = this.playerAttack(); break;
        case 'defend': result = this.playerDefend(); break;
        case 'skill': result = this.playerUseSkill(action.id); break;
        case 'item': result = this.playerUseItem(action.id); break;
        case 'flee':
            this.currentCombat.log.push("You fled from combat.");
            this.currentCombat.isActive = false;
            break;
    }
    
    if (result?.combatEnded) {
        this.currentCombat.isActive = false;
    } else if (this.currentCombat.isActive) {
        this.processNextTurn();
    }
  }
  
  // All other public methods from dCombatSystem...
  public endCombat() { this.currentCombat = null; }

  // FIX: Replaced simple `advanceTurn` with a robust turn processor that handles effects, death, and AI turns.
  private processNextTurn() {
    if (!this.currentCombat || !this.currentCombat.isActive) return;

    this.currentCombat.turnIndex = (this.currentCombat.turnIndex + 1) % this.currentCombat.participants.length;
    const participant = this.currentCombat.participants[this.currentCombat.turnIndex];

    this.processTurnEffects(participant);

    if (participant.stats.health <= 0) {
      this.processNextTurn(); // Skip turn if participant is defeated
      return;
    }

    if (!participant.isPlayer) {
      setTimeout(() => {
        if (this.currentCombat?.isActive) {
          this.processCreatureTurn(participant);
          this.onUpdate(); // Notify UI of creature's action
        }
      }, 750);
    }
  }

  private processCreatureTurn(creature: CombatParticipant) {
      if (!this.currentCombat || !this.currentCombat.isActive) return;
      
      const player = this.currentCombat.participants.find(p => p.isPlayer);
      if (!player) return;

      let result;
      const healthPercentage = (creature.stats.health / creature.stats.maxHealth) * 100;
      
      // AI decision logic
      if (healthPercentage < 30 && this.rngService.nextInRange(1, 100) <= 50) {
        // 50% chance to defend if health is low
        result = this.creatureDefend(creature);
      } else {
        // Default to a normal attack
        result = this.executeAttack(creature, player);
      }
      
      this.currentCombat.log.push(result.log);
      
      if (player.stats.health <= 0) {
          this.currentCombat.log.push(`You have been defeated!`);
          this.currentCombat.isActive = false;
      } else {
          this.processNextTurn();
      }
  }

  private processTurnEffects(participant: CombatParticipant) {
    if (!participant.statusEffects || participant.statusEffects.length === 0) return;

    let damageOverTime = 0;
    
    // Apply damage from existing effects at the start of the turn
    for (const effect of participant.statusEffects) {
        if (effect.type === 'poisoned' && effect.damage) {
            participant.stats.health -= effect.damage;
            damageOverTime += effect.damage;
        }
    }
    
    if (damageOverTime > 0 && this.currentCombat) {
        this.currentCombat.log.push(`${participant.entity.name} takes ${damageOverTime} damage from poison.`);
    }

    // Update and filter effects for the next turn
    participant.statusEffects = participant.statusEffects
        .map(effect => ({ ...effect, turns: effect.turns - 1 }))
        .filter(effect => {
            if (effect.turns > 0) {
                return true;
            } else {
                if (this.currentCombat) {
                    this.currentCombat.log.push(`${participant.entity.name} is no longer ${effect.type}.`);
                }
                return false;
            }
        });
  }

  // FIX: Updated player actions to use the new combat structure.
  public playerAttack(): { log: string, combatEnded: boolean, playerWon: boolean } {
    if (!this.currentCombat || !this.currentCombat.participants[this.currentCombat.turnIndex].isPlayer) return { log: "Not your turn.", combatEnded: false, playerWon: false };
    const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
    const creature = this.currentCombat!.participants.find(p => !p.isPlayer)!;
    const result = this.executeAttack(player, creature);
    this.currentCombat!.log.push(result.log);

    if (creature.stats.health <= 0) {
      this.currentCombat!.log.push(`${creature.entity.name} defeated!`);
      return { log: result.log, combatEnded: true, playerWon: true };
    }
    return { log: result.log, combatEnded: false, playerWon: false };
  }

  public playerDefend(): { log: string } {
      if (!this.currentCombat || !this.currentCombat.participants[this.currentCombat.turnIndex].isPlayer) return { log: "Not your turn." };
      const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
      const log = "You brace for the next attack.";
      player.statusEffects.push({ type: 'defending', turns: 2 });
      this.currentCombat!.log.push(log);
      return { log };
  }

  private creatureDefend(creature: CombatParticipant): { log: string } {
      const log = `${creature.entity.name} braces for the next attack.`;
      creature.statusEffects.push({ type: 'defending', turns: 2 });
      return { log };
  }

  public playerUseSkill(skillId: number) {
    if (!this.currentCombat || !this.currentCombat.participants[this.currentCombat.turnIndex].isPlayer) return { log: "Not your turn.", combatEnded: false, playerWon: false };
    const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
    const creature = this.currentCombat!.participants.find(p => !p.isPlayer)!;
    const skill = this.database.getTable('tblCombatSkills').find(skillId);
    if (!skill || player.entity.qi_points < skill.qi_cost) {
      const log = !skill ? "Skill not found." : "Not enough Qi.";
      this.currentCombat!.log.push(log);
      return { log, combatEnded: false, playerWon: false };
    }
    player.entity.qi_points -= skill.qi_cost;
    let log = `You used ${skill.name}.`;
    if (skill.effect_type === 'DAMAGE') {
      const statValue = skill.effect_value_stat !== 'none' ? (player.entity[skill.effect_value_stat] || 0) : 0;
      const damage = skill.effect_value_base + Math.floor(statValue * skill.effect_value_multiplier);
      creature.stats.health -= damage;
      log += ` It dealt ${damage} damage.`;
    } else if (skill.effect_type === 'HEAL') {
      player.entity.qi_points = Math.min(1000, player.entity.qi_points + skill.effect_value_base);
      log += ` You recover ${skill.effect_value_base} Qi.`;
    }
    this.currentCombat!.log.push(log);
    if (creature.stats.health <= 0) {
      this.currentCombat!.log.push(`${creature.entity.name} defeated!`);
      return { log: `${creature.entity.name} defeated!`, combatEnded: true, playerWon: true };
    }
    return { log, combatEnded: false, playerWon: false };
  }

  public playerUseItem(itemId: number) {
    if (!this.currentCombat || !this.currentCombat.participants[this.currentCombat.turnIndex].isPlayer) return { log: "Not your turn.", combatEnded: false, playerWon: false };
    let log = "You don't have that item.";
    const itemRecord = this.database.getTable('tblItemTypes').find(itemId);
    const itemEffect = this.database.getTable('tblItemCombatEffects').query((r: any) => r.item_id == itemId)[0];
    if (itemRecord && itemEffect && this.inventoryService.removeItem(itemId, 1)) {
        log = `You used a ${itemRecord.name}.`;
        const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
        if (itemEffect.effect_type === 'HEAL') {
            player.entity.qi_points = Math.min(1000, player.entity.qi_points + parseInt(itemEffect.effect_value));
            log += ` You recover ${itemEffect.effect_value} Qi.`;
        }
        this.currentCombat.log.push(log);
    } else {
        this.currentCombat.log.push(itemRecord ? `You can't use ${itemRecord.name} in combat.` : log);
    }
    return { log, combatEnded: false, playerWon: false };
  }
  
  private executeAttack(attacker: CombatParticipant, defender: CombatParticipant) {
    const isDefending = defender.statusEffects.some(e => e.type === 'defending');
    const attackRoll = this.rngService.nextInRange(1, 20) + attacker.stats.attack;
    const defenseValue = defender.stats.defense + (isDefending ? 5 : 0);

    if (attackRoll > defenseValue) {
      let damage = this.rngService.nextInRange(Math.floor(attacker.stats.attack / 2), attacker.stats.attack);
      if (isDefending) {
          damage = Math.floor(damage / 2);
          this.currentCombat?.log.push(`${defender.entity.name} defends!`);
      }
      defender.stats.health -= damage;
      
      let logMessage = `${attacker.entity.name} hits ${defender.entity.name} for ${damage} damage.`;
      
      // Apply on-hit effects for creatures
      if (!attacker.isPlayer) {
          const creatureTypeId = attacker.entity.typeId;
          // Rain-Pearl Serpent (ID 14) has 30% chance to poison
          if (creatureTypeId === 14 && this.rngService.nextInRange(1, 100) <= 30) {
              const existingPoison = defender.statusEffects.find(e => e.type === 'poisoned');
              const poisonEffect: StatusEffect = { type: 'poisoned', turns: 3, damage: 5 };
              
              if (existingPoison) {
                  existingPoison.turns = Math.max(existingPoison.turns, poisonEffect.turns);
              } else {
                  defender.statusEffects.push(poisonEffect);
              }
              logMessage += ` You are poisoned!`;
          }
      }

      return { damage, log: logMessage };
    } else {
      return { damage: 0, log: `${attacker.entity.name}'s attack is blocked by ${defender.entity.name}.` };
    }
  }
}