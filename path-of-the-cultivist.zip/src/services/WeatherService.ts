import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';

export enum Season { Spring, Summer, Autumn, Winter }
export enum WeatherType { Clear, Cloudy, Rain, Storm, Fog, Snow }

export interface GameTime {
    year: number;
    season: Season;
    day: number;
    hour: number;
    minute: number;
}

export interface WeatherState {
    type: WeatherType;
    intensity: number; // 0-100
}

export class WeatherService extends BaseService {
    private time: GameTime;
    private weather: WeatherState;

    constructor(private rngService: RNGService) {
        super();
        this.time = { year: 1, season: Season.Spring, day: 1, hour: 8, minute: 0 };
        this.weather = { type: WeatherType.Clear, intensity: 100 };
    }

    public advanceTime(minutes: number) {
        this.time.minute += minutes;

        if (this.time.minute >= 60) {
            const hours = Math.floor(this.time.minute / 60);
            this.time.minute %= 60;
            this.time.hour += hours;
            
            let dayChanged = false;
            if (this.time.hour >= 24) {
                const days = Math.floor(this.time.hour / 24);
                this.time.hour %= 24;
                this.time.day += days;
                dayChanged = true;
            }

            if (this.time.day > 90) { // 90 days per season
                const seasonsPassed = Math.floor((this.time.day - 1) / 90);
                this.time.day = ((this.time.day - 1) % 90) + 1;
                const oldSeason = this.time.season;
                this.time.season = (this.time.season + seasonsPassed) % 4;

                if (this.time.season < oldSeason) { // Year wrapped around
                    this.time.year++;
                }
            }
            this.updateWeather();
        }
    }
    
    private updateWeather() {
        if (this.rngService.nextInRange(0, 100) < 20) { // 20% chance to change weather each hour
            const weatherTypes = Object.values(WeatherType).filter(v => typeof v === 'number') as number[];
            
            let newWeatherType: WeatherType;
            if (this.time.season === Season.Winter && this.rngService.nextInRange(0, 100) < 40) {
                newWeatherType = WeatherType.Snow;
            } else if (this.time.season === Season.Summer && this.rngService.nextInRange(0, 100) < 25) {
                newWeatherType = WeatherType.Storm;
            } else if (this.time.season === Season.Spring && this.rngService.nextInRange(0, 100) < 30) {
                newWeatherType = WeatherType.Rain;
            } else {
                 newWeatherType = this.rngService.nextInRange(0, weatherTypes.length - 1);
            }
            
            this.weather.type = newWeatherType;
            this.weather.intensity = this.rngService.nextInRange(20, 100);
        }
    }

    public getTime(): GameTime { return { ...this.time }; }
    public getWeather(): WeatherState { return { ...this.weather }; }
    
    public getFormattedTime(): string {
        return `Year ${this.time.year}, ${Season[this.time.season]}, Day ${this.time.day}, ${String(this.time.hour).padStart(2, '0')}:${String(this.time.minute).padStart(2, '0')}`;
    }
    
    public getFormattedWeather(): string {
        return `${WeatherType[this.weather.type]}`;
    }

    public setTime(time: GameTime) { 
        this.time = time;
        if (this.time.minute === undefined) {
            this.time.minute = 0;
        }
    }
}
