import { BaseService } from '../patterns/BaseService';

export class LocalizationService extends BaseService {
    private strings: Map<string, string> = new Map();
    public language: string = 'English';

    constructor() {
        super();
    }

    public async loadLanguage(lang: string): Promise<void> {
        this.language = lang;
        this.strings.clear();
        
        try {
            const response = await fetch(`./database/${lang}/UIText.txt`);
            if (!response.ok) {
                console.error(`Failed to load language file for ${lang}`);
                // Fallback to English if the selected language file is not found
                if (lang !== 'English') {
                    return this.loadLanguage('English');
                }
                return;
            }
            const content = await response.text();
            this.parseStrings(content);
        } catch (error) {
            console.error(`Error loading language file for ${lang}:`, error);
             if (lang !== 'English') {
                return this.loadLanguage('English');
            }
        }
    }

    private parseStrings(content: string) {
        const lines = content.trim().replace(/\r/g, '').split('\n').filter(line => line.trim().startsWith(':'));
        if (lines.length === 0) return;

        // Skip header line
        for (let i = 1; i < lines.length; i++) {
            const rowMatch = lines[i].match(/^:(.*):$/);
            if (rowMatch) {
                const values = rowMatch[1].split('|');
                // Expected format: id|key|value
                if (values.length >= 3) {
                    const key = values[1];
                    const value = values[2];
                    this.strings.set(key, value);
                }
            }
        }
    }

    public get(key: string, replacements?: Record<string, string | number>): string {
        let str = this.strings.get(key) || `[${key}]`;
        if (replacements) {
            Object.entries(replacements).forEach(([placeholder, value]) => {
                str = str.replace(`{${placeholder}}`, String(value));
            });
        }
        return str;
    }
}