
import { BaseService } from '../patterns/BaseService';
import { DatabaseService } from './DatabaseService';
import { Faction, FactionGoal, FactionGoalType } from '../types/SocialTypes';
import { WorldService } from './WorldService';
import { RNGService } from './RNGService';
import { Character } from '../data/dCharacter';

export class FactionSystemService extends BaseService {
    private factions: Map<string, Faction> = new Map();

    constructor(
        private db: DatabaseService,
        private worldService: WorldService,
        private rngService: RNGService
    ) {
        super();
    }

    public loadFactionsFromSave(factions: Faction[]) {
        this.factions.clear();
        factions.forEach(faction => {
            this.factions.set(faction.id, faction);
        });
    }

    public setFactions(factions: Faction[]) {
        const factionTable = this.db.getTable('factions');
        const membersTable = this.db.getTable('faction_members');
        
        factionTable.records = [];
        membersTable.records = [];
        this.factions.clear();

        factions.forEach(faction => {
            this.factions.set(faction.id, faction);
            
            factionTable.insert({
                id: faction.id, name: faction.name, type: faction.type,
                description: faction.description, ideology: JSON.stringify(faction.ideology),
                powerLevel: faction.powerLevel, territory: JSON.stringify(faction.territory)
            });

            faction.members.forEach(member => {
                membersTable.insert({
                    factionId: faction.id, characterId: member.characterId,
                    rank: member.rank, loyalty: member.loyalty
                });
            });
        });
    }
    
    public updateFactionAI(character: Character) {
        const gameTime = Date.now();
        const aiUpdateCooldown = 1000 * 60; // Every 1 minute for testing

        for (const faction of this.factions.values()) {
            if (gameTime - (faction.lastAiUpdate || 0) < aiUpdateCooldown) {
                continue;
            }

            faction.lastAiUpdate = gameTime;

            if (faction.currentGoal && faction.currentGoal.progress < 100) {
                faction.currentGoal.progress += this.rngService.nextInRange(5, 15);
                if (faction.currentGoal.progress >= 100) {
                    console.log(`Faction '${faction.name}' completed goal: ${faction.currentGoal.type}`);
                    // Apply goal reward, e.g., increase resources
                    faction.currentGoal = undefined;
                }
            } else {
                this.selectNewGoalForFaction(faction, character);
            }
        }
    }
    
    private selectNewGoalForFaction(faction: Faction, character: Character) {
        const goalTypes = [FactionGoalType.GATHER_RESOURCES, FactionGoalType.INCREASE_INFLUENCE];
        const selectedType = goalTypes[this.rngService.next() % goalTypes.length];

        const newGoal: FactionGoal = {
            type: selectedType,
            progress: 0,
            startedAt: Date.now(),
        };

        faction.currentGoal = newGoal;
        console.log(`Faction '${faction.name}' has a new goal: ${selectedType}`);
    }

    public getFaction(id: string): Faction | undefined {
        return this.factions.get(id);
    }

    public getAllFactions(): Faction[] {
        return Array.from(this.factions.values());
    }
}