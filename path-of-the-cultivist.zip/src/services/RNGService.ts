
import { BaseService } from '../patterns/BaseService';

export class RNGService extends BaseService {
 private numbers: number[];
 private currentIndex: number;
 private seed: number;

 constructor(initialNumbers?: number[], seed?: number) {
  super();
  this.currentIndex = 0;
  if (initialNumbers && initialNumbers.length > 0) {
   this.numbers = initialNumbers;
   this.seed = seed ?? Date.now();
  } else {
   this.seed = seed ?? Date.now();
   this.numbers = [];
   this.generateNumbers();
  }
 }
 
 private seededRandom() {
    this.seed = (this.seed * 1664525 + 1013904223) % Math.pow(2, 32);
    return this.seed / Math.pow(2, 32);
 }

 generateNumbers() {
  this.numbers = [];
  for (let i = 0; i < 400; i++) {
   this.numbers.push(Math.floor(this.seededRandom() * 1000));
  }
 }
 
 next() {
  const num = this.numbers[this.currentIndex];
  this.currentIndex = (this.currentIndex + 1) % this.numbers.length;
  return num;
 }
 
 nextInRange(min: number, max: number) {
  if (this.numbers.length === 0) return min;
  return min + (this.next() % (max - min + 1));
 }

 getNumbers(): number[] { return [...this.numbers]; }
 public setCurrentIndex(index: number): void { if (this.numbers.length > 0) this.currentIndex = index % this.numbers.length; }
 public getCurrentIndex(): number { return this.currentIndex; }
}
