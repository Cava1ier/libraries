import { BaseService } from '../patterns/BaseService';
import { Faction } from '../types/SocialTypes';
import { CreatureData } from '../types/AdventureTypes';

const SAVE_KEY_PREFIX = 'cultivist_save_';

export interface SaveData {
    characterData: any;
    quests: any[];
    inventory: any[];
    time: any;
    discoveredTiles: string[];
    factions: any[]; // Storing as any[] because Map will be serialized to array
    creatures: CreatureData[];
}

interface SavePackage {
    version: string;
    timestamp: number;
    compressed: boolean;
    checksum: string;
    data: string;
}

export class SaveService extends BaseService {
    private readonly SAVE_VERSION = '1.0.2';
    private readonly COMPRESSION_ENABLED = true;

    constructor() {
        super();
    }

    private _compressData(data: string): string {
        return data.replace(/(.)\1{3,}/g, (match) => `~${match.length}${match[0]}`);
    }

    private _decompressData(data: string): string {
        return data.replace(/~(\d+)(.)/g, (_, count, char) => char.repeat(parseInt(count)));
    }
    
    private _calculateChecksum(data: string): string {
        let hash = 0;
        for (let i = 0; i < data.length; i++) {
            const char = data.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; // Convert to 32bit integer
        }
        return hash.toString(16);
    }

    public saveGame(saveData: SaveData, slotId: number = 1): boolean {
        try {
            const json = JSON.stringify(saveData);
            const checksum = this._calculateChecksum(json);
            const compressedData = this.COMPRESSION_ENABLED ? this._compressData(json) : json;
            
            const savePackage: SavePackage = {
                version: this.SAVE_VERSION,
                timestamp: Date.now(),
                compressed: this.COMPRESSION_ENABLED,
                checksum,
                data: compressedData,
            };
            
            localStorage.setItem(`${SAVE_KEY_PREFIX}${slotId}`, JSON.stringify(savePackage));
            console.log(`Game Saved to slot ${slotId}!`);
            return true;
        } catch (error) {
            console.error(`Failed to save game to slot ${slotId}:`, error);
            return false;
        }
    }

    public loadGame(slotId: number = 1): SaveData | null {
        try {
            const packageJson = localStorage.getItem(`${SAVE_KEY_PREFIX}${slotId}`);
            if (!packageJson) return null;
            
            const savePackage: SavePackage = JSON.parse(packageJson);
            
            if (savePackage.version !== this.SAVE_VERSION) {
                 console.warn(`Save file version mismatch. Expected ${this.SAVE_VERSION}, got ${savePackage.version}. Attempting to load anyway.`);
            }

            const json = savePackage.compressed ? this._decompressData(savePackage.data) : savePackage.data;
            
            const checksum = this._calculateChecksum(json);
            if (checksum !== savePackage.checksum) {
                console.error("Save file corrupted: checksum mismatch.");
                localStorage.removeItem(`${SAVE_KEY_PREFIX}${slotId}`);
                return null;
            }

            const loadedData: SaveData = JSON.parse(json);
            console.log(`Game Loaded from slot ${slotId}!`, loadedData);
            return loadedData;
        } catch (error) {
            console.error(`Failed to load game from slot ${slotId}:`, error);
            return null;
        }
    }
    
    public hasSaveGame(slotId: number = 1): boolean {
        return localStorage.getItem(`${SAVE_KEY_PREFIX}${slotId}`) !== null;
    }
    
    public getAvailableSlots(): number[] {
        const slots: number[] = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key?.startsWith(SAVE_KEY_PREFIX)) {
                const slotId = parseInt(key.replace(SAVE_KEY_PREFIX, ''));
                if (!isNaN(slotId)) {
                    slots.push(slotId);
                }
            }
        }
        return slots.sort((a,b) => a - b);
    }
}
