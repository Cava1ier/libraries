import { BaseService } from '../patterns/BaseService';
import { Character } from '../data/dCharacter';
import { WorldService } from './WorldService';
import { CreatureService } from './CreatureService';
import { PathfindingService } from './PathfindingService';
import { InventoryService } from './InventoryService';
import { QuestService } from './QuestService';
import { DatabaseService } from './DatabaseService';
import { SkillService } from './SkillService';
import { PathfindingResult, MovementValidationResult } from '../systems/movement/MovementTypes';
import { Position } from '../systems/generation/character/Character.types';
import { Pathfinder } from '../systems/movement/Pathfinder';
import { MovementValidator } from '../systems/movement/MovementValidator';
import { MovementExecutor } from '../systems/movement/MovementExecutor';
import { AnimationController } from '../systems/movement/AnimationController';
import { GameConfiguration } from '../systems/world/character/managers/ConfigurationManager';

export class MovementService extends BaseService {
  public pathfinder: Pathfinder;
  public validator: MovementValidator;
  public executor: MovementExecutor;
  public animator: AnimationController;
  private config: GameConfiguration['movement'];

  constructor(
    private worldService: WorldService,
    private creatureService: CreatureService,
    private pathfindingService: PathfindingService,
    private inventoryService: InventoryService,
    private questService: QuestService,
    private databaseService: DatabaseService,
    private skillService: SkillService,
  ) {
    super();
    this.config = { animationSpeed: 200, pathfindingTimeout: 5000, maxPathLength: 100, visionRadius: 10, autoExploreRadius: 30 };
    this.pathfinder = new Pathfinder(this.pathfindingService);
    this.validator = new MovementValidator(this.worldService, this.creatureService as any, this.skillService as any);
    this.executor = new MovementExecutor(this.worldService, this.inventoryService, this.questService, this.databaseService, this.skillService);
    this.animator = new AnimationController(this.config);
  }

  public async moveTo(character: Character, position: Position): Promise<MovementValidationResult> {
    const validation = this.validator.validateMovement(character, position, character.data);
    if (!validation.success) return validation;
    const result = this.executor.executeMovement(character, position);
    return { success: result.success, blockedBy: 'none' };
  }

  public followPath(character: Character, path: Position[]): Promise<MovementValidationResult> {
    return new Promise((resolve) => {
        let lastMoveResult: MovementValidationResult | null = null;
        this.animator.startPathAnimation(path,
            async (position) => { const moveResult = await this.moveTo(character, position); lastMoveResult = moveResult; return moveResult.success; },
            () => resolve({ success: true, blockedBy: 'none' }),
            (error) => resolve(lastMoveResult || { success: false, blockedBy: 'terrain', reason: error })
        );
    });
  }

  public findPathTo(start: Position, target: Position): PathfindingResult { return this.pathfinder.findPath(start, target, this.config.maxPathLength); }
  public stopMovement() { this.animator.stopAnimation(); }
  public isMoving(): boolean { return this.animator.isRunning; }
  public findNearestUnexplored(startPos: Position, discoveredTiles: Set<string>): Position | null {
    const { x, y, z } = startPos;
    const radius = this.config.autoExploreRadius;
    for (let r = 1; r < radius; r++) for (let i = -r; i <= r; i++) for (let j = -r; j <= r; j++) {
        if (Math.abs(i) !== r && Math.abs(j) !== r) continue;
        const checkX = x + i; const checkY = y + j;
        if (!discoveredTiles.has(`${checkX},${checkY}`)) return { x: checkX, y: checkY, z };
    }
    return null;
  }
}