import { BaseService } from '../patterns/BaseService';
import { Character } from '../data/dCharacter';
import { WorldService } from './WorldService';
import { LineOfSightCalculator } from '../systems/vision/LineOfSightCalculator';

export class VisionService extends BaseService {
  constructor(private worldService: WorldService) {
      super();
  }

  public calculateLineOfSight(character: Character, discoveredTiles: Set<string>): { lineOfSight: Set<string>; discovered: Set<string> } {
    const result = LineOfSightCalculator.calculate(character, this.worldService);
    result.discovered.forEach(tileKey => discoveredTiles.add(tileKey));
    return { lineOfSight: result.lineOfSight, discovered: discoveredTiles };
  }
}
