
import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';
import { DatabaseService } from './DatabaseService';
import { WorldService } from './WorldService';
import { RelationshipService } from './RelationshipService';
import { OceanScores, GeneratedCharacter } from '../systems/generation/character/Character.types';
import { CharacterConstants } from '../systems/generation/character/Character.constants';
import { OceanScoreService } from '../systems/generation/character/services/OceanScoreService';
import { PositionService } from '../systems/generation/character/services/PositionService';
import { NameService } from '../systems/generation/character/services/NameService';
import { ArchetypeService } from '../systems/generation/character/services/ArchetypeService';
import { StatService } from '../systems/generation/character/services/StatService';

interface ConflictMapping {
    strength: string;
    likes_1: string;
    likes_2: string;
    abhors: string;
}

export class CharacterGenerationService extends BaseService {
    private oceanService: OceanScoreService;
    private positionService: PositionService;
    private nameService: NameService;
    private archetypeService: ArchetypeService;
    private statService: StatService;

    constructor(
        private rngService: RNGService, 
        private db: DatabaseService, 
        private worldService: WorldService,
        private relationshipService: RelationshipService
    ) {
        super();
        this.oceanService = new OceanScoreService(this.rngService);
        this.positionService = new PositionService(this.worldService, this.rngService);
        this.nameService = new NameService(this.db, this.rngService);
        this.archetypeService = new ArchetypeService();
        this.statService = new StatService(this.rngService);
    }

    public generateCharacter(oceanScores?: Partial<OceanScores>, conflictMapping?: ConflictMapping): number {
        const validatedOceanScores = this.oceanService.generateOrValidate(oceanScores);
        
        const name = this.nameService.generateName();
        const realm = this.getRealm();
        const spiritual_roots = CharacterConstants.ELEMENTS[this.rngService.next() % CharacterConstants.ELEMENTS.length];
        
        const position = this.positionService.findStartPosition();
        const stats = this.statService.generateStats(validatedOceanScores, spiritual_roots);
        const archetype = this.archetypeService.generateArchetype(validatedOceanScores, conflictMapping?.strength || 'Balanced');
        
        const characterData: Omit<GeneratedCharacter, 'id'> = {
            name, realm, ...position, ...stats,
            ocean_o: validatedOceanScores.o, ocean_c: validatedOceanScores.c,
            ocean_e: validatedOceanScores.e, ocean_a: validatedOceanScores.a,
            ocean_n: validatedOceanScores.n,
            conflict_strength: conflictMapping?.strength || 'Man vs Self',
            conflict_like_1: conflictMapping?.likes_1 || 'Man vs Society',
            conflict_like_2: conflictMapping?.likes_2 || 'Man vs Nature',
            conflict_abhor: conflictMapping?.abhors || 'Man vs Technology',
            story_archetype: archetype,
        };
        
        const characterId = this.db.getTable('characters').insert(characterData);
        const newCharacter = this.db.getTable('characters').find(characterId);

        const allCharacters = this.db.getTable('characters').findAll();
        const relationships = this.relationshipService.generateRelationshipsForCharacter(newCharacter, allCharacters);
        
        const relationshipsTable = this.db.getTable('relationships');
        relationships.forEach(rel => relationshipsTable.insert(rel));

        return characterId;
    }

    private getRealm(): string {
        const ranksTable = this.db.getTable('tblRanks');
        const allRanks = ranksTable ? ranksTable.findAll() : [{ name: 'Mortal' }];
        const randomRank = allRanks.length > 0 ? allRanks[this.rngService.next() % allRanks.length] : { name: 'Mortal' };
        return randomRank.name;
    }
}
