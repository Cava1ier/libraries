import { BaseService } from '../patterns/BaseService';
import { ActionRegistry } from '../systems/actions/ActionRegistry';
import { ActionContext } from '../systems/actions/Action.types';
import { GameStateService } from '../systems/world/character/managers/GameStateManager';
import { EventService } from './EventService';

export class ActionService extends BaseService {
    private currentActionTimeoutId: number | null = null;

    constructor(
        private gameStateService: GameStateService,
        private eventService: EventService,
    ) {
        super();
        ActionRegistry.initialize();
    }

    public executeAction(actionId: string, context: ActionContext) {
        const action = ActionRegistry.get(actionId);
        if (!action) {
            console.warn(`Action "${actionId}" not found.`);
            return;
        }

        if (action.duration && action.playerState) {
            this.gameStateService.setPlayerState(action.playerState);
            this.gameStateService.setActionProgress({ startTime: Date.now(), duration: action.duration, actionId });
            this.eventService.addEvent('system', action.startMessage, action.startConsole);

            this.currentActionTimeoutId = window.setTimeout(() => {
                if (this.gameStateService.getPlayerState() !== action.playerState) return;
                
                const result = action.execute(context);
                
                this.gameStateService.setPlayerState('idle');
                this.eventService.addEvent('system', result.message, result.console || "");
                this.currentActionTimeoutId = null;
            }, action.duration);
        } else {
            const result = action.execute(context);
            if(result.message) this.eventService.addEvent('system', result.message, result.console || "");
        }
    }

    public cancelCurrentAction() {
        if (this.currentActionTimeoutId) {
            clearTimeout(this.currentActionTimeoutId);
            this.currentActionTimeoutId = null;
            this.gameStateService.setPlayerState('idle');
            this.eventService.addEvent('system', 'Action cancelled.', '');
        }
    }
}
