
export abstract class BaseService {
    // A base class for services, can hold common logic or lifecycle methods in the future.
    constructor() {}
}
