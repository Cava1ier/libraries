
// OCEANConflictMatrix.tsx
import React from 'react';
import './OCEANConflictMatrix.css';

type Trait = 'Openness' | 'Conscientiousness' | 'Extraversion' | 'Agreeableness' | 'Neuroticism';
type Attitude = 'Enjoys' | 'Likes' | 'Indifferent' | 'Dislikes';
type Intensity = 'Low' | 'Medium' | 'High';
type Conflict = string; // e.g., "Man vs. Nature"

interface Props {
  /** List of literary conflicts to display */
  conflicts: Conflict[];
  /** Optional custom attitudes (defaults to the four listed above) */
  attitudes?: Attitude[];
  /** Optional custom intensities (defaults to Low, Medium, High) */
  intensities?: Intensity[];
  /** Optional custom CSS class for the outer container */
  className?: string;
  /** Data map: key = `${trait}_${attitude}_${intensity}_${conflict}` → description */
  profileData: Record<string, string>;
}

/** Helper to build the map key */
const makeKey = (t: Trait, a: Attitude, i: Intensity, c: Conflict) => `${t}_${a}_${i}_${c}`;

export const OCEANConflictMatrix: React.FC<Props> = ({
  conflicts,
  attitudes = ['Enjoys', 'Likes', 'Indifferent', 'Dislikes'],
  intensities = ['Low', 'Medium', 'High'],
  className = '',
  profileData,
}) => {
  const traits: Trait[] = [
    'Openness',
    'Conscientiousness',
    'Extraversion',
    'Agreeableness',
    'Neuroticism',
  ];

  return (
    <div className={`ocean-matrix ${className}`}>
      {/* Header row – conflicts */}
      <div className="matrix-header empty-cell" />
      {conflicts.map((c) => (
        <div key={c} className="matrix-header conflict">
          {c}
        </div>
      ))}

      {/* Body – for each trait → each attitude → each intensity */}
      {traits.map((trait) =>
        attitudes.map((attitude) =>
          intensities.map((intensity) => (
            <React.Fragment key={`${trait}-${attitude}-${intensity}`}>
              {/* Row label (trait + attitude + intensity) */}
              <div className="matrix-label">
                {trait} – {attitude} – {intensity}
              </div>

              {/* Cells for each conflict */}
              {conflicts.map((conflict) => {
                const key = makeKey(
                  trait,
                  attitude as Attitude,
                  intensity as Intensity,
                  conflict
                );
                const content = profileData[key] ?? '—';
                return (
                  <div key={key} className="matrix-cell">
                    {content}
                  </div>
                );
              })}
            </React.Fragment>
          ))
        )
      )}
    </div>
  );
};
