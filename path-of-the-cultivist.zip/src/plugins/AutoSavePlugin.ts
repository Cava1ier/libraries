



// FIX: Use `import type` to break a circular dependency between the plugin and the main game world class.
// FIX: Changed dCharacterGameWorld to GameCoordinatorService to align with the new architecture.
import type { GameCoordinatorService } from '../services/GameCoordinatorService';
import { GameEvent } from '../systems/events/EventSystem';
import { GamePlugin } from '../systems/plugin/PluginSystem';

export class AutoSavePlugin implements GamePlugin {
  name = 'AutoSave';
  version = '1.0.0';
  dependencies = [];
  
  // FIX: Changed dCharacterGameWorld to GameCoordinatorService.
  private gameWorld!: GameCoordinatorService;
  private intervalId: number | null = null;

  // FIX: Changed dCharacterGameWorld to GameCoordinatorService.
  async initialize(gameWorld: GameCoordinatorService): Promise<void> {
    this.gameWorld = gameWorld;
    
    // FIX: Property 'config' does not exist on 'ActionService'. Using a default value.
    const autoSaveInterval = 300000; // 5 minutes
    
    this.intervalId = window.setInterval(() => {
      // FIX: Property 'validator' does not exist on 'ActionService'. Checking state directly.
      const canSave = !['combat', 'dialogue'].includes(this.gameWorld.playerState);
      if (canSave) {
        this.gameWorld.performAction('save');
      }
    }, autoSaveInterval);
  }

  async destroy(): Promise<void> {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  onEvent(event: GameEvent): void {
    // Save on important events, after a short delay to let state update.
    // We check for quest completion or combat ending in a victory.
    if (event.type === 'quest' || (event.type === 'combat' && event.title.toLowerCase().includes('defeated'))) {
      setTimeout(() => {
        // FIX: Property 'validator' does not exist on 'ActionService'. Checking state directly.
        const canSave = !['combat', 'dialogue'].includes(this.gameWorld.playerState);
        if (canSave) {
          this.gameWorld.performAction('save');
        }
      }, 1000);
    }
  }
}
