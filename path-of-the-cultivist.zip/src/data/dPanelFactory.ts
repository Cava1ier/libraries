import React from 'react';
import { PanelSpec } from './dPanelData';
import { StatusPanel } from '../ui/StatusPanel';
import { ActionsPanel } from '../ui/ActionsPanel';
import { LogPanel } from '../ui/LogPanel';
import { InventoryPanel } from '../ui/InventoryPanel';
import { QuestPanel } from '../ui/QuestPanel';
import { SkillsPanel } from '../ui/SkillsPanel';
import { QuestLogPanel } from '../ui/QuestLogPanel';
import { GameWorldData } from '../components/GameWorld/dataGameWorld';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { OptionsPanel } from '../ui/OptionsPanel';

export class PanelFactory {
  static create(spec: PanelSpec, isVisible: boolean, gameData: GameWorldData, pluginManager: PluginManager): React.ReactElement {
    const baseProps = { spec, isVisible, pluginManager, key: spec.id };

    switch (spec.type) {
      case 'status':
        return React.createElement(StatusPanel, {
          ...baseProps,
          character: gameData.character,
          mapData: gameData.mapData,
          playerState: gameData.playerState,
          weatherSystem: gameData.gameCoordinator.weatherService,
          gameCoordinator: gameData.gameCoordinator,
          database: gameData.database,
        });
      case 'actions':
        return React.createElement(ActionsPanel, {
          ...baseProps,
          playerState: gameData.playerState,
          gameWorld: gameData.gameCoordinator,
        });
      case 'log':
        return React.createElement(LogPanel, {
          ...baseProps,
          worldEvents: gameData.worldEvents
        });
      case 'inventory':
        return React.createElement(InventoryPanel, {
          ...baseProps,
          items: gameData.inventorySystem.getItems(),
          database: gameData.database
        });
      case 'quests':
        return React.createElement(QuestPanel, {
          ...baseProps,
          quests: gameData.questSystem.getActiveQuests(),
          database: gameData.database
        });
      case 'skills':
        return React.createElement(SkillsPanel, {
          ...baseProps,
          skillSystem: gameData.gameCoordinator.skillService,
          database: gameData.database
        });
      case 'quest-log':
        return React.createElement(QuestLogPanel, {
            ...baseProps,
            quests: gameData.questSystem.getActiveQuests(),
            completedQuestIds: gameData.questSystem.getCompletedQuestIds(),
            database: gameData.database
        });
      case 'options':
        return React.createElement(OptionsPanel, {
            ...baseProps
        });
      default: 
        const exhaustiveCheck: never = spec.type;
        throw new Error(`Unknown panel type: ${exhaustiveCheck}`);
    }
  }
}