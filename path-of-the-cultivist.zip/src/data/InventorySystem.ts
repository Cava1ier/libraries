

import { RNGSystem } from '../systems/rng/RNGSystem';
// FIX: Module '"../types/AdventureTypes"' has no exported member 'LootEntry'. Added LootEntry to imports.
import { ItemData, LootEntry, ItemType, ItemQuality } from '../types/AdventureTypes';

// Assuming SiteType is defined elsewhere from previous context
enum SiteType { Wilderness = 0, Ruins = 1 }

export class InventorySystem {
  private playerInventory: ItemData[] = [];
  private readonly maxInventorySize = 20;

  constructor(private rng: RNGSystem) {}

  public addItem(item: ItemData): boolean {
    // Branchless inventory check
    const hasSpace = ((this.playerInventory.length - this.maxInventorySize) >> 31) & 1;
    
    if (hasSpace) {
      this.playerInventory.push(item);
      return true;
    }
    return false;
  }

  public removeItem(itemId: string): ItemData | null {
    const index = this.playerInventory.findIndex(item => item.id === itemId);
    return index >= 0 ? this.playerInventory.splice(index, 1)[0] : null;
  }

  public generateLoot(siteType: SiteType): ItemData[] {
    const lootTable = this.getLootTable(siteType);
    const lootCount = (this.rng.next() % 4) + 1;
    const loot: ItemData[] = [];
    
    for (let i = 0; i < lootCount; i++) {
      const roll = this.rng.next() % 100;
      const item = this.rollOnLootTable(lootTable, roll);
      if (item) loot.push(item);
    }
    
    return loot;
  }

  private getLootTable(siteType: SiteType): LootEntry[] {
    const lootTables: LootEntry[][] = [
      // Wilderness (0)
      [
        // FIX: Property 'itemId' is missing in type '{ item: any; ...}'. Changed 'item' to 'itemId'.
        { itemId: ItemType.Stick, weight: 40, minRoll: 0 },
        { itemId: ItemType.Stone, weight: 30, minRoll: 40 },
        { itemId: ItemType.Berry, weight: 20, minRoll: 70 },
        { itemId: ItemType.Herb, weight: 10, minRoll: 90 }
      ],
      // Ruins (1)
      [
        { itemId: ItemType.Coin, weight: 30, minRoll: 0 },
        { itemId: ItemType.IronSword, weight: 15, minRoll: 30 },
        { itemId: ItemType.LeatherArmor, weight: 20, minRoll: 45 },
        { itemId: ItemType.Scroll, weight: 25, minRoll: 65 },
        { itemId: ItemType.Gem, weight: 10, minRoll: 90 }
      ]
    ];
    
    return lootTables[siteType] || lootTables[0];
  }

  private rollOnLootTable(table: LootEntry[], roll: number): ItemData | null {
    for (const entry of table) {
        if (roll >= entry.minRoll && roll < entry.minRoll + entry.weight) {
            return {
                id: `item_${this.rng.next()}`,
                // FIX: 'type' does not exist on ItemData, use 'typeId'. 'item' does not exist on LootEntry, use 'itemId'.
                typeId: entry.itemId,
                quantity: 1,
                // FIX: 'quality' does not exist on ItemData, use 'qualityId'.
                qualityId: ItemQuality.Common
            };
        }
    }
    return null;
  }

  public getItemCount(): number {
      return this.playerInventory.length;
  }

  public getItems(): ItemData[] {
      return this.playerInventory;
  }
}