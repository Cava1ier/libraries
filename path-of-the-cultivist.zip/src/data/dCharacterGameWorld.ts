// FIX: This file is a duplicate of `src/services/GameCoordinatorService.ts`.
// Re-exporting from the canonical source to resolve type conflicts across the application.
export * from '../services/GameCoordinatorService';
