export interface PanelSpec {
  id: string;
  type: 'status' | 'actions' | 'log' | 'inventory' | 'quests' | 'skills' | 'quest-log' | 'options';
  title: string;
}

export const PANEL_SPECS: PanelSpec[] = [
  { id: 'status', type: 'status',     title: 'Cultivator Status' },
  { id: 'actions', type: 'actions',   title: 'Actions & Controls' },
  { id: 'log',   type: 'log',    title: 'Event Log' },
  { id: 'inventory', type: 'inventory', title: 'Inventory' },
  { id: 'quest-log', type: 'quest-log', title: 'Quest Log' },
  { id: 'skills', type: 'skills', title: 'Skills' },
  { id: 'options', type: 'options', title: 'Options' }
];