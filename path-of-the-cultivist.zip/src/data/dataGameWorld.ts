import { GameWorldMapData } from '../components/GameWorld/dataGameWorldMap';
import { Character } from './dCharacter';
import { GameCoordinatorService, GameCoordinatorContext } from '../services/GameCoordinatorService';
import { CombatEncounter, DialogueState, QuestData } from '../types/AdventureTypes';
import { AppData } from '../dataApp';

export class GameWorldData {
    public gameCoordinator: GameCoordinatorService;
    public mapData: GameWorldMapData;
    
    constructor(
        private appData: AppData,
        characterRecord: any,
        savedData: any,
        onCombatStart: (encounter: CombatEncounter | null) => void,
        onDialogueStart: (dialogue: DialogueState) => void,
        onQuestComplete: (quest: QuestData) => void,
        onLevelUp: () => void,
        onCraftingStart: () => void,
        forceUpdate: () => void
    ) {
        const finalCharacterRecord = savedData?.characterData || characterRecord;
        const character = new Character(finalCharacterRecord);
        // FIX: The GameCoordinator now depends on the WorldService, so it should be created after services are registered in AppData
        this.mapData = new GameWorldMapData(character.data, appData.gameState.worldService);

        const context: GameCoordinatorContext = {
            character,
            mapData: this.mapData,
            initialDiscoveredTiles: savedData?.discoveredTiles,
            onUpdate: forceUpdate,
            onCombatStart,
            onDialogueStart,
            onQuestComplete,
            onLevelUp,
            onCraftingStart
        };
        
        appData.createGameWorld(context, savedData);
        this.gameCoordinator = appData.gameCoordinator!;
    }

    public get character(): Character { return this.gameCoordinator.character; }
    public get worldEvents(): any[] { return this.gameCoordinator.eventService.getRecentEvents(50); }
    public get database(): any { return this.gameCoordinator.db; }
    public get trackedQuest(): any | undefined { return this.gameCoordinator.questService.getTrackedQuest(); }
    public get playerState() { return this.gameCoordinator.playerState; }
    public get currentPath() { return this.gameCoordinator.currentPath; }
    public get creatures(): Map<string, any> { return this.gameCoordinator.creatureService.creatures; }
    
    public get inventorySystem() { return this.gameCoordinator.inventoryService; }
    public get questSystem() { return this.gameCoordinator.questService; }
}