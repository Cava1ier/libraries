
import { GameDatabase } from '../systems/database/Database';
import { Faction } from '../types/SocialTypes';

export class dFactionSystem {
    private factions: Map<string, Faction> = new Map();
    private db: GameDatabase;

    constructor(database: GameDatabase) {
        this.db = database;
    }

    public setFactions(factions: Faction[]) {
        const factionTable = this.db.getTable('factions');
        const membersTable = this.db.getTable('faction_members');

        factions.forEach(faction => {
            this.factions.set(faction.id, faction);
            
            const factionRecord = {
                id: faction.id,
                name: faction.name,
                type: faction.type,
                description: faction.description,
                ideology: JSON.stringify(faction.ideology),
                powerLevel: faction.powerLevel,
                territory: JSON.stringify(faction.territory)
            };
            factionTable.insert(factionRecord);

            faction.members.forEach(member => {
                membersTable.insert({
                    factionId: faction.id,
                    characterId: member.characterId,
                    rank: member.rank,
                    loyalty: member.loyalty
                });
            });
        });
    }

    public getFaction(id: string): Faction | undefined {
        return this.factions.get(id);
    }

    public getAllFactions(): Faction[] {
        return Array.from(this.factions.values());
    }
}