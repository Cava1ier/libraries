
import { GameDatabase } from '../systems/database/Database';
import { dQuestSystem } from './dQuestSystem';
import { CreatureData, DialogueState } from '../types/AdventureTypes';

export class dDialogueSystem {
  private db: GameDatabase;
  private questSystem: dQuestSystem;

  constructor(db: GameDatabase, questSystem: dQuestSystem) {
    this.db = db;
    this.questSystem = questSystem;
  }

  public getDialogue(npc: CreatureData): DialogueState {
    const npcId = npc.id.startsWith('npc_') ? npc.id.split('_')[1] : null;
    if (!npcId) {
        return { npc, text: "The creature seems unresponsive.", options: [{ text: "Leave", action: () => {} }] };
    }

    const npcRecord = this.db.getTable('tblNPCs').find(npcId);
    if (!npcRecord) return { npc, text: "...", options: [{ text: "Leave", action: () => {} }] };

    const activeQuests = this.questSystem.getActiveQuests();
    const completedQuests = this.questSystem.getCompletedQuestIds();

    for (const quest of activeQuests) {
        if (quest.end_npc_id == npcRecord.id && this.questSystem.isQuestComplete(quest)) {
            const dialogueText = quest.id == 1 ? npcRecord.dialogue_end_quest_1 : npcRecord.dialogue_start_quest_2;
            return {
                npc,
                text: dialogueText,
                quest,
                options: [{ text: "Complete Quest", action: () => this.questSystem.completeQuest(quest) }]
            };
        }
    }

    const allQuests = this.db.getTable('tblQuests').findAll();
    for (const quest of allQuests) {
        if(quest.start_npc_id == npcRecord.id && !activeQuests.some(q => q.id === quest.id) && !completedQuests.has(quest.id) && (quest.prereq_quest_id === 0 || completedQuests.has(quest.prereq_quest_id))) {
            const dialogueText = quest.id == 1 ? npcRecord.dialogue_start_quest_1 : npcRecord.dialogue_start_quest_2;
            return {
                npc,
                text: dialogueText,
                quest: quest,
                options: [
                    { text: "Accept Quest", action: () => this.questSystem.acceptQuest(quest) },
                    { text: "Decline", action: () => {} }
                ]
            };
        }
    }
    
    const genericDialogue = `Greetings, cultivator. I am ${npc.name}.`;
    return { npc, text: genericDialogue, options: [{ text: "Leave", action: () => {} }] };
  }
}