
import React from 'react';
import { Component } from '../core/Component';
import { PluginManager } from '../systems/plugin/PluginSystem';

interface ErrorPageProps {
    message?: string;
    pluginManager: PluginManager;
}

export class ErrorPage extends Component<ErrorPageProps, {}> {
    prefix = 'error-page';
    
    // FIX: Kept as an arrow function as it's passed directly to onClick.
    handleReturnToMenu = () => {
        this.props.pluginManager.loadPage('menu');
    }

    // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
    render() {
        const message = this.props.message || "An unknown error occurred.";
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('h1', { className: this.cls('title') }, 'A Path Was Lost'),
            React.createElement('p', { className: this.cls('message') }, message),
            React.createElement('button', { className: this.cls('button'), onClick: this.handleReturnToMenu }, 'Return to the Main Menu')
        );
    }
}