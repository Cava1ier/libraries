import { RNGSystem } from '../systems/rng/RNGSystem';
import { CreatureData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';

export class dCreatureSystem {
  public creatures: Map<string, CreatureData> = new Map(); // Key: "x,y,z"
  private db: GameDatabase;
  private rng: RNGSystem;

  constructor(rng: RNGSystem, db: GameDatabase) {
    this.rng = rng;
    this.db = db;
  }

  public spawnCreatureForTile(x: number, y: number, z: number, biome: string) {
    const key = `${x},${y},${z}`;
    if (this.creatures.has(key)) return;

    const spawnChance = 0.05;
    if (this.rng.next() / 1000 > spawnChance) return;

    const creatureTypes = this.db.getTable('tblCreatureTypes').findAll();
    const creatureRecord = creatureTypes[this.rng.nextInRange(0, creatureTypes.length - 1)];
    
    if (creatureRecord.name === 'Villager') return;

    const creature: CreatureData = {
      id: `c_${x}_${y}_${z}`,
      typeId: creatureRecord.id,
      name: creatureRecord.name,
      isHostile: creatureRecord.isHostile === 1,
      stats: {
        health: creatureRecord.health,
        maxHealth: creatureRecord.health,
        attack: creatureRecord.attack,
        defense: creatureRecord.defense,
        speed: creatureRecord.speed,
        energy: 100,
      },
      position: { x, y, z },
    };
    this.creatures.set(key, creature);
  }
  
  public spawnNpcById(npcId: number, x: number, y: number, z: number) {
      const key = `${x},${y},${z}`;
      const npcRecord = this.db.getTable('tblNPCs').find(npcId);
      const creatureType = this.db.getTable('tblCreatureTypes').find(6); // Villager

      const creature: CreatureData = {
        id: `npc_${npcId}`,
        typeId: creatureType.id,
        name: npcRecord.name,
        isHostile: false,
        stats: { ...creatureType, maxHealth: creatureType.health, energy: 100 },
        position: { x, y, z },
      };
      this.creatures.set(key, creature);
  }

  public getCreatureAt(x: number, y: number, z: number): CreatureData | undefined {
    return this.creatures.get(`${x},${y},${z}`);
  }

  public removeCreature(creature: CreatureData) {
    this.creatures.delete(`${creature.position.x},${creature.position.y},${creature.position.z}`);
  }
}
