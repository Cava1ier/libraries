export interface TabSpec {
  id: string;
  label: string;
  panelId: string;
  icon: string;
}

export const TAB_SPECS: TabSpec[] = [
  { id: 't1', label: 'Status',     panelId: 'status',    icon: '👤' },
  { id: 't2', label: 'Actions',    panelId: 'actions',   icon: '⚡' },
  { id: 't3', label: 'Log',        panelId: 'log',       icon: '📜' },
  { id: 't4', label: 'Inventory',  panelId: 'inventory', icon: '🎒' },
  { id: 't7', label: 'Quest Log',  panelId: 'quest-log', icon: '📓' },
  { id: 't6', label: 'Skills',     panelId: 'skills',    icon: '⭐' },
  { id: 't8', label: 'Options',    panelId: 'options',   icon: '⚙️' }
];