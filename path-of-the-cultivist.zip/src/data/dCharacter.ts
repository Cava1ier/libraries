
export class Character {
    public id: number;
    public data: any;

    constructor(characterRecord: any) {
        if (!characterRecord) {
            throw new Error("Cannot create Character: characterRecord is null or undefined.");
        }
        this.id = characterRecord.id;
        this.data = characterRecord;
        if (this.data.experience === undefined) this.data.experience = 0;
        if (this.data.attribute_points === undefined) this.data.attribute_points = 0;
    }

    get x(): number { return this.data.x; }
    get y(): number { return this.data.y; }
    get z(): number { return this.data.z; }
    
    setPosition(x: number, y: number, z: number) {
        this.data.x = x;
        this.data.y = y;
        this.data.z = z;
    }

    get name(): string { return this.data.name || 'Nameless'; }
    get realm(): string { return this.data.realm || 'Mortal'; }

    get qi_points(): number { return this.data.qi_points; }
    set qi_points(value: number) { this.data.qi_points = value; }
    
    get max_qi_points(): number { return this.data.max_qi_points || 1000; }

    get body_tempering(): number { return this.data.body_tempering; }
    get soul_strength(): number { return this.data.soul_strength; }
    get dao_comprehension(): number { return this.data.dao_comprehension; }

    get ocean_o(): number { return this.data.ocean_o; }
    get ocean_c(): number { return this.data.ocean_c; }
    get ocean_e(): number { return this.data.ocean_e; }
    get ocean_a(): number { return this.data.ocean_a; }
    get ocean_n(): number { return this.data.ocean_n; }

    get experience(): number { return this.data.experience || 0; }
    set experience(value: number) { this.data.experience = value; }
    
    get attribute_points(): number { return this.data.attribute_points || 0; }
    set attribute_points(value: number) { this.data.attribute_points = value; }

    get cultivation_level(): number { return this.data.cultivation_level || 1; }
    set cultivation_level(value: number) { this.data.cultivation_level = value; }

    getExperienceForNextLevel(): number {
        return Math.floor(Math.pow(this.cultivation_level, 1.5) * 100);
    }
    
    addExperience(amount: number): { leveledUp: boolean, newLevel?: number } {
        if (amount <= 0) return { leveledUp: false };

        this.experience += amount;
        let leveledUp = false;
        
        while (this.experience >= this.getExperienceForNextLevel()) {
            leveledUp = true;
            this.experience -= this.getExperienceForNextLevel();
            this.cultivation_level += 1;
            this.attribute_points += 5;
        }
        
        return { leveledUp, newLevel: this.cultivation_level };
    }

    spendAttributePoint(stat: string): boolean {
        if (this.attribute_points > 0) {
            if (stat in this.data) {
                this.data[stat] += 1;
                this.attribute_points -= 1;
                
                // Recalculate derived stats
                if (stat === 'body_tempering') this.data.attack = 5 + Math.floor(this.data.body_tempering / 5);
                if (stat === 'physical_resilience') this.data.defense = 5 + Math.floor(this.data.physical_resilience / 10);
                if (stat === 'fate_threads') this.data.speed = 5 + Math.floor(this.data.fate_threads / 10);
                return true;
            }
        }
        return false;
    }
}