import { BaseTab } from './BaseTab';

export class TabSystem {
    private tabs: BaseTab[] = [];
    private activeTabId: string;

    constructor(tabs: BaseTab[], initialTabId?: string) {
        this.tabs = tabs;
        this.activeTabId = initialTabId || (tabs.length > 0 ? tabs[0].id : '');
    }

    public getTabs(): BaseTab[] {
        return this.tabs;
    }

    public setActiveTab(tabId: string): void {
        if (this.tabs.some(t => t.id === tabId)) {
            this.activeTabId = tabId;
        }
    }

    public getActiveTab(): BaseTab | undefined {
        return this.tabs.find(t => t.id === this.activeTabId);
    }
    
    public getActiveTabId(): string {
        return this.activeTabId;
    }
}