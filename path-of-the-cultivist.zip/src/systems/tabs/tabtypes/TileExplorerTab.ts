import React from 'react';
import { BaseTab, TabRenderProps } from '../BaseTab';

export class TileExplorerTab extends BaseTab {
    constructor() {
        super('inspect', 'Inspect');
    }

    render(props: TabRenderProps): React.ReactNode {
        const { cls, data } = props;
        const { inspectedTile } = data.mapData;

        const content = inspectedTile ? [
            React.createElement('p', { key: 'biome', className: cls('stat-text') }, `Biome: ${inspectedTile.biome}`),
            React.createElement('p', { key: 'type', className: cls('stat-text') }, `Type: ${inspectedTile.type}`),
            React.createElement('p', { key: 'coords', className: cls('stat-text') }, `Coords: (X: ${inspectedTile.x}, Y: ${inspectedTile.y}, Z: ${inspectedTile.z})`),
        ] : [React.createElement('p', { className: cls('stat-text') }, 'Use \'l\' to enter look mode and move the cursor to inspect tiles.')];
        
        return React.createElement('div', { className: cls('panel-scrollable') },
            React.createElement('h3', { className: cls('panel-title') }, 'Inspect Tile'),
            ...content
       );
    }
}