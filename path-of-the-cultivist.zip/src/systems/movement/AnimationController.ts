
import { MovementConfig } from './MovementTypes';
import { Position } from '../generation/character/Character.types';

export class AnimationController {
  private animationId: number = 0;
  private isAnimating: boolean = false;
  public onStep: ((position: Position) => void) | null = null; // Callback for external systems

  constructor(private config: MovementConfig) {}

  public startPathAnimation(
    path: Position[],
    executeStep: (position: Position, stepIndex: number) => Promise<boolean>,
    onComplete: () => void,
    onError: (error: string) => void
  ) {
    if (this.isAnimating) {
      this.stopAnimation();
    }

    this.isAnimating = true;
    let currentStep = 0;

    const animateStep = async () => {
      if (!this.isAnimating || currentStep >= path.length) {
        this.stopAnimation();
        onComplete();
        return;
      }

      const nextPos = path[currentStep];
      const moveSuccessful = await executeStep(nextPos, currentStep);

      if (!moveSuccessful) {
        this.stopAnimation();
        onError("Movement interrupted");
        return;
      }
      
      // Notify external listeners that a step has been taken
      if (this.onStep) {
          this.onStep(nextPos);
      }

      currentStep++;
      this.animationId = setTimeout(animateStep, this.config.animationSpeed) as any;
    };

    animateStep();
  }

  public stopAnimation() {
    this.isAnimating = false;
    clearTimeout(this.animationId);
  }

  public get isRunning(): boolean {
    return this.isAnimating;
  }
}