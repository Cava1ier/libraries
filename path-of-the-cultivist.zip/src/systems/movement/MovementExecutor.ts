



// FIX: Replaced `WorldSystem` with `WorldService` to align with the application's service-oriented architecture and resolve type mismatches.
import { WorldService } from '../../services/WorldService';
// FIX: Replaced dInventorySystem with InventoryService to match the new architecture.
import { InventoryService } from '../../services/InventoryService';
// FIX: Replaced dQuestSystem with QuestService to match the new architecture.
import { QuestService } from '../../services/QuestService';
import { GameDatabase } from '../database/Database';
import { Character } from '../../data/dCharacter';
import { Position } from '../generation/character/Character.types';
import { dSkillSystem } from '../../data/dSkillSystem';
import { ActionContext } from '../tiles/BaseTile';
// FIX: Imported DatabaseService to be used in constructor.
import { DatabaseService } from '../../services/DatabaseService';
import { SkillService } from '../../services/SkillService';

export class MovementExecutor {
  constructor(
    private worldSystem: WorldService,
    private inventorySystem: InventoryService,
    private questSystem: QuestService,
    // FIX: Changed parameter type from GameDatabase to DatabaseService to match application architecture.
    private database: DatabaseService,
    // FIX: Changed parameter type from dSkillSystem to SkillService to match application architecture.
    private skillSystem: SkillService,
  ) {}

  public executeMovement(
    character: Character,
    targetPos: Position
  ): { success: boolean; events: string[] } {
    const events: string[] = [];
    const tile = this.worldSystem.getTile(targetPos.x, targetPos.y, targetPos.z);
    
    if (!tile) {
      return { success: false, events: ["Invalid tile"] };
    }
    
    const context: ActionContext = {
      skillSystem: this.skillSystem as any // Cast to any to satisfy BaseTile, as SkillService has a compatible interface
    };

    const moveResult = tile.onEnter(character.data, context);
    
    if (!moveResult.success) {
      events.push(moveResult.event || "Movement failed");
      return { success: false, events };
    }

    if (moveResult.inventoryAdd) {
      this.handleInventoryAddition(moveResult.inventoryAdd, events);
    }

    if (moveResult.characterUpdates) {
      Object.assign(character.data, moveResult.characterUpdates);
    }

    const finalPosition = moveResult.newPosition || targetPos;
    character.setPosition(finalPosition.x, finalPosition.y, finalPosition.z);
    
    events.push(`Moved to (${finalPosition.x}, ${finalPosition.y}, ${finalPosition.z})`);
    
    return { success: true, events };
  }

  private handleInventoryAddition(
    inventoryAdd: { itemName: string; quantity: number }, 
    events: string[]
  ) {
    const [itemRecord] = this.database.getTable('tblItems').query((r: any) => r.name === inventoryAdd.itemName);
    if (itemRecord) {
      this.inventorySystem.addItem(itemRecord.id, inventoryAdd.quantity, 2); // Common Quality
      this.questSystem.updateProgress('COLLECT', itemRecord.name, inventoryAdd.quantity);
      events.push(`Found ${inventoryAdd.quantity} ${itemRecord.name}`);
    }
  }
}