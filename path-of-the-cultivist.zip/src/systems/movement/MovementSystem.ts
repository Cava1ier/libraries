





import { Character } from '../../data/dCharacter';
// FIX: Replaced `WorldSystem` with `WorldService` to align with the service-oriented architecture.
import { WorldService } from '../../services/WorldService';
import { dCreatureSystem } from '../../data/dCreatureSystem';
// FIX: Replaced `PathfindingSystem` with `PathfindingService` to resolve type mismatches.
import { PathfindingService } from '../../services/PathfindingService';
// FIX: Changed dInventorySystem to InventoryService to align with the application's service architecture.
import { InventoryService } from '../../services/InventoryService';
// FIX: Changed dQuestSystem to QuestService to align with the application's service architecture.
import { QuestService } from '../../services/QuestService';
import { GameDatabase } from '../database/Database';
import { PathfindingResult, MovementValidationResult } from './MovementTypes';
import { Position } from '../generation/character/Character.types';
import { Pathfinder } from './Pathfinder';
import { MovementValidator } from './MovementValidator';
import { MovementExecutor } from './MovementExecutor';
import { AnimationController } from './AnimationController';
import { GameConfiguration } from '../world/character/managers/ConfigurationManager';
import { DatabaseService } from '../../services/DatabaseService';
// FIX: Changed dSkillSystem to SkillService to align with the application's service architecture.
import { SkillService } from '../../services/SkillService';

export class MovementSystem {
  public pathfinder: Pathfinder;
  public validator: MovementValidator;
  public executor: MovementExecutor;
  public animator: AnimationController;
  private config: GameConfiguration['movement'];

  constructor(
    private character: Character,
    worldSystem: WorldService,
    creatureSystem: dCreatureSystem,
    pathfindingSystem: PathfindingService,
    // FIX: Updated parameter types to match the expected types in MovementExecutor.
    inventorySystem: InventoryService,
    questSystem: QuestService,
    // FIX: Changed parameter type from GameDatabase to DatabaseService to resolve type error.
    database: DatabaseService,
    skillSystem: SkillService,
    config: GameConfiguration['movement']
  ) {
    this.config = config;
    this.pathfinder = new Pathfinder(pathfindingSystem);
    this.validator = new MovementValidator(worldSystem, creatureSystem, skillSystem);
    this.executor = new MovementExecutor(
      worldSystem,
      inventorySystem,
      questSystem,
      database,
      skillSystem
    );
    this.animator = new AnimationController(config);
  }

  public async moveTo(position: Position): Promise<MovementValidationResult> {
    const validation = this.validator.validateMovement(
      this.character,
      position,
      this.character.data
    );

    if (!validation.success) {
      return validation;
    }

    const result = this.executor.executeMovement(this.character, position);
    
    return {
      success: result.success,
      blockedBy: 'none'
    };
  }

  public followPath(path: Position[]): Promise<MovementValidationResult> {
    return new Promise((resolve) => {
        let lastMoveResult: MovementValidationResult | null = null;
        this.animator.startPathAnimation(
            path,
            async (position, stepIndex) => {
                const moveResult = await this.moveTo(position);
                lastMoveResult = moveResult;
                return moveResult.success;
            },
            () => { // onComplete
                resolve({ success: true, blockedBy: 'none' });
            },
            (error) => { // onError
                resolve(lastMoveResult || { success: false, blockedBy: 'terrain', reason: error });
            }
        );
    });
  }

  public findPathTo(target: Position): PathfindingResult {
    return this.pathfinder.findPath(this.character, target, this.config.maxPathLength);
  }

  public stopMovement() {
    this.animator.stopAnimation();
  }

  public isMoving(): boolean {
      return this.animator.isRunning;
  }

  public findNearestUnexplored(discoveredTiles: Set<string>): Position | null {
    const { x, y, z } = this.character;
    const autoExploreRadius = this.config.autoExploreRadius;
    
    for (let r = 1; r < autoExploreRadius; r++) {
      for (let i = -r; i <= r; i++) {
        for (let j = -r; j <= r; j++) {
          if (Math.abs(i) !== r && Math.abs(j) !== r) continue;

          const checkX = x + i;
          const checkY = y + j;
          if (!discoveredTiles.has(`${checkX},${checkY}`)) {
            return { x: checkX, y: checkY, z };
          }
        }
      }
    }
    return null;
  }
}