import { StyleRegistry } from '../css/StyleRegistry';

export class AppComponentLoader {
    public static styleRegistry = new StyleRegistry('cultivist');
}
