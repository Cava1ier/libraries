



// FIX: Use `import type` to break a circular dependency between the base command and the main game world class, preventing type resolution failures.
// FIX: Changed dCharacterGameWorld to GameCoordinatorService to align with the new architecture.
import type { GameCoordinatorService } from '../../../../services/GameCoordinatorService';
import { EventSystem } from '../events/EventSystem';

export interface GameCommand {
  execute(): Promise<void> | void;
  undo?(): Promise<void> | void;
  canExecute(): boolean;
  description: string;
}

export abstract class BaseGameCommand implements GameCommand {
  constructor(
    // FIX: Changed dCharacterGameWorld to GameCoordinatorService.
    protected gameWorld: GameCoordinatorService, 
    protected eventSystem: EventSystem
  ) {}

  abstract execute(): Promise<void> | void;
  abstract canExecute(): boolean;
  abstract description: string;
}
