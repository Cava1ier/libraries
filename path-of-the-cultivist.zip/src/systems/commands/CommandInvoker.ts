
import { GameCommand } from './GameCommand';

export class CommandInvoker {
  private history: GameCommand[] = [];
  private currentIndex: number = -1;
  private maxHistorySize: number = 50;

  public async executeCommand(command: GameCommand): Promise<void> {
    if (!command.canExecute()) {
      console.warn(`Cannot execute command: ${command.description}`);
      return;
    }

    await command.execute();

    this.history = this.history.slice(0, this.currentIndex + 1);
    this.history.push(command);
    this.currentIndex++;

    if (this.history.length > this.maxHistorySize) {
      this.history.shift();
      this.currentIndex--;
    }
  }

  public async undo(): Promise<boolean> {
    if (this.currentIndex < 0) return false;

    const command = this.history[this.currentIndex];
    if (command.undo) {
      await command.undo();
      this.currentIndex--;
      return true;
    }

    return false;
  }

  public canUndo(): boolean {
    return this.currentIndex >= 0 && !!this.history[this.currentIndex]?.undo;
  }

  public getHistory(): GameCommand[] {
    return [...this.history];
  }

  public clearHistory(): void {
    this.history = [];
    this.currentIndex = -1;
  }
}
