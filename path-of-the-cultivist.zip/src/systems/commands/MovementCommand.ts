



// FIX: Use `import type` to break a circular dependency between the movement command and the main game world class, ensuring correct type inference.
// FIX: Changed dCharacterGameWorld to GameCoordinatorService to align with the new architecture.
import type { GameCoordinatorService } from '../../../../services/GameCoordinatorService';
import { EventSystem } from '../events/EventSystem';
import { BaseGameCommand } from './GameCommand';

export class MovementCommand extends BaseGameCommand {
  private originalPosition?: { x: number; y: number; z: number };

  constructor(
    // FIX: Changed dCharacterGameWorld to GameCoordinatorService.
    gameWorld: GameCoordinatorService,
    eventSystem: EventSystem,
    private targetPosition: { x: number; y: number; z: number }
  ) {
    super(gameWorld, eventSystem);
  }

  get description(): string {
    return `Move to (${this.targetPosition.x}, ${this.targetPosition.y})`;
  }

  canExecute(): boolean {
    return this.gameWorld.movementController.canMove();
  }

  async execute(): Promise<void> {
    if (!this.canExecute()) {
      this.eventSystem.addEvent('system', 'Cannot move now', 'Player is busy.');
      return;
    }

    const char = this.gameWorld.character;
    this.originalPosition = { x: char.x, y: char.y, z: char.z };

    this.gameWorld.movementController.handleMapClick(
      this.targetPosition.x,
      this.targetPosition.y
    );

    this.eventSystem.addEvent(
      'movement',
      'Movement initiated',
      `Moving to (${this.targetPosition.x}, ${this.targetPosition.y})`
    );
  }

  async undo(): Promise<void> {
    if (!this.originalPosition) return;

    this.gameWorld.character.setPosition(
      this.originalPosition.x,
      this.originalPosition.y,
      this.originalPosition.z
    );
    this.gameWorld.updateAndRender();

    this.eventSystem.addEvent(
      'movement',
      'Movement undone',
      `Returned to (${this.originalPosition.x}, ${this.originalPosition.y})`
    );
  }
}
