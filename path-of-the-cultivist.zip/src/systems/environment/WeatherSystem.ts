
import { RNGSystem } from '../rng/RNGSystem';

export enum Season { Spring, Summer, Autumn, Winter }
export enum WeatherType { Clear, Cloudy, Rain, Storm, Fog, Snow }

export interface GameTime {
    year: number;
    season: Season;
    day: number;
    hour: number;
}

export interface WeatherState {
    type: WeatherType;
    intensity: number; // 0-100
}

export class WeatherSystem {
    private time: GameTime;
    private weather: WeatherState;
    private rng: RNGSystem;

    constructor(rng: RNGSystem) {
        this.rng = rng;
        this.time = { year: 1, season: Season.Spring, day: 1, hour: 8 };
        this.weather = { type: WeatherType.Clear, intensity: 100 };
    }

    public advanceTime(hours: number) {
        this.time.hour += hours;
        if (this.time.hour >= 24) {
            this.time.hour %= 24;
            this.time.day++;
        }
        if (this.time.day > 90) { // 90 days per season
            this.time.day = 1;
            this.time.season = (this.time.season + 1) % 4;
            if (this.time.season === Season.Spring) {
                this.time.year++;
            }
        }
        this.updateWeather();
    }
    
    private updateWeather() {
        if (this.rng.nextInRange(0, 100) < 20) { // 20% chance to change weather
            const weatherTypes = Object.values(WeatherType).filter(v => typeof v === 'number') as number[];
            const newWeatherType = this.rng.nextInRange(0, weatherTypes.length - 1);
            this.weather.type = newWeatherType;
            this.weather.intensity = this.rng.nextInRange(20, 100);
        }
    }

    public getTime(): GameTime {
        return { ...this.time };
    }
    
    public getWeather(): WeatherState {
        return { ...this.weather };
    }
    
    public getFormattedTime(): string {
        return `Year ${this.time.year}, ${Season[this.time.season]}, Day ${this.time.day}, ${String(this.time.hour).padStart(2, '0')}:00`;
    }
    
    public getFormattedWeather(): string {
        return `${WeatherType[this.weather.type]}`;
    }

    public setTime(time: GameTime) {
        this.time = time;
    }
}
