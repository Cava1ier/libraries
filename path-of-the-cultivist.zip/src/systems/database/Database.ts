

export class DatabaseTable {
 public tableName: string;
 public columns: string[];
 public records: any[];
 private nextId: number;

 constructor(tableName: string, columns:string[]) {
  this.tableName = tableName;
  this.columns = columns;
  this.records = [];
  this.nextId = 1;
 }
 
 addRecord(record: any) {
    this.records.push(record);
 }

 insert(data: any) {
  const record = { id: this.nextId++, ...data };
  this.records.push(record);
  return record.id;
 }
 
 find(id: number | string) {
    const numericId = Number(id);
    if (isNaN(numericId)) {
        return this.records.find(r => r.id === id);
    }
    return this.records.find(r => Number(r.id) === numericId);
 }
 
 findAll() {
  return [...this.records];
 }

 query(filterFn: (record: any) => boolean) {
    return this.records.filter(filterFn);
 }
 
 toString() {
  let result = ':' + this.tableName + ':id|' + this.columns.join('|') + ':\n';
  this.records.forEach(record => {
   const values = [record.id, ...this.columns.map(col => record[col] || '')];
   result += ':' + values.join('|') + ':\n';
  });
  return result;
 }
}

export class GameDatabase {
 public tables: { [key: string]: DatabaseTable };
 constructor() {
  this.tables = {};
  this.initializeDynamicTables();
 }
 
 initializeDynamicTables() {
  this.tables.characters = new DatabaseTable('characters', [
   'name', 'realm', 'cultivation_level', 'qi_points', 'body_tempering', 'soul_strength',
   'dao_comprehension', 'spiritual_roots', 'meridian_purity', 'elemental_affinity',
   'karmic_burden', 'heavenly_tribulation', 'fate_threads', 'ocean_o', 'ocean_c',
   'ocean_e', 'ocean_a', 'ocean_n', 
   'conflict_strength', 'conflict_like_1', 'conflict_like_2', 'conflict_abhor',
   'story_archetype',
   'x', 'y', 'z', 'spiritual_roots_value', 'mental_fortitude', 'physical_resilience',
   'experience', 'attribute_points'
  ]);
  
  this.tables.events = new DatabaseTable('events', [
   'character_id', 'location_id', 'event_type', 'description', 'timestamp',
   'consequences', 'story_impact'
  ]);
  
  this.tables.cultivation_techniques = new DatabaseTable('cultivation_techniques', [
   'name', 'grade', 'element', 'requirements', 'effects', 'side_effects'
  ]);

  this.tables.factions = new DatabaseTable('factions', [
    'name', 'type', 'description', 'ideology', 'powerLevel', 'territory'
  ]);

  this.tables.faction_members = new DatabaseTable('faction_members', [
    'factionId', 'characterId', 'rank', 'loyalty'
  ]);

  this.tables.relationships = new DatabaseTable('relationships', [
    'sourceCharacterId', 'targetCharacterId', 'type', 'strength'
  ]);

  this.tables.world_sites = new DatabaseTable('world_sites', [
    'x', 'y', 'z', 'type', 'name', 'properties'
  ]);
  
  this.tables.world_creatures = new DatabaseTable('world_creatures', [
    'x', 'y', 'z', 'typeId'
  ]);
  
  this.tables.recipes = new DatabaseTable('recipes', [
    'name', 'result_item_id', 'result_quantity', 
    'req_item_id_1', 'req_quantity_1', 'req_item_id_2', 'req_quantity_2'
  ]);
 }
 
 getTable(name: string) {
  return this.tables[name];
 }

 private _parseAndLoadTable(content: string) {
    const lines = content.trim().replace(/\r/g, '').split('\n').filter(line => line.trim().startsWith(':'));
    if (lines.length === 0) return;

    const headerMatch = lines[0].match(/^:([^:]+):([^:]+):$/);
    if (!headerMatch) {
        console.warn('Invalid table header format:', lines[0]);
        return;
    }
    
    const tableName = headerMatch[1];
    const columnNames = headerMatch[2].split('|');
    const table = new DatabaseTable(tableName, columnNames.filter(c => c !== 'id')); // id is handled by insert

    for (let i = 1; i < lines.length; i++) {
        const rowMatch = lines[i].match(/^:(.*):$/);
        if (!rowMatch) continue;

        const values = rowMatch[1].split('|');
        const record: { [key: string]: any } = {};
        
        // Start from index 1 to skip manual ID
        columnNames.forEach((colName, index) => {
            const value = values[index] || '';
            // Attempt to parse numbers, but keep IDs and version-like strings as strings
            if (!isNaN(Number(value)) && value.trim() !== '' && !value.includes('.') && colName.toLowerCase() !== 'id' && colName.toLowerCase() !== 'name') {
                record[colName] = parseInt(value, 10);
            } else if (!isNaN(parseFloat(value)) && value.trim() !== '' && !value.includes(':')) {
                 record[colName] = parseFloat(value);
            }
            else {
                record[colName] = value;
            }
        });
        
        // Manually handle ID from file if present
        const idFromFile = values[columnNames.indexOf('id')];
        if (idFromFile) {
            record.id = idFromFile;
        }

        table.addRecord(record);
    }
    this.tables[tableName] = table;
 }

 public async loadDatabase() {
    const fileNames = [
        'Alignments.txt', 'Beasts.txt', 'Civilizations.txt', 'Items.txt', 'NamingRules.txt',
        'Nouns.txt', 'PersonRoles.txt', 'Places.txt', 'PreNameAdjectives.txt', 'QuestOriginations.txt',
        'Ranks.txt', 'Suffixes.txt', 'Verbs.txt',
        // Add the new enum-based tables to be loaded
        'AIGoalTypes.txt', 'CreatureTypes.txt', 'GameStates.txt', 'ItemQualities.txt', 'ItemTypes.txt',
        'MovementPatterns.txt', 'QuestTypes.txt', 'SkillTypes.txt',
        // Add questionnaire data
        'OCEANQuestions.txt',
        'OCEANAnswers.txt',
        // Add new world-building data
        'Quests.txt', 'NPCs.txt', 'CreatureTypes.txt', 'TerrainTypes.txt', 'Biomes.txt',
        // Add conflict and progression data
        'OCEAN_ConflictMapping.txt',
        'Breakthroughs.txt',
        'ConflictNarratives.txt',
        // Add combat data
        'CombatSkills.txt',
        'ItemCombatEffects.txt',
        'Recipes.txt',
    ];

    for (const fileName of fileNames) {
        try {
            const response = await fetch(`./database/${fileName}`);
            if (!response.ok) {
                console.error(`Failed to load ${fileName}: ${response.statusText}`);
                continue;
            }
            const content = await response.text();
            this._parseAndLoadTable(content);
        } catch (error) {
            console.error(`Error loading or parsing ${fileName}:`, error);
        }
    }
 }
}