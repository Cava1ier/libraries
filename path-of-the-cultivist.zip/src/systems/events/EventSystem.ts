
import { GameWorldCallbacks } from '../world/character/CharacterWorld.types';
import { PluginManager } from '../plugin/PluginSystem';

export interface GameEvent {
  id: string;
  type: 'movement' | 'combat' | 'interaction' | 'system' | 'quest';
  title: string;
  description: string;
  timestamp: number;
  data?: any;
}

export class EventSystem {
  private events: GameEvent[] = [];
  private maxEvents: number = 100;
  private pluginManager: PluginManager | null = null;

  constructor(private callbacks: GameWorldCallbacks) {}

  public setPluginManager(manager: PluginManager) {
    this.pluginManager = manager;
  }

  public addEvent(
    type: GameEvent['type'],
    title: string, 
    description: string = "",
    data?: any
  ): GameEvent {
    const event: GameEvent = {
      id: this.generateEventId(),
      type,
      title,
      description,
      timestamp: Date.now(),
      data
    };

    this.events.unshift(event);
    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(0, this.maxEvents);
    }

    this.callbacks.addEvent(title, description);

    if (this.pluginManager) {
        this.pluginManager.notifyPlugins(event);
    }
    
    return event;
  }

  public getRecentEvents(count: number = 10): GameEvent[] {
    return this.events.slice(0, count);
  }

  public getEventsByType(type: GameEvent['type']): GameEvent[] {
    return this.events.filter(event => event.type === type);
  }

  public clearEvents() {
    this.events = [];
  }

  private generateEventId(): string {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}
