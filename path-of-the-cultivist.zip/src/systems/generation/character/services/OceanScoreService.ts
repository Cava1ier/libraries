
import { RNGService } from '../../../../services/RNGService';
import { OceanScores } from '../Character.types';
import { CharacterConstants } from '../Character.constants';

export class OceanScoreService {
    constructor(private rng: RNGService) {}

    public generateOrValidate(providedScores?: Partial<OceanScores>): OceanScores {
        const { min, range } = CharacterConstants.OCEAN_RANGE;

        const scores: OceanScores = {
            o: providedScores?.o ?? min + (this.rng.next() % range),
            c: providedScores?.c ?? min + (this.rng.next() % range),
            e: providedScores?.e ?? min + (this.rng.next() % range),
            a: providedScores?.a ?? min + (this.rng.next() % range),
            n: providedScores?.n ?? min + (this.rng.next() % range),
        };

        Object.keys(scores).forEach(key => {
            const scoreKey = key as keyof OceanScores;
            if (scores[scoreKey] > 100) scores[scoreKey] = 100;
            if (scores[scoreKey] < 0) scores[scoreKey] = 0;
        });

        return scores;
    }
}
