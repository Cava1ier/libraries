
import { OceanScores } from '../Character.types';
import { CharacterConstants } from '../Character.constants';

export class ArchetypeService {
    constructor() {}

    public generateArchetype(oceanScores: OceanScores, conflictType: string): string {
        const baseArchetype = this.determineBaseArchetype(oceanScores);
        return this.applyConflictModifier(baseArchetype, conflictType);
    }
    
    private determineBaseArchetype(oceanScores: OceanScores): string {
        const { high, low } = CharacterConstants.ARCHETYPE_THRESHOLDS;
        const o = { high: oceanScores.o > high, low: oceanScores.o < low };
        const c = { high: oceanScores.c > high, low: oceanScores.c < low };
        const e = { high: oceanScores.e > high, low: oceanScores.e < low };
        const a = { high: oceanScores.a > high, low: oceanScores.a < low };
        const n = { high: oceanScores.n > high, low: oceanScores.n < low };

        if (o.high && c.high) return 'Methodical Pioneer';
        else if (e.high && a.high) return 'Benevolent Diplomat';
        else if (c.high && a.low) return 'Ruthless Tactician';
        else if (e.high && n.high) return 'Passionate Fury';
        else if (o.low && c.low) return 'Unfettered Drifter';
        else if (a.low && n.high) return 'Paranoid Schemer';
        else if (o.high && e.high) return 'Inquisitive Explorer';
        else if (c.high && n.low) return 'Iron-Willed Guardian';
        else if (o.high) return 'Visionary Sage';
        else if (c.high) return 'Disciplined Master';
        else if (e.high) return 'Charming Hero';
        else if (a.high) return 'Harmonious Saint';
        else if (n.high) return 'Tortured Genius';
        else return 'Balanced Wanderer';
    }

    private applyConflictModifier(baseArchetype: string, conflictType: string): string {
        switch (conflictType) {
            case 'Man vs Self': return `Introspective ${baseArchetype}`;
            case 'Man vs Man': return `Rivalrous ${baseArchetype}`;
            case 'Man vs Society': return `Rebellious ${baseArchetype}`;
            case 'Man vs Nature': return `Survivalist ${baseArchetype}`;
            case 'Man vs Technology': return `Experimental ${baseArchetype}`;
            case 'Man vs Supernatural': return `Harbinger ${baseArchetype}`;
            case 'Man vs Fate': return `Destined ${baseArchetype}`;
            default: return baseArchetype;
        }
    }
}
