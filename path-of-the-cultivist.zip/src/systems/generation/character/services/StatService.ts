
import { RNGService } from '../../../../services/RNGService';
import { OceanScores, CharacterStats } from '../Character.types';
import { StatCalculatorFactory } from '../factories/StatCalculatorFactory';

export class StatService {
    private calculatorFactory: StatCalculatorFactory;

    constructor(private rng: RNGService) {
        this.calculatorFactory = new StatCalculatorFactory(rng);
    }

    public generateStats(oceanScores: OceanScores, spiritual_roots: string): CharacterStats {
        const soulStrength = this.calculatorFactory.getCalculator('soul_strength')?.calculate(oceanScores) ?? 10;
        const karmicBurden = this.calculatorFactory.getCalculator('karmic_burden')?.calculate(oceanScores) ?? 50;
        const fateThreads = this.calculatorFactory.getCalculator('fate_threads')?.calculate(oceanScores) ?? 10;
        
        const bodyTempering = 10 + Math.floor(oceanScores.c * 0.8) + (this.rng.next() % 16);
        const physicalResilience = 20 + (this.rng.next() % 81);
        const qiPoints = 400 + Math.floor(oceanScores.e * 6) + (this.rng.next() % 51);

        const stats: CharacterStats = {
            cultivation_level: 1,
            spiritual_roots: spiritual_roots,
            soul_strength: soulStrength,
            karmic_burden: karmicBurden,
            fate_threads: fateThreads,
            qi_points: qiPoints,
            max_qi_points: qiPoints,
            body_tempering: bodyTempering,
            dao_comprehension: 10 + Math.floor(oceanScores.o * 0.8) + (this.rng.next() % 16),
            meridian_purity: 15 + Math.floor(oceanScores.c * 0.8) + (this.rng.next() % 11),
            elemental_affinity: 10 + Math.floor(oceanScores.o * 0.6) + (this.rng.next() % 26),
            heavenly_tribulation: 10 + Math.floor(oceanScores.n * 0.9) + (this.rng.next() % 11),
            spiritual_roots_value: 20 + (this.rng.next() % 81),
            mental_fortitude: 20 + (this.rng.next() % 81),
            physical_resilience: physicalResilience,
            attack: 5 + Math.floor(bodyTempering / 5),
            defense: 5 + Math.floor(physicalResilience / 10),
            speed: 5 + Math.floor(oceanScores.e / 15),
        };
        
        return stats;
    }
}