
import { DatabaseService } from '../../../../services/DatabaseService';
import { RNGService } from '../../../../services/RNGService';

export class NameService {
    constructor(private db: DatabaseService, private rng: RNGService) {}

    public generateName(ruleType: string = 'tblPersons'): string {
        const namingRulesTable = this.db.getTable('tblNamingRules');
        if (!namingRulesTable) return 'Nameless One';

        const ruleRecord = namingRulesTable.query(rule => rule.type === ruleType)[0];
        if (!ruleRecord || !ruleRecord.pattern) return 'Unruled One';

        const pattern = ruleRecord.pattern;
        const partTableNames = pattern.split('+');
        
        const nameParts: string[] = [];
        partTableNames.forEach((tableName: string) => {
            const partTable = this.db.getTable(tableName);
            if (partTable) {
                const records = partTable.findAll();
                if (records.length > 0) {
                    const randomIndex = this.rng.next() % records.length;
                    const randomRecord = records[randomIndex];
                    if (randomRecord && randomRecord.name) {
                        nameParts.push(randomRecord.name);
                    }
                }
            }
        });

        return nameParts.join(' ');
    }
}
