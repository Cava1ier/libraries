
import { OceanScores } from '../Character.types';
import { StatCalculator } from './StatCalculator';

export class SoulStrengthCalculator extends StatCalculator {
    public calculate(oceanScores: OceanScores): number {
        const base = 10;
        const multiplier = 0.8;
        const randomRange = 16;

        const value = base + Math.floor((100 - oceanScores.n) * multiplier) + this.randomFromRange(randomRange);
        return value;
    }
}
