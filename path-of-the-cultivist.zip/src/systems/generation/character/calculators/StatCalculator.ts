
import { RNGService } from '../../../../services/RNGService';
import { OceanScores } from '../Character.types';

export abstract class StatCalculator {
    constructor(protected rng: RNGService) {}

    public abstract calculate(oceanScores: OceanScores): number;

    protected randomFromRange(range: number): number {
        return this.rng.next() % range;
    }
}
