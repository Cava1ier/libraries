
import { OceanScores } from '../Character.types';
import { StatCalculator } from './StatCalculator';

export class FateThreadsCalculator extends StatCalculator {
    public calculate(oceanScores: OceanScores): number {
        const base = 10;
        const o_multiplier = 0.4;
        const e_multiplier = 0.4;
        const randomRange = 11;

        const value = base + Math.floor(oceanScores.o * o_multiplier + oceanScores.e * e_multiplier) + this.randomFromRange(randomRange);
        return value;
    }
}
