
import { RNGService } from '../../../../services/RNGService';
import { CharacterStats } from '../Character.types';
import { StatCalculator } from '../calculators/StatCalculator';
import { SoulStrengthCalculator } from '../calculators/SoulStrengthCalculator';
import { KarmicBurdenCalculator } from '../calculators/KarmicBurdenCalculator';
import { FateThreadsCalculator } from '../calculators/FateThreadsCalculator';

export class StatCalculatorFactory {
    private calculators: Map<string, StatCalculator>;

    constructor(rng: RNGService) {
        this.calculators = new Map([
            ['soul_strength', new SoulStrengthCalculator(rng)],
            ['karmic_burden', new KarmicBurdenCalculator(rng)],
            ['fate_threads', new FateThreadsCalculator(rng)],
        ]);
    }

    public getCalculator(statType: keyof CharacterStats): StatCalculator | undefined {
        return this.calculators.get(statType as string);
    }
}
