
import { RNGSystem } from '../../rng/RNGSystem';
import { GameDatabase } from '../../database/Database';
import { WorldSystem } from '../../world/WorldSystem';
import { GeneratedCharacter } from '../../generation/character/Character.types';
import { Faction, FactionType, FactionIdeology, FactionMember, FactionResources, Territory, FactionTemplate, FactionRelationship } from '../../../types/SocialTypes';

export class FactionGenerator {
    private factionTemplates: FactionTemplate[] = [];

    constructor(
        private rng: RNGSystem,
        private db: GameDatabase,
        private worldSystem: WorldSystem
    ) {
        this.initializeFactionTemplates();
    }

    public generateFactionsForRegion(region: { x: [number, number]; y: [number, number] }, characters: GeneratedCharacter[], maxFactions: number = 3): Faction[] {
        const factions: Faction[] = [];
        const regionCharacters = characters.filter(char =>
            char.x >= region.x[0] && char.x <= region.x[1] &&
            char.y >= region.y[0] && char.y <= region.y[1]
        );

        for (let i = 0; i < maxFactions; i++) {
            const founder = this.selectFactionFounder(regionCharacters.filter(c => !factions.some(f => f.members.some(m => m.characterId === c.name))));
            if (founder) {
                const faction = this.generateFaction(founder, undefined, this.createTerritoryFromRegion(region));
                this.assignMembersToFaction(faction, regionCharacters);
                factions.push(faction);
            }
        }
        
        this.generateFactionRelationships(factions);
        return factions;
    }
    
    public generateFaction(founderCharacter?: GeneratedCharacter, factionType?: FactionType, territory?: Territory): Faction {
        const template = this.selectFactionTemplate(factionType, founderCharacter);
        return this.createFactionFromTemplate(template, founderCharacter, territory);
    }

    private selectFactionFounder(characters: GeneratedCharacter[]): GeneratedCharacter | null {
        if (characters.length === 0) return null;
        const leaders = characters.filter(char => char.ocean_e > 60 && char.ocean_c > 50 && char.cultivation_level >= 2);
        return leaders.length > 0 ? leaders[this.rng.next() % leaders.length] : characters[this.rng.next() % characters.length];
    }

    private selectFactionTemplate(preferredType?: FactionType, founder?: GeneratedCharacter): FactionTemplate {
        let candidates = this.factionTemplates;
        if (preferredType) candidates = candidates.filter(t => t.type === preferredType);
        if (founder) candidates = candidates.filter(t => this.isCharacterCompatibleWithFaction(founder, t));
        if (candidates.length === 0) candidates = this.factionTemplates;
        return candidates[this.rng.next() % candidates.length];
    }
    
    private createFactionFromTemplate(template: FactionTemplate, founder?: GeneratedCharacter, territory?: Territory): Faction {
        const faction: Faction = {
            id: this.generateFactionId(),
            name: this.generateFactionName(template, founder),
            type: template.type,
            description: template.description,
            ideology: { ...template.ideology },
            powerLevel: template.basePowerLevel + (this.rng.next() % 20),
            territory: territory ? [territory] : [],
            members: [],
            relationships: new Map(),
            resources: this.generateInitialResources(template),
            goals: [],
            history: [],
            isActive: true,
        };

        if (founder) {
            faction.members.push({
                characterId: founder.name,
                rank: template.leaderRank || 'Leader',
                joinDate: Date.now(),
                loyalty: 90 + (this.rng.next() % 11),
            });
        }
        return faction;
    }

    private generateFactionName(template: FactionTemplate, founder?: GeneratedCharacter): string {
        const namePatterns = template.namePatterns || ['{adjective} {noun}'];
        const pattern = namePatterns[this.rng.next() % namePatterns.length];
        return pattern
            .replace('{founder}', founder?.name.split(' ')[0] || 'Ancient')
            .replace('{type}', template.type.charAt(0).toUpperCase() + template.type.slice(1))
            .replace('{adjective}', this.getRandomFromTable('tblPreNameAdjectives'))
            .replace('{noun}', this.getRandomFromTable('tblNouns'))
            .replace('{element}', founder?.spiritual_roots || 'Mystic');
    }

    private assignMembersToFaction(faction: Faction, candidates: GeneratedCharacter[]): void {
        const maxMembers = Math.min(10, candidates.length);
        const memberCount = 2 + (this.rng.next() % (maxMembers > 2 ? (maxMembers - 2) : 1));

        const compatibleCandidates = candidates.filter(char =>
            char.name !== faction.members[0]?.characterId &&
            this.isCharacterCompatibleWithFactionIdeology(char, faction.ideology)
        );

        for (let i = 0; i < Math.min(memberCount, compatibleCandidates.length); i++) {
            const candidate = compatibleCandidates[i];
            faction.members.push({
                characterId: candidate.name,
                rank: 'Disciple',
                joinDate: Date.now(),
                loyalty: 50 + (this.rng.next() % 40),
            });
        }
    }

    private generateFactionRelationships(factions: Faction[]): void {
        for (let i = 0; i < factions.length; i++) {
            for (let j = i + 1; j < factions.length; j++) {
                const faction1 = factions[i];
                const faction2 = factions[j];
                const relationship = this.calculateFactionRelationship(faction1, faction2);
                faction1.relationships.set(faction2.id, relationship);
                faction2.relationships.set(faction1.id, { ...relationship, sourceId: faction2.id, targetId: faction1.id });
            }
        }
    }

    private calculateFactionRelationship(faction1: Faction, faction2: Faction): FactionRelationship {
        let baseRelation = 0;
        if (faction1.ideology.alignment === faction2.ideology.alignment) baseRelation += 20;
        else if (
            (faction1.ideology.alignment === 'righteous' && faction2.ideology.alignment === 'demonic') ||
            (faction1.ideology.alignment === 'demonic' && faction2.ideology.alignment === 'righteous')
        ) baseRelation -= 40;
        
        const finalRelation = Math.max(-100, Math.min(100, baseRelation + (this.rng.next() % 21) - 10));

        return {
            sourceId: faction1.id,
            targetId: faction2.id,
            type: this.determineRelationshipType(finalRelation),
            strength: finalRelation,
            isPublic: true,
            history: [],
            lastUpdate: Date.now()
        };
    }

    private isCharacterCompatibleWithFaction(character: GeneratedCharacter, template: FactionTemplate): boolean {
        if (template.ideology.alignment === 'righteous' && character.karmic_burden > 60) return false;
        if (template.ideology.alignment === 'demonic' && character.karmic_burden < 40) return false;
        if (template.leadershipRequirements) {
            if (template.leadershipRequirements.minExtraversion && character.ocean_e < template.leadershipRequirements.minExtraversion) return false;
            if (template.leadershipRequirements.minConscientiousness && character.ocean_c < template.leadershipRequirements.minConscientiousness) return false;
        }
        return true;
    }

    private isCharacterCompatibleWithFactionIdeology(character: GeneratedCharacter, ideology: FactionIdeology): boolean {
        switch (ideology.alignment) {
            case 'righteous': return character.karmic_burden < 50 && character.ocean_a > 40;
            case 'demonic': return character.karmic_burden > 50 || character.ocean_a < 40;
            default: return true;
        }
    }

    private determineRelationshipType(strength: number): string {
        if (strength > 60) return 'alliance';
        if (strength > 20) return 'friendly';
        if (strength > -20) return 'neutral';
        if (strength > -60) return 'hostile';
        return 'enemy';
    }

    private createTerritoryFromRegion(region: { x: [number, number]; y: [number, number] }): Territory {
        return {
            name: `Territory of ${region.x[0]},${region.y[0]}`,
            bounds: region,
            controlLevel: 70 + (this.rng.next() % 31),
            strategicValue: 50 + (this.rng.next() % 51),
            resources: ['spiritual_veins', 'herbs']
        };
    }
    
    private generateInitialResources(template: FactionTemplate): FactionResources {
        const base = template.baseResources;
        return {
            wealth: base.wealth + (this.rng.next() % 1000),
            influence: base.influence + (this.rng.next() % 50),
            militaryStrength: base.militaryStrength + (this.rng.next() % 100),
            knowledgeBase: base.knowledgeBase + (this.rng.next() % 100),
            spiritualPower: base.spiritualPower + (this.rng.next() % 200),
            territories: base.territories
        };
    }
    
    private getRandomFromTable(tableName: string): string {
        const table = this.db.getTable(tableName);
        if (!table) return 'Unknown';
        const records = table.findAll();
        return records.length > 0 ? records[this.rng.next() % records.length].name : 'Unknown';
    }

    private generateFactionId(): string {
        return `faction_${Date.now()}_${this.rng.next() % 10000}`;
    }

    private initializeFactionTemplates(): void {
        this.factionTemplates = [
            {
                type: FactionType.SECT,
                ideology: { alignment: 'righteous', primaryValues: ['cultivation', 'honor'], conflictApproach: 'defensive', recruitmentPolicy: 'selective' },
                basePowerLevel: 60, baseResources: { wealth: 5000, influence: 40, militaryStrength: 70, knowledgeBase: 80, spiritualPower: 90, territories: 1 },
                leaderRank: 'Sect Master', namePatterns: ['{element} {noun} Sect', 'Sacred {noun} Sect'],
                leadershipRequirements: { minConscientiousness: 60 },
                description: 'A cultivation sect focused on righteous practices.'
            },
            {
                type: FactionType.DEMONIC_CULT,
                ideology: { alignment: 'demonic', primaryValues: ['power', 'domination'], conflictApproach: 'aggressive', recruitmentPolicy: 'open' },
                basePowerLevel: 50, baseResources: { wealth: 3000, influence: 30, militaryStrength: 80, knowledgeBase: 60, spiritualPower: 70, territories: 1 },
                leaderRank: 'Cult Master', namePatterns: ['{adjective} {noun} Cult', 'Blood {noun} Society'],
                description: 'A demonic cult that pursues forbidden power.'
            },
            {
                type: FactionType.CLAN,
                ideology: { alignment: 'neutral', primaryValues: ['family', 'tradition'], conflictApproach: 'defensive', recruitmentPolicy: 'hereditary' },
                basePowerLevel: 40, baseResources: { wealth: 10000, influence: 60, militaryStrength: 50, knowledgeBase: 50, spiritualPower: 40, territories: 1 },
                leaderRank: 'Patriarch', namePatterns: ['{founder} Clan', '{adjective} {noun} Family'],
                description: 'A powerful family-based organization.'
            }
        ];
    }
}
