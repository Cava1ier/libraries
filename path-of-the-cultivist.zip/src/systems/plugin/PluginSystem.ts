

import React from 'react';
import { EventSystem, GameEvent } from '../events/EventSystem';

// FIX: Added Plugin interface for UI page components.
export interface Plugin {
  id: string;
  component: React.ComponentType<any>;
}

export interface GamePlugin {
  name: string;
  version: string;
  dependencies?: string[];
  // FIX: Used 'any' for gameWorld to break a circular dependency with dCharacterGameWorld.
  initialize(gameWorld: any): Promise<void>;
  destroy?(): Promise<void>;
  onEvent?(event: GameEvent): void;
}

export interface PluginManifest {
  name: string;
  version: string;
  description: string;
  author: string;
  dependencies: string[];
}

export class PluginManager {
  // Game logic plugin fields
  // FIX: Renamed 'plugins' to 'gamePlugins' to avoid conflict with UI plugin map.
  private gamePlugins: Map<string, GamePlugin> = new Map();
  private loadedManifests: Map<string, PluginManifest> = new Map();
  private gameWorld?: any;
  private eventSystem?: EventSystem;

  // UI page management fields
  private uiPlugins: Map<string, Plugin> = new Map();
  private currentPage: { component: React.ComponentType<any>, props: any } | null = null;
  private forceUpdate?: () => void;


  constructor(
    // FIX: Overloaded constructor to handle two different initialization patterns.
    arg1: any, // Can be a dCharacterGameWorld instance or a forceUpdate function.
    arg2?: EventSystem
  ) {
    if (typeof arg1 === 'function') {
      // UI Plugin Manager mode
      this.forceUpdate = arg1;
    } else if (arg1 && arg2) {
      // Game Logic Plugin Manager mode
      this.gameWorld = arg1;
      this.eventSystem = arg2;
    }
  }

  // FIX: Added method to register a UI page plugin.
  public registerPlugin(plugin: Plugin): void {
    this.uiPlugins.set(plugin.id, plugin);
  }

  // FIX: Added method to load a UI page.
  public loadPage(pageId: string, props: any = {}): void {
    const plugin = this.uiPlugins.get(pageId);
    if (plugin) {
      this.currentPage = { component: plugin.component, props };
      if (this.forceUpdate) {
        this.forceUpdate();
      }
    } else {
      console.error(`Page with id '${pageId}' not found.`);
      const errorPage = this.uiPlugins.get('error');
      if (errorPage) {
          this.currentPage = { component: errorPage.component, props: { message: `Page '${pageId}' not found.` } };
          if (this.forceUpdate) this.forceUpdate();
      }
    }
  }

  // FIX: Added method to retrieve the current UI page.
  public getCurrentPage() {
    return this.currentPage;
  }

  public async loadPlugin(manifest: PluginManifest, pluginClass: new() => GamePlugin): Promise<boolean> {
    if (!this.gameWorld || !this.eventSystem) {
        console.error("PluginManager not initialized for game logic plugins.");
        return false;
    }
    try {
      if (!this.checkDependencies(manifest.dependencies)) {
        throw new Error(`Missing dependencies for plugin ${manifest.name}`);
      }

      const plugin = new pluginClass();
      
      if (!this.validatePlugin(plugin)) {
        throw new Error(`Invalid plugin interface for ${manifest.name}`);
      }

      await plugin.initialize(this.gameWorld);

      this.gamePlugins.set(manifest.name, plugin);
      this.loadedManifests.set(manifest.name, manifest);

      this.eventSystem.addEvent(
        'system',
        'Plugin loaded',
        `${manifest.name} v${manifest.version} loaded successfully`
      );
      return true;
    } catch (error: any) {
      this.eventSystem.addEvent(
        'system',
        'Plugin load failed',
        `Failed to load ${manifest.name}: ${error.message}`
      );
      return false;
    }
  }

  public async unloadPlugin(name: string): Promise<boolean> {
    const plugin = this.gamePlugins.get(name);
    if (!plugin) return false;

    try {
      if (plugin.destroy) {
        await plugin.destroy();
      }

      this.gamePlugins.delete(name);
      this.loadedManifests.delete(name);

      this.eventSystem?.addEvent(
        'system',
        'Plugin unloaded',
        `${name} unloaded successfully`
      );
      return true;
    } catch (error: any) {
      this.eventSystem?.addEvent(
        'system',
        'Plugin unload failed',
        `Failed to unload ${name}: ${error.message}`
      );
      return false;
    }
  }

  public notifyPlugins(event: GameEvent): void {
    for (const plugin of this.gamePlugins.values()) {
      if (plugin.onEvent) {
        try {
          plugin.onEvent(event);
        } catch (error) {
          console.error(`Plugin ${plugin.name} event handler failed:`, error);
        }
      }
    }
  }

  public getLoadedPlugins(): PluginManifest[] {
    return Array.from(this.loadedManifests.values());
  }

  private checkDependencies(dependencies: string[]): boolean {
    return dependencies.every(dep => this.gamePlugins.has(dep));
  }

  private validatePlugin(plugin: GamePlugin): boolean {
    return (
      typeof plugin.name === 'string' &&
      typeof plugin.version === 'string' &&
      typeof plugin.initialize === 'function'
    );
  }
}
