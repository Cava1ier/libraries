

'use strict';

/**
 * Manages the styles for a specific component prefix.
 * This class is responsible for generating and injecting CSS rules into the DOM.
 */
class ClassRegistry {
    private appPrefix: string;
    private classPrefix: string;
    private styles: string[];
    private classnames: string[];
    private styleValues: (string | null | undefined)[][];
    private nl: null = null;
    private _styleRegistry: Map<string, string>;
    private _styleElementId: string;
    private _initialized: boolean;

    constructor(appPrefix: string, classPrefix: string, styles: string[], classnames: string[], styleValues: (string | null | undefined)[][]) {
        this.appPrefix = appPrefix;
        this.classPrefix = classPrefix;
        this.styles = styles;
        this.classnames = classnames;
        this.styleValues = styleValues;
        this._styleRegistry = new Map();
        this._styleElementId = `styles-${appPrefix}-${classPrefix}`;
        this._initialized = false;

        this._validateArrays();
    }

    private _validateArrays() {
        if (this.classnames.length !== this.styleValues.length) {
            throw new Error(`Style Registry Error: classnames (${this.classnames.length}) and styleValues (${this.styleValues.length}) arrays must have same length for prefix '${this.classPrefix}'`);
        }

        this.styleValues.forEach((values, index) => {
            if (values.length !== this.styles.length) {
                // This is a common error. We will log a warning but allow it to proceed by padding the array.
                // This can prevent crashes if a component's style definition is temporarily out of sync during development.
                console.warn(`Style Registry Warning: styleValues[${index}] length (${values.length}) does not match styles length (${this.styles.length}) for prefix '${this.classPrefix}'. Padding with nulls.`);
                while(values.length < this.styles.length) {
                    values.push(this.nl);
                }
            }
        });
    }

    /**
    * Generate the full CSS class name with proper prefixing
    * @param {string} className - The class identifier
    * @returns {string} Fully prefixed CSS class name
    */
    cls(className: string): string {
        if (!this._initialized) {
            this.injectStyles();
        }

        const fullClass = `${this.appPrefix}-${this.classPrefix}-${className}`;
        return this._styleRegistry.get(className) || fullClass;
    }

    /**
    * Inject styles into the document
    */
    injectStyles() {
        if (this._initialized) return;

        let cssRules = '';

        this.classnames.forEach((className, classIndex) => {
            const fullClass = `${this.appPrefix}-${this.classPrefix}-${className}`;
            const values = this.styleValues[classIndex];

            let cssRule = `.${fullClass} {\n`;
            this.styles.forEach((property, propIndex) => {
                const value = values[propIndex];
                if (value != null && value !== this.nl) {
                    cssRule += `  ${property}: ${value};\n`;
                }
            });
            cssRule += '}\n';
            cssRules += cssRule;

            this._styleRegistry.set(className, fullClass);
        });

        this._injectCSS(cssRules);
        this._initialized = true;
    }

    private _injectCSS(cssRules: string) {
        const existingStyleElement = document.getElementById(this._styleElementId);
        if (existingStyleElement) {
            existingStyleElement.remove();
        }
    
        const styleElement = document.createElement('style');
        styleElement.id = this._styleElementId;
        styleElement.textContent = cssRules;
        document.head.appendChild(styleElement);
    }
}


/**
 * The main registry that manages multiple ClassRegistry instances for an application.
 */
export class StyleRegistry {
    private appPrefix: string;
    private registries: Map<string, ClassRegistry>;

    constructor(appPrefix: string) {
        if (!appPrefix) {
            throw new Error('StyleRegistry requires an app prefix');
        }
        this.appPrefix = appPrefix;
        this.registries = new Map();
    }

    addClassPrefix(classPrefix: string, styles: string[] = [], classnames: string[] = [], styleValues: (string|null|undefined)[][] = []) {
        if (this.registries.has(classPrefix)) {
            // If styles for this prefix are being re-registered, we assume an update is intended.
            // console.warn(`Style prefix '${classPrefix}' is being re-registered.`);
        }

        const classRegistry = new ClassRegistry(this.appPrefix, classPrefix, styles, classnames, styleValues);
        this.registries.set(classPrefix, classRegistry);
        classRegistry.injectStyles();

        return classRegistry;
    }

    cls(classPrefix: string, className: string): string {
        const registry = this.registries.get(classPrefix);
        if (!registry) {
            console.error(`Class prefix '${classPrefix}' not registered. Call addClassPrefix() first.`);
            return `${this.appPrefix}-${classPrefix}-${className}`;
        }

        return registry.cls(className);
    }
}