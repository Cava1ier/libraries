
import { BaseTile, MoveResult, TileData, ActionContext } from '../BaseTile';

export class BlockingTile extends BaseTile {
    constructor(data: TileData) {
        super(data);
    }
    
    canMoveTo(character: any, context?: ActionContext): boolean {
        return false;
    }

    onEnter(character: any, context?: ActionContext): MoveResult {
        return {
            success: false,
            event: `The ${this.type} blocks your path.`,
            consequence: "You cannot pass through."
        };
    }
}
