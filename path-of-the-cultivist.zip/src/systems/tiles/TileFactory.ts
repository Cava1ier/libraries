import { BaseTile, TileData } from './BaseTile';
import { StandardTile } from './tiletypes/StandardTile';
import { BlockingTile } from './tiletypes/BlockingTile';
import { ElevationChangeTile } from './tiletypes/ElevationChangeTile';
import { InteractiveTile } from './tiletypes/InteractiveTile';
import { ConditionalTile } from './tiletypes/ConditionalTile';
import { TileConfigRegistry } from './TileConfigRegistry';

export class TilesFactory {
    private static tileClasses = new Map<string, new (data: any) => BaseTile>([
        ['standard', StandardTile],
        ['blocking', BlockingTile],
        ['elevation', ElevationChangeTile],
        ['interactive', InteractiveTile],
        ['conditional', ConditionalTile],
    ]);

    public static createTile(data: TileData): BaseTile {
        const config = TileConfigRegistry.get(data.type);
        if (!config) {
            console.warn(`No config for tile type "${data.type}", using standard tile as fallback.`);
            return new StandardTile(data);
        }

        const TileClass = this.tileClasses.get(config.tileClass);
        if (!TileClass) {
            console.error(`Unknown tile class name in config: ${config.tileClass}. Falling back to standard tile.`);
            return new StandardTile(data);
        }
        
        // Merge data from the world generator with behavioral properties from the config registry.
        const tileData = {
            ...data,
            ...config.properties,
        };

        return new TileClass(tileData);
    }
}