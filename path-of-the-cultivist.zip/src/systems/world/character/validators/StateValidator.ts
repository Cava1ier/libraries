import { GameStateService } from '../managers/GameStateManager';
import { PlayerState } from '../CharacterWorld.types';

export class StateValidator {
  constructor(private stateManager: GameStateService) {}

  public canMove(): boolean {
    const state = this.stateManager.playerState;
    return state === 'idle' || state === 'exploring';
  }

  public canPerformAction(): boolean {
    const state = this.stateManager.playerState;
    return state === 'idle' || state === 'exploring';
  }

  public canChangeMode(): boolean {
    return this.canMove();
  }

  public canSave(): boolean {
    const state = this.stateManager.playerState;
    return state !== 'combat' && state !== 'dialogue';
  }

  public canExplore(): boolean {
    const state = this.stateManager.playerState;
    return state === 'idle' || state === 'exploring';
  }

  public isInCombat(): boolean {
    return this.stateManager.playerState === 'combat';
  }

  public isInDialogue(): boolean {
    return this.stateManager.playerState === 'dialogue';
  }

  public isMoving(): boolean {
    const state = this.stateManager.playerState;
    return state === 'moving' || state === 'exploring';
  }

  public validateStateTransition(
    from: PlayerState, 
    to: PlayerState
  ): { valid: boolean; reason?: string } {
    const validTransitions: Record<PlayerState, PlayerState[]> = {
      'idle': ['moving', 'exploring', 'combat', 'dialogue', 'meditating', 'cultivating'],
      'moving': ['idle', 'combat', 'dialogue'],
      'exploring': ['idle', 'moving', 'combat', 'dialogue'],
      'combat': ['idle'],
      'dialogue': ['idle'],
      'meditating': ['idle'],
      'cultivating': ['idle']
    };

    const allowedStates = validTransitions[from] || [];
    
    if (!allowedStates.includes(to)) {
      return {
        valid: false,
        reason: `Cannot transition from ${from} to ${to}`
      };
    }

    return { valid: true };
  }
}
