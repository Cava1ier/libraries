import { GameCoordinatorService } from '../../../../services/GameCoordinatorService';
import { GAME_CONFIG } from '../../../../config/GameWorldConfig';

export class ExplorationController {
  constructor(private gameCoordinator: GameCoordinatorService) {}

  public toggleAutoExplore() {
    if (this.gameCoordinator.gameState.getPlayerState() === 'exploring') {
      this.stopExploration();
    } else {
      this.startExploration();
    }
  }

  public continueAutoExplore() {
    const { gameState, movementService, discoveredTiles, character } = this.gameCoordinator;
    if (gameState.getPlayerState() !== 'exploring') return;

    setTimeout(() => {
      if (gameState.getPlayerState() !== 'exploring') return;

      const target = movementService.findNearestUnexplored(character.data, discoveredTiles);
      if (target) {
        this.gameCoordinator.movementController.handleMapClick(target.x, target.y);
      } else {
        this.completeExploration();
      }
    }, GAME_CONFIG.ACTIONS.EXPLORATION_DELAY);
  }

  private startExploration() {
    this.gameCoordinator.gameState.setPlayerState('exploring');
    this.gameCoordinator.eventService.addEvent('system', 'You begin to explore automatically...', '');
    this.continueAutoExplore();
  }

  // FIX: Changed from private to public to be accessible from InputHandler.
  public stopExploration() {
    this.gameCoordinator.movementController.stopMovement();
    this.gameCoordinator.gameState.setPlayerState('idle');
    this.gameCoordinator.eventService.addEvent('system', 'Auto-exploration stopped.', '');
  }

  private completeExploration() {
    this.gameCoordinator.eventService.addEvent('system', 'Exploration complete.', 'No new areas found nearby.');
    this.gameCoordinator.gameState.setPlayerState('idle');
  }
}