
import { GameCoordinatorService } from '../../../../services/GameCoordinatorService';
import { InteractionMode } from '../CharacterWorld.types';
import { BaseTile, ActionContext } from '../../../tiles/BaseTile';
import { TileConfigRegistry } from '../../../tiles/TileConfigRegistry';
import { CreatureData } from '../../../../types/AdventureTypes';

export class InteractionController {
  constructor(private gameCoordinator: GameCoordinatorService) {}

  public handleCursorMove(dx: number, dy: number) {
    const { mapData, movementService, character, gameState } = this.gameCoordinator;
    mapData.moveCursor(dx, dy);
    const pathResult = movementService.findPathTo(character, { ...mapData.cursorPos, z: character.z });
    gameState.setCurrentPath(pathResult.path);
    this.gameCoordinator.updateAndRender();
  }

  public setMode(newMode: InteractionMode) {
    const { gameState, mapData, character, eventService } = this.gameCoordinator;
    if (gameState.getPlayerState() !== 'idle') return;
    
    mapData.setMode(newMode, character.data);
    gameState.setCurrentPath(null);
    
    eventService.addEvent('system', newMode === 'look' ? "Switched to Look mode." : "Switched to Move mode.");
    this.gameCoordinator.updateAndRender();
  }

  public changeViewZ(delta: number) {
    this.gameCoordinator.mapData.changeViewZ(delta);
    this.gameCoordinator.updateAndRender();
  }

  public tryClimb(dz: number) {
    const { movementService, character, mapData, eventService } = this.gameCoordinator;
    const result = movementService.validator.validateClimb(character, dz);
    
    if (result.success) {
      const newZ = character.z + dz;
      character.setPosition(character.x, character.y, newZ);
      mapData.followCharacter(character.data);
      eventService.addEvent('system', `You climb ${dz > 0 ? 'up' : 'down'}.`, `You are now at Z-level ${newZ}.`);
      this.gameCoordinator.worldUpdateManager.updateVision();
    } else {
      eventService.addEvent('system', result.reason || "Cannot climb", "The way is blocked.");
    }
    this.gameCoordinator.updateAndRender();
  }

  public endDialogue() {
    this.gameCoordinator.gameState.setPlayerState('idle');
  }

  private findAdjacentInteractable(): { tile: BaseTile | null, creature: CreatureData | null } {
    const { character, worldService, creatureService } = this.gameCoordinator;
    const directions = [
        { dx: 0, dy: -1 }, { dx: 1, dy: 0 }, { dx: 0, dy: 1 }, { dx: -1, dy: 0 }, // Cardinal
        { dx: -1, dy: -1 }, { dx: 1, dy: -1 }, { dx: -1, dy: 1 }, { dx: 1, dy: 1 }  // Diagonal
    ];

    for (const dir of directions) {
        const checkX = character.x + dir.dx;
        const checkY = character.y + dir.dy;
        const checkZ = character.z;
        
        // Prioritize non-hostile creatures for interaction
        const creature = creatureService.getCreatureAt(checkX, checkY, checkZ);
        if (creature && !creature.isHostile) {
            return { tile: null, creature: creature };
        }

        const tile = worldService.getVisibleTile(checkX, checkY, checkZ);
        if (tile) {
            const config = TileConfigRegistry.get(tile.type);
            if (config && config.tileClass === 'interactive') {
                return { tile: tile, creature: null };
            }
        }
    }
    return { tile: null, creature: null };
  }

  public isInteractionAvailable(): boolean {
    const interactable = this.findAdjacentInteractable();
    return !!interactable.tile || !!interactable.creature;
  }

  public interactWithAdjacent(): void {
    const interactable = this.findAdjacentInteractable();

    if (interactable.creature) {
        const creature = interactable.creature;
        creature.passthroughTimestamp = Date.now();
        this.gameCoordinator.gameState.setPlayerState('dialogue');
        const dialogue = this.gameCoordinator.dialogueService.getDialogue(creature);
        this.gameCoordinator.context.onDialogueStart(dialogue);
        return;
    }
    
    if (interactable.tile) {
        const tile = interactable.tile;
        const context: ActionContext = {
            skillSystem: this.gameCoordinator.skillService as any,
        };

        const result = tile.onEnter(this.gameCoordinator.character.data, context);

        if (result.event) {
            this.gameCoordinator.eventService.addEvent('interaction', result.event, result.consequence || '');
        }

        if (result.inventoryAdd) {
            const { itemName, quantity } = result.inventoryAdd;
            const itemRecord = this.gameCoordinator.db.getTable('tblItems').query((r: any) => r.name === itemName)[0];
            if (itemRecord) {
                this.gameCoordinator.inventoryService.addItem(itemRecord.id, quantity, 2); // Assuming common quality
                this.gameCoordinator.questService.updateProgress('COLLECT', itemName, quantity);
            } else {
                this.gameCoordinator.eventService.addEvent('system', 'Error', `Could not find item definition for ${itemName}.`);
            }
        }

        if (result.characterUpdates) {
            Object.assign(this.gameCoordinator.character.data, result.characterUpdates);
        }
        
        this.gameCoordinator.updateAndRender();
        return;
    }

    this.gameCoordinator.eventService.addEvent('system', "Nothing to interact with.", "");
  }
}