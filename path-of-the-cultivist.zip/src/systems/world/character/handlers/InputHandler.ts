import { GameCoordinatorService } from '../../../../services/GameCoordinatorService';
import { KeyMappingRegistry } from '../../../../config/KeyMappings';

export class InputHandler {
  constructor(private gameCoordinator: GameCoordinatorService) {}

  public handleKeyDown(key: string, shiftKey: boolean) {
    const { playerState, mapData } = this.gameCoordinator;
    if (playerState === 'combat' || playerState === 'dialogue') return;
    if (this.handleModeKeys(key)) return;
    if (this.handleViewKeys(key, shiftKey)) return;
    
    if (playerState === 'idle' || playerState === 'exploring') {
      const movement = KeyMappingRegistry.getMovement(key);
      if (movement) {
        if (mapData.mode === 'move') {
          if (playerState === 'exploring') this.gameCoordinator.explorationController.stopExploration();
          this.gameCoordinator.movementController.handleDirectionalMovement(movement);
        } else {
          this.gameCoordinator.interactionController.handleCursorMove(movement.dx, movement.dy);
        }
      }
    }
  }

  private handleModeKeys(key: string): boolean {
    const action = KeyMappingRegistry.getModeAction(key);
    if (!action) return false;

    switch (action) {
      case 'toggle_mode':
        this.gameCoordinator.interactionController.setMode(this.gameCoordinator.mapData.mode === 'move' ? 'look' : 'move');
        return true;
      case 'escape':
        if (this.gameCoordinator.playerState === 'moving' || this.gameCoordinator.playerState === 'exploring') {
          this.gameCoordinator.movementController.stopMovement();
        } else if (this.gameCoordinator.mapData.mode === 'look') {
          this.gameCoordinator.interactionController.setMode('move');
        } else if (this.gameCoordinator.playerState !== 'idle') {
          this.gameCoordinator.actionService.cancelCurrentAction();
        }
        return true;
    }
    return false;
  }

  private handleViewKeys(key: string, shiftKey: boolean): boolean {
    if (!shiftKey) return false;
    const action = KeyMappingRegistry.getViewAction(key);
    if (!action) return false;
    this.gameCoordinator.interactionController.changeViewZ(action === 'view_up' ? 1 : -1);
    return true;
  }
}