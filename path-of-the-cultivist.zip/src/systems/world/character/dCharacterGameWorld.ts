
// FIX: This file is a duplicate of `src/data/dCharacterGameWorld.ts`.
// Re-exporting from the canonical source to resolve type conflicts across the application.
export * from '../../../data/dCharacterGameWorld';