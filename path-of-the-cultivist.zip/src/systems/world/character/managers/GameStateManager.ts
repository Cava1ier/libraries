import { PlayerState, InteractionMode } from '../CharacterWorld.types';
import { Position } from '../../../generation/character/Character.types';
import { BaseService } from '../../../../patterns/BaseService';

export class GameStateService extends BaseService {
  public playerState: PlayerState = 'idle';
  public currentPath: Position[] | null = null;
  public discoveredTiles: Set<string> = new Set();
  public lineOfSightTiles: Set<string> = new Set();
  public actionProgress: { startTime: number, duration: number, actionId: string } | null = null;

  constructor(initialDiscoveredTiles?: string[]) {
    super();
    if (initialDiscoveredTiles) {
        this.discoveredTiles = new Set(initialDiscoveredTiles);
    }
  }

  public getPlayerState(): PlayerState {
      return this.playerState;
  }

  public setPlayerState(state: PlayerState) {
    const oldState = this.playerState;
    this.playerState = state;
    this.onStateChange(oldState, state);
  }

  public getCurrentPath(): Position[] | null {
      return this.currentPath;
  }

  public setCurrentPath(path: Position[] | null) {
    this.currentPath = path;
  }

  public getActionProgress() {
      return this.actionProgress;
  }
  
  public setActionProgress(progress: { startTime: number, duration: number, actionId: string } | null) {
    this.actionProgress = progress;
  }

  public getDiscoveredTiles(): Set<string> {
      return this.discoveredTiles;
  }

  public setDiscoveredTiles(tiles: string[]) {
      this.discoveredTiles = new Set(tiles);
  }
  
  public getLineOfSightTiles(): Set<string> {
      return this.lineOfSightTiles;
  }

  public updateVision(visionResult: { lineOfSight: Set<string>; discovered: Set<string> }) {
    this.lineOfSightTiles = visionResult.lineOfSight;
    this.discoveredTiles = visionResult.discovered;
  }

  private onStateChange(oldState: PlayerState, newState: PlayerState) {
    if (oldState === 'moving' && newState === 'idle') {
      this.setCurrentPath(null);
    }
    // If we're moving back to idle from any busy state, clear the progress.
    if (newState === 'idle') {
      this.setActionProgress(null);
    }
  }
}
