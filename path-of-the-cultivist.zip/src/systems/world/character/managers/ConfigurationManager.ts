
import { GameWorldCallbacks } from '../CharacterWorld.types';

export interface GameConfiguration {
  movement: {
    animationSpeed: number;
    pathfindingTimeout: number;
    maxPathLength: number;
    visionRadius: number;
    autoExploreRadius: number;
  };
  combat: {
    turnTimeout: number;
    autoResolve: boolean;
  };
  exploration: {
    delay: number;
    maxRadius: number;
  };
  ui: {
    maxEvents: number;
    autoSaveInterval: number;
  };
  debug: {
    showPathfinding: boolean;
    logEvents: boolean;
  };
}

export class ConfigurationManager {
  private config: GameConfiguration;
  private callbacks?: GameWorldCallbacks;

  constructor(initialConfig: Partial<GameConfiguration> = {}, callbacks?: GameWorldCallbacks) {
    this.config = this.mergeWithDefaults(initialConfig);
    this.callbacks = callbacks;
  }

  public getConfig(): GameConfiguration { return { ...this.config }; }
  public updateConfig(updates: Partial<GameConfiguration>): void {
    this.config = this.deepMerge(this.config, updates);
    this.notifyConfigChange();
  }

  public getMovementConfig() { return this.config.movement; }
  public getCombatConfig() { return this.config.combat; }
  public getExplorationConfig() { return this.config.exploration; }
  public getUIConfig() { return this.config.ui; }
  public getDebugConfig() { return this.config.debug; }
  
  public resetToDefaults(): void {
    this.config = this.getDefaultConfig();
    this.notifyConfigChange();
  }

  public saveConfig(): void {
    try {
      localStorage.setItem('gameConfig', JSON.stringify(this.config));
    } catch (e) {
      console.error("Failed to save config to localStorage", e);
    }
  }

  public loadConfig(): void {
    const saved = localStorage.getItem('gameConfig');
    if (saved) {
      try {
        const parsedConfig = JSON.parse(saved);
        this.config = this.mergeWithDefaults(parsedConfig);
        this.notifyConfigChange();
      } catch (error) {
        console.warn('Failed to load saved config, using defaults');
      }
    }
  }

  private mergeWithDefaults(config: Partial<GameConfiguration>): GameConfiguration {
    return this.deepMerge(this.getDefaultConfig(), config);
  }

  private getDefaultConfig(): GameConfiguration {
    return {
      movement: { animationSpeed: 200, pathfindingTimeout: 5000, maxPathLength: 100, visionRadius: 10, autoExploreRadius: 30 },
      combat: { turnTimeout: 30000, autoResolve: false },
      exploration: { delay: 100, maxRadius: 10 },
      ui: { maxEvents: 100, autoSaveInterval: 300000 },
      debug: { showPathfinding: false, logEvents: false }
    };
  }

  private deepMerge(target: any, source: any): any {
    const result = { ...target };
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        result[key] = this.deepMerge(target[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    }
    return result;
  }

  private notifyConfigChange(): void {
    // In a real app, this would use a proper event emitter.
  }
}
