
export interface PerformanceMetrics {
  frameRate: number;
  memoryUsage: number;
  renderTime: number;
  updateTime: number;
  pathfindingTime: number;
  visionCalculationTime: number;
}

export class PerformanceMonitor {
  private metrics: PerformanceMetrics = {
    frameRate: 0, memoryUsage: 0, renderTime: 0,
    updateTime: 0, pathfindingTime: 0, visionCalculationTime: 0
  };

  private frameCount: number = 0;
  private lastFrameTime: number = 0;
  private performanceEntries: Map<string, number> = new Map();

  public startTiming(operation: string): void {
    this.performanceEntries.set(operation, performance.now());
  }

  public endTiming(operation: string): number {
    const startTime = this.performanceEntries.get(operation);
    if (!startTime) return 0;

    const duration = performance.now() - startTime;
    this.performanceEntries.delete(operation);

    switch (operation) {
      case 'render': this.metrics.renderTime = duration; break;
      case 'update': this.metrics.updateTime = duration; break;
      case 'pathfinding': this.metrics.pathfindingTime = duration; break;
      case 'vision': this.metrics.visionCalculationTime = duration; break;
    }
    return duration;
  }

  public updateFrameRate(): void {
    const now = performance.now();
    if (this.lastFrameTime) {
      const delta = now - this.lastFrameTime;
      this.metrics.frameRate = 1000 / delta;
    }
    this.lastFrameTime = now;
    this.frameCount++;
  }

  public updateMemoryUsage(): void {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      this.metrics.memoryUsage = memory.usedJSHeapSize / 1024 / 1024; // MB
    }
  }

  public getMetrics(): PerformanceMetrics { return { ...this.metrics }; }
  public getAverageMetrics(samples: number = 60): PerformanceMetrics { return this.getMetrics(); }

  public isPerformanceGood(): boolean {
    return (
      this.metrics.frameRate > 30 &&
      this.metrics.renderTime < 16 &&
      this.metrics.updateTime < 10
    );
  }

  public getPerformanceReport(): string {
    const m = this.getMetrics();
    return `
Performance Report:
- Frame Rate: ${m.frameRate.toFixed(1)} FPS
- Memory: ${m.memoryUsage.toFixed(1)} MB
- Render Time: ${m.renderTime.toFixed(2)} ms
- Update Time: ${m.updateTime.toFixed(2)} ms
- Pathfinding: ${m.pathfindingTime.toFixed(2)} ms
- Vision Calc: ${m.visionCalculationTime.toFixed(2)} ms
    `.trim();
  }
}
