




import { BaseTile } from '../tiles/BaseTile';
import { WorldSystem } from '../world/WorldSystem';
import { TileConfigRegistry } from '../tiles/TileConfigRegistry';

interface PathNode {
    x: number;
    y: number;
    g: number; // cost from start
    h: number; // heuristic cost to end
    f: number; // g + h
    parent: PathNode | null;
}

export class PathfindingSystem {
    private worldSystem: WorldSystem;

    constructor(worldSystem: WorldSystem) {
        this.worldSystem = worldSystem;
    }

    public findPath(start: {x: number, y: number, z: number}, end: {x: number, y: number, z: number}): {x: number, y: number}[] | null {
        const openSet: PathNode[] = [];
        const closedSet = new Set<string>();

        const startNode: PathNode = {
            x: start.x, y: start.y,
            g: 0,
            h: this.heuristic(start, end),
            f: this.heuristic(start, end),
            parent: null
        };
        openSet.push(startNode);

        while (openSet.length > 0) {
            // Find the node with the lowest f score
            let lowestIndex = 0;
            for (let i = 1; i < openSet.length; i++) {
                if (openSet[i].f < openSet[lowestIndex].f) {
                    lowestIndex = i;
                }
            }
            const currentNode = openSet[lowestIndex];

            // Goal check
            if (currentNode.x === end.x && currentNode.y === end.y) {
                return this.reconstructPath(currentNode);
            }

            openSet.splice(lowestIndex, 1);
            closedSet.add(`${currentNode.x},${currentNode.y}`);

            const neighbors = this.getNeighbors(currentNode, start.z);
            for (const neighbor of neighbors) {
                // FIX: Access coordinates via neighbor.node
                const neighborKey = `${neighbor.node.x},${neighbor.node.y}`;
                if (closedSet.has(neighborKey)) {
                    continue;
                }

                const gScore = currentNode.g + neighbor.cost;
                
                // FIX: Access coordinates via neighbor.node
                const existingNode = openSet.find(n => n.x === neighbor.node.x && n.y === neighbor.node.y);

                if (!existingNode || gScore < existingNode.g) {
                    neighbor.node.parent = currentNode;
                    neighbor.node.g = gScore;
                    // FIX: Access coordinates via neighbor.node and set h-score correctly.
                    neighbor.node.h = this.heuristic({x: neighbor.node.x, y: neighbor.node.y}, end);
                    neighbor.node.f = neighbor.node.g + neighbor.node.h;
                    if (!existingNode) {
                        openSet.push(neighbor.node);
                    }
                }
            }
        }

        return null; // No path found
    }

    private getNeighbors(node: PathNode, z: number): {node: PathNode, cost: number}[] {
        const neighbors: {node: PathNode, cost: number}[] = [];
        for (let dx = -1; dx <= 1; dx++) {
            for (let dy = -1; dy <= 1; dy++) {
                if (dx === 0 && dy === 0) continue;
                
                const x = node.x + dx;
                const y = node.y + dy;

                const tile = this.worldSystem.getTile(x, y, z);
                if (tile && tile.canMoveTo({z: z})) {
                    // Using bitwise ops to check for diagonal movement
                    const isDiagonal = (dx & dy) !== 0;
                    const cost = this.getMovementCost(tile) * (isDiagonal ? 1.414 : 1.0);
                    
                    neighbors.push({
                        node: { x, y, g: 0, h: 0, f: 0, parent: null },
                        cost: cost
                    });
                }
            }
        }
        return neighbors;
    }

    private getMovementCost(tile: BaseTile): number {
        const config = TileConfigRegistry.get(tile.type);
        return config?.properties?.movementCost || 1;
    }

    private heuristic(a: {x: number, y: number}, b: {x: number, y: number}): number {
        // Manhattan distance using branchless absolute value
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const absDx = (dx ^ (dx >> 31)) - (dx >> 31);
        const absDy = (dy ^ (dy >> 31)) - (dy >> 31);
        return absDx + absDy;
    }

    private reconstructPath(node: PathNode): {x: number, y: number}[] {
        const path = [];
        let current: PathNode | null = node;
        while (current) {
            path.unshift({x: current.x, y: current.y});
            current = current.parent;
        }
        return path;
    }
}