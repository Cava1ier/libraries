

import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';

interface ErrorPageProps {
    message?: string;
    pluginManager: PluginManager;
}

export class ErrorPage extends Component<ErrorPageProps, {}> {
    prefix = 'error-page';
    styles = [
        'display', 'flex-direction', 'justify-content', 'align-items', 'height', 'width',
        'padding', 'text-align', 'font-family', 'font-size', 'font-weight', 'color',
        'background', 'border', 'border-radius', 'cursor'
    ];
    classnames = ['container', 'title', 'message', 'button'];
    styleValues = [
        ['flex', 'column', 'center', 'center', '100vh', '100vw', '2rem', 'center', this.nl, this.nl, this.nl, '#ffcdd2', 'linear-gradient(135deg, #2d1919 0%, #3e1616 50%, #600f0f 100%)', this.nl, this.nl, this.nl],
        [this.nl, this.nl, this.nl, this.nl, this.nl, this.nl, nl, nl, 'serif', '2.5rem', 'bold', '#d4af37', this.nl, this.nl, this.nl, this.nl],
        [this.nl, this.nl, this.nl, this.nl, this.nl, '80%', '1rem 0', 'center', 'sans-serif', '1.2rem', 'normal', '#e0e0e0', this.nl, this.nl, this.nl, this.nl],
        ['inline-block', this.nl, this.nl, this.nl, this.nl, '200px', '1rem', 'center', 'sans-serif', '1rem', 'normal', '#ffffff', 'transparent', '2px solid #d4af37', '8px', 'pointer']
    ];
    
    // Converted to an arrow function to ensure 'this' is correctly bound.
    handleReturnToMenu = () => {
        this.props.pluginManager.loadPage('menu');
    }

    // FIX: Converted to a standard class method as it is a lifecycle method.
    render() {
        const message = this.props.message || "An unknown error occurred.";
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('h1', { className: this.cls('title') }, 'A Path Was Lost'),
            React.createElement('p', { className: this.cls('message') }, message),
            React.createElement('button', { className: this.cls('button'), onClick: this.handleReturnToMenu }, 'Return to the Main Menu')
        );
    }
}