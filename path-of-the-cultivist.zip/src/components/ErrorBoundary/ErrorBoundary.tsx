





import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';

interface ErrorBoundaryProps {
    children?: React.ReactNode;
    pluginManager: PluginManager;
}

interface ErrorBoundaryState {
    hasError: boolean;
    error: Error | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
    prefix = 'error-boundary';

    state: ErrorBoundaryState = { hasError: false, error: null };

    static getDerivedStateFromError(error: Error): ErrorBoundaryState {
        return { hasError: true, error: error };
    }

    // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
    componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
        console.error("Uncaught error:", error, errorInfo);
    }

    // FIX: Kept as an arrow function as it's passed directly to onClick.
    handleReturnToMenu = () => {
        this.setState({ hasError: false, error: null });
        this.props.pluginManager.loadPage('menu');
    }

    // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
    render() {
        if (this.state.hasError) {
            return React.createElement('div', { className: this.cls('container') },
                React.createElement('h1', { className: this.cls('title') }, 'Oops! A Celestial Tribulation Occurred.'),
                React.createElement('p', { className: this.cls('message') }, 'An unexpected disturbance has shaken the application\'s core.'),
                React.createElement('p', { className: this.cls('message') }, `Error: ${this.state.error?.message}`),
                React.createElement('button', { className: this.cls('button'), onClick: this.handleReturnToMenu }, 'Return to the Main Menu')
            );
        }

        return this.props.children;
    }
}