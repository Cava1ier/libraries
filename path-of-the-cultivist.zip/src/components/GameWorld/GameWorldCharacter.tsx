// This component is deprecated and no longer in use.
// The player character is now rendered directly onto the canvas by the MapRenderer class
// for significantly better performance. This file can be safely deleted.
