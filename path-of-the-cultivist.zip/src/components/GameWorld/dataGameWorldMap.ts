import { WorldSystem } from '../../systems/world/WorldSystem';
import { WorldService } from '../../services/WorldService';

const VIEWPORT_WIDTH = 31;
const VIEWPORT_HEIGHT = 21;

export class GameWorldMapData {
    public inspectedTile: any | null = null;
    public mode: 'move' | 'look' = 'move';
    public cursorPos: { x: number; y: number; };
    public viewZ: number;

    constructor(character: any, private worldSystem: WorldService) {
        this.cursorPos = { x: character.x, y: character.y };
        this.viewZ = character.z || 5;
    }
    
    // FIX: Changed parameter type from WorldSystem to WorldService to match application architecture.
    public updateInspectedTile = (character: any, worldSystem: WorldService) => {
        if (this.mode === 'move') {
            this.inspectedTile = worldSystem.getVisibleTile(character.x, character.y, this.viewZ);
        } else {
            this.inspectedTile = worldSystem.getVisibleTile(this.cursorPos.x, this.cursorPos.y, this.viewZ);
        }
    }
    
    public setMode = (newMode: 'move' | 'look', character: any) => {
        this.mode = newMode;
        if (newMode === 'look') {
            this.cursorPos = { x: character.x, y: character.y };
            this.viewZ = character.z;
        }
    }
    
    public changeViewZ = (delta: number) => {
        this.viewZ = Math.max(0, Math.min(10, this.viewZ + delta));
    }
    
    public moveCursor(dx: number, dy: number) {
        this.cursorPos.x += dx;
        this.cursorPos.y += dy;
    }

    public followCharacter(character: any) {
        this.viewZ = character.z;
    }
    
    public getMapViewData(character: any) {
        const halfWidth = Math.floor(VIEWPORT_WIDTH / 2);
        const halfHeight = Math.floor(VIEWPORT_HEIGHT / 2);
        const startX = character.x - halfWidth;
        const startY = character.y - halfHeight;

        const rows: any[] = [];
        for (let j = 0; j < VIEWPORT_HEIGHT; j++) {
            const tiles: any[] = [];
            const currentY = startY + j;
            for (let i = 0; i < VIEWPORT_WIDTH; i++) {
                const currentX = startX + i;
                const tile = this.worldSystem.getVisibleTile(currentX, currentY, this.viewZ);
                tiles.push({
                    key: i,
                    tile,
                    isCursor: this.mode === 'look' && currentX === this.cursorPos.x && currentY === this.cursorPos.y,
                });
            }
            rows.push({ key: j, tiles });
        }
        return { rows, startX, startY };
    }
}