
import { GameWorldMapData } from './dataGameWorldMap';
import { Character } from '../../data/dCharacter';
import { GameCoordinatorService, GameCoordinatorContext } from '../../services/GameCoordinatorService';
import { CombatEncounter, DialogueState, QuestData } from '../../types/AdventureTypes';
import { AppData } from '../../dataApp';
import { ServiceFactory } from '../../core/ServiceFactory';
import { WorldService } from '../../services/WorldService';


export class GameWorldData {
    public gameCoordinator: GameCoordinatorService;
    public mapData: GameWorldMapData;
    
    constructor(
        private appData: AppData,
        characterRecord: any,
        savedData: any,
        onCombatStart: (encounter: CombatEncounter | null) => void,
        onDialogueStart: (dialogue: DialogueState) => void,
        onQuestComplete: (quest: QuestData) => void,
        onLevelUp: () => void,
        onCraftingStart: () => void,
        forceUpdate: () => void
    ) {
        const finalCharacterRecord = savedData?.characterData || characterRecord;
        const character = new Character(finalCharacterRecord);

        // FIX: Get WorldService directly from the factory, as it's a singleton initialized when the app starts.
        // This avoids the null reference on appData.gameState (which is a getter for appData.gameCoordinator)
        // because the gameCoordinator has not been created at this point in the lifecycle.
        const worldService = ServiceFactory.create<WorldService>('WorldService');
        this.mapData = new GameWorldMapData(character.data, worldService);

        const context: GameCoordinatorContext = {
            character,
            mapData: this.mapData,
            initialDiscoveredTiles: savedData?.discoveredTiles,
            onUpdate: forceUpdate,
            onCombatStart,
            onDialogueStart,
            onQuestComplete,
            onLevelUp,
            onCraftingStart
        };
        
        appData.createGameWorld(context, savedData);
        this.gameCoordinator = appData.gameCoordinator!;
    }

    public get character(): Character { return this.gameCoordinator.character; }
    public get worldEvents(): any[] { return this.gameCoordinator.eventService.getRecentEvents(50); }
    public get database(): any { return this.gameCoordinator.db; }
    public get trackedQuest(): any | undefined { return this.gameCoordinator.questService.getTrackedQuest(); }
    public get playerState() { return this.gameCoordinator.playerState; }
    public get currentPath() { return this.gameCoordinator.currentPath; }
    public get creatures(): Map<string, any> { return this.gameCoordinator.creatureService.creatures; }
    
    public get inventorySystem() { return this.gameCoordinator.inventoryService; }
    public get questSystem() { return this.gameCoordinator.questService; }
}
