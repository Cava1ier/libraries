





import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { CharacterCreationData } from './dataCharacterCreation';
import { StatWeb } from '../StatWeb/StatWeb';
import { OceanProfile } from '../../types/OceanTypes';
import { ServiceFactory } from '../../core/ServiceFactory';
import { LocalizationService } from '../../services/LocalizationService';

interface CharacterCreationProps {
    gameState?: any;
    oceanScores?: any;
    oceanProfile?: OceanProfile;
    pluginManager: PluginManager;
}

interface CharacterCreationState {
    data: CharacterCreationData | null;
    webKey: number;
    activeAccordion: string | null;
}

export class CharacterCreation extends Component<CharacterCreationProps, CharacterCreationState> {
 prefix = 'char-create';
  
 state: CharacterCreationState = {
    data: null,
    webKey: 0,
    activeAccordion: 'Primary Details'
  };
 
 // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
 componentDidMount() {
  const accordionName = ServiceFactory.create<LocalizationService>('LocalizationService').get('char_create_primary_details');
  this.setState({ 
      data: new CharacterCreationData(this.props.oceanScores, this.props.oceanProfile),
      activeAccordion: accordionName
  });
 }
 
 // FIX: Converted to arrow function to fix 'this' context
 generateNewCharacter = () => {
    if (this.state.data) {
        this.state.data.generateNewCharacter();
        this.setState(prevState => ({ webKey: prevState.webKey + 1, data: this.state.data }));
    }
 }

 // FIX: Converted arrow function to a standard class method.
 toggleAccordion(groupName: string) {
    this.setState(prevState => ({
        activeAccordion: prevState.activeAccordion === groupName ? null : groupName
    }));
 }

 // FIX: Converted arrow function to a standard class method.
 renderAccordion(groupName: string, ...children: React.ReactNode[]) {
    const isOpen = this.state.activeAccordion === groupName;
    return React.createElement('div', { key: groupName, className: this.cls('accordion-container') },
        React.createElement('div', {
            className: this.cls('accordion-header'),
            onClick: () => this.toggleAccordion(groupName)
        },
            React.createElement('span', {}, groupName),
            React.createElement('span', {}, isOpen ? '−' : '+')
        ),
        React.createElement('div', {
            className: this.cls('accordion-content'),
            style: {
                maxHeight: isOpen ? '1000px' : '0',
                paddingTop: isOpen ? '0.5rem' : '0',
                paddingBottom: isOpen ? '0.5rem' : '0',
                opacity: isOpen ? 1 : 0,
            }
        }, ...children)
    );
 }
 
 // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
 render() {
  const { data } = this.state;
  const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');

  if (!data || !data.character) return React.createElement('div', {}, localizationService.get('char_create_generating'));
  const { character, stats } = data;

  const statsForWeb = [
    { name: 'Qi\nPoints', value: character.qi_points, max: 1000 },
    { name: 'Body\nTempering', value: character.body_tempering, max: 100 },
    { name: 'Meridian\nPurity', value: character.meridian_purity, max: 100 },
    { name: 'Soul\nStrength', value: character.soul_strength, max: 100 },
    { name: 'Dao\nComprehension', value: character.dao_comprehension, max: 100 },
    { name: 'Fate\nThreads', value: character.fate_threads, max: 100 },
    { name: 'Karmic\nBurden', value: character.karmic_burden, max: 100 },
  ];

  const groupedStats = stats.reduce<Record<string, any[]>>((acc, stat: any) => {
      const group = stat.group || 'Other';
      (acc[group] = acc[group] || []).push(stat);
      return acc;
  }, {});

  const primaryDetails = [
    React.createElement('p', { key: 'name' }, 'Name: ' + character.name),
    React.createElement('p', { key: 'realm' }, 'Realm: ' + character.realm),
    React.createElement('p', { key: 'roots' }, 'Spiritual Roots: ' + character.spiritual_roots),
  ];
  
  const primaryDetailsTitle = localizationService.get('char_create_primary_details');

  const attributeAccordions = Object.entries(groupedStats).map(([groupName, groupStats]) => 
    this.renderAccordion(groupName, 
        ...(groupStats as any[]).map((stat: any, index: number) =>
            React.createElement('div', { key: index, className: this.cls('stat-list-item') },
                React.createElement('span', {}, stat.name),
                React.createElement('span', {}, `${stat.value}/${stat.max}`)
            )
        )
    )
  );
  
  return React.createElement('div', { className: this.cls('container') },
   React.createElement('div', { className: this.cls('panel') },
    React.createElement('h2', { className: this.cls('title') }, localizationService.get('char_create_profile_title')),
    React.createElement('div', { className: this.cls('stat-web-container') }, 
        React.createElement(StatWeb, { stats: statsForWeb, webKey: this.state.webKey })
    ),
    React.createElement('button', { className: this.cls('button'), onClick: () => this.props.pluginManager.loadPage('game-world', { characterRecord: character }) }, localizationService.get('char_create_button_accept')),
    React.createElement('button', { className: this.cls('button'), onClick: this.generateNewCharacter }, localizationService.get('char_create_button_reroll'))
   ),
   React.createElement('div', { className: this.cls('panel') },
    React.createElement('h2', { className: this.cls('title') }, localizationService.get('char_create_details_title')),
    this.renderAccordion(primaryDetailsTitle, ...primaryDetails),
    React.createElement('h3', { className: this.cls('subtitle'), style:{borderTop: '1px solid rgba(212,175,55,0.2)', paddingTop: '1rem', marginTop: '1rem'} }, localizationService.get('char_create_full_attributes')),
    ...attributeAccordions
   )
  );
 }
}