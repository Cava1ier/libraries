import { OceanProfile } from '../../types/OceanTypes';
import { ServiceFactory } from '../../core/ServiceFactory';
import { CharacterGenerationService } from '../../services/CharacterGenerationService';
import { DatabaseService } from '../../services/DatabaseService';

export class CharacterCreationData {
    public character: any | null = null;
    public stats: any[] = [];
    private oceanScores: any;
    private oceanProfile: OceanProfile | undefined;

    constructor(oceanScores: any, oceanProfile?: OceanProfile) {
        this.oceanScores = oceanScores;
        this.oceanProfile = oceanProfile;
        this.generateNewCharacter();
    }
    
    private determineConflictMapping(profile: OceanProfile) {
        const database = ServiceFactory.create<DatabaseService>('DatabaseService');
        const mappingTable = database.getTable('tblOCEAN_ConflictMapping');
        if (!mappingTable) {
            console.error("Conflict mapping table not found!");
            return { strength: 'Man vs Self', likes_1: 'Man vs Self', likes_2: 'Man vs Self', abhors: 'Man vs Self' };
        }
        
        const profileString = [profile.o, profile.c, profile.e, profile.a, profile.n];
        
        const record = mappingTable.query((r: any) => 
            r.O === profileString[0] &&
            r.C === profileString[1] &&
            r.E === profileString[2] &&
            r.A === profileString[3] &&
            r.N === profileString[4]
        )[0];

        if (record) {
            return {
                strength: record.strength,
                likes_1: record.likes_1,
                likes_2: record.likes_2,
                abhors: record.abhors
            };
        }

        return { strength: 'Man vs Self', likes_1: 'Man vs Society', likes_2: 'Man vs Nature', abhors: 'Man vs Technology' };
    }

    public generateNewCharacter() {
        const characterGenerator = ServiceFactory.create<CharacterGenerationService>('CharacterGenerationService');
        const database = ServiceFactory.create<DatabaseService>('DatabaseService');
        
        if (characterGenerator && database) {
            const conflictMapping = this.oceanProfile ? this.determineConflictMapping(this.oceanProfile) : undefined;
            
            const charId = characterGenerator.generateCharacter(this.oceanScores, conflictMapping);
            const character = database.getTable('characters').find(charId);
            
            const stats = [
                { name: 'Qi Points', value: character.qi_points, max: 1000, group: 'Spiritual' },
                { name: 'Cultivation Level', value: character.cultivation_level, max: 100, group: 'Spiritual' },
                { name: 'Spiritual Roots', value: character.spiritual_roots_value, max: 100, group: 'Spiritual' },
                { name: 'Meridian Purity', value: character.meridian_purity, max: 100, group: 'Spiritual' },
                { name: 'Elemental Affinity', value: character.elemental_affinity, max: 100, group: 'Spiritual' },
                { name: 'Soul Strength', value: character.soul_strength, max: 100, group: 'Mental' },
                { name: 'Dao Comprehension', value: character.dao_comprehension, max: 100, group: 'Mental' },
                { name: 'Mental Fortitude', value: character.mental_fortitude, max: 100, group: 'Mental' },
                { name: 'Karmic Burden', value: character.karmic_burden, max: 100, group: 'Metaphysical' },
                { name: 'Heavenly Tribulation', value: character.heavenly_tribulation, max: 100, group: 'Metaphysical' },
                { name: 'Fate Threads', value: character.fate_threads, max: 100, group: 'Metaphysical' },
                { name: 'Body Tempering', value: character.body_tempering, max: 100, group: 'Physical' },
                { name: 'Physical Resilience', value: character.physical_resilience, max: 100, group: 'Physical' }
            ];
            
            this.character = character;
            this.stats = stats;
        }
    }
}