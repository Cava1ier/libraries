





import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { ServiceFactory } from '../../core/ServiceFactory';
import { LocalizationService } from '../../services/LocalizationService';

interface SplashScreenProps {
    loadingMessage?: string;
    pluginManager?: PluginManager;
}

interface SplashScreenState {
    minTimeElapsed: boolean;
}

export class SplashScreen extends Component<SplashScreenProps, SplashScreenState> {
 prefix = 'splash';

    state: SplashScreenState = {
        minTimeElapsed: false
    };

    // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
    componentDidMount() {
        setTimeout(() => {
            this.setState({ minTimeElapsed: true });
        }, 3000); 
    }

    // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
    componentDidUpdate(prevProps: SplashScreenProps, prevState: SplashScreenState) {
        this.tryTransition();
    }

    // FIX: Converted arrow function to a standard class method.
    tryTransition() {
        const { pluginManager, loadingMessage } = this.props;
        const { minTimeElapsed } = this.state;

        if (pluginManager && !loadingMessage && minTimeElapsed) {
            pluginManager.loadPage('menu');
        }
    };

    // FIX: Converted arrow function to a standard class method for lifecycle events to ensure correct type inference.
    render() {
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('h1', { className: this.cls('title') }, localizationService.get('splash_title')),
            React.createElement('h2', { className: this.cls('subtitle') }, localizationService.get('splash_subtitle')),
            React.createElement('div', { className: this.cls('collaborator-1') }, localizationService.get('splash_creator')),
            React.createElement('div', { className: this.cls('collaborator-2') }, localizationService.get('splash_engine')),
            this.props.loadingMessage && React.createElement('div', { className: this.cls('spinner') }),
            this.props.loadingMessage && React.createElement('p', { className: this.cls('loading-text') }, this.props.loadingMessage)
        );
    }
}