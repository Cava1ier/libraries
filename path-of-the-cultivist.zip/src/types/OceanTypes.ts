

export interface OceanScores {
  o: number;
  c: number;
  e: number;
  a: number;
  n: number;
}

export interface OceanProfile {
  o: 'L' | 'M' | 'H';
  c: 'L' | 'M' | 'H';
  e: 'L' | 'M' | 'H';
  a: 'L' | 'M' | 'H';
  n: 'L' | 'M' | 'H';
  profileId: string;
}

export interface Answer {
  text: string;
  scores: Partial<OceanScores>;
}

export interface Question {
  id: number;
  // FIX: Added 'interactive_minigame' to the union type to match its usage in OCEANQuestionnaire.tsx.
  type: 'multiple' | 'binary' | 'passive' | 'minigame' | 'interactive_minigame';
  title: string;
  context: string;
  answers: Answer[];
  trait?: keyof OceanScores;
  conflict: string;
}

export interface GameState {
  currentQuestionIndex: number;
  scores: OceanScores;
  isComplete: boolean;
  profile?: OceanProfile;
}