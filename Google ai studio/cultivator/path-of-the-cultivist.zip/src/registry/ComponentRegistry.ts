
import React from 'react';

export class ComponentRegistry {
    private components = new Map<string, React.ComponentType>();
    
    // Using a singleton pattern to ensure one registry instance.
    private static instance: ComponentRegistry;
    public static getInstance(): ComponentRegistry {
        if (!ComponentRegistry.instance) {
            ComponentRegistry.instance = new ComponentRegistry();
        }
        return ComponentRegistry.instance;
    }

    register(name: string, component: React.ComponentType) {
        if (this.components.has(name)) {
            console.warn(`Component '${name}' is being re-registered.`);
        }
        this.components.set(name, component);
    }

    get(name: string): React.ComponentType | undefined {
        return this.components.get(name);
    }
}