
import { GeneratedCharacter } from "../systems/generation/character/Character.types";

// ===== RELATIONSHIP & SOCIAL TYPES =====

export interface Relationship {
    id: string;
    sourceCharacterId: string;
    targetCharacterId: string;
    type: RelationshipType;
    strength: number; // -100 to 100
    history: RelationshipEvent[];
    tags: string[];
    isActive: boolean;
    createdAt: number;
    lastInteraction: number;
}
  
export enum RelationshipType {
    FAMILY = 'family',
    ROMANTIC = 'romantic',
    FRIENDSHIP = 'friendship',
    RIVALRY = 'rivalry',
    MENTOR_STUDENT = 'mentor_student',
    MASTER_SERVANT = 'master_servant',
    ALLIANCE = 'alliance',
    ENEMY = 'enemy',
    BUSINESS = 'business',
    SECT_MEMBER = 'sect_member'
}

export interface RelationshipEvent {
    type: 'meeting' | 'conflict' | 'cooperation' | 'betrayal' | 'reconciliation';
    description: string;
    strengthChange: number;
    timestamp: number;
    location?: string;
}
  
export interface SocialNetwork {
    characterId: string;
    relationships: Map<string, Relationship>;
    socialRank: number;
    influence: number;
    reputation: Record<string, number>; // reputation in different circles
}

// ===== FACTION & ORGANIZATION TYPES =====

export enum FactionGoalType {
    EXPAND_TERRITORY = 'expand_territory',
    GATHER_RESOURCES = 'gather_resources',
    INCREASE_INFLUENCE = 'increase_influence',
    ATTACK_RIVAL = 'attack_rival',
}

export interface FactionGoal {
    type: FactionGoalType;
    targetId?: string;
    progress: number; // 0-100
    startedAt: number;
}

export interface Faction {
    id: string;
    name: string;
    type: FactionType;
    description: string;
    ideology: FactionIdeology;
    powerLevel: number;
    territory: Territory[];
    members: FactionMember[];
    relationships: Map<string, FactionRelationship>;
    resources: FactionResources;
    goals: FactionGoal[];
    history: FactionEvent[];
    isActive: boolean;
    currentGoal?: FactionGoal;
    lastAiUpdate?: number;
}
  
export enum FactionType {
    SECT = 'sect',
    CLAN = 'clan',
    EMPIRE = 'empire',
    MERCHANT_GUILD = 'merchant_guild',
    DEMONIC_CULT = 'demonic_cult',
    RIGHTEOUS_ALLIANCE = 'righteous_alliance',
    ROGUE_ORGANIZATION = 'rogue_organization',
    ACADEMIC_INSTITUTION = 'academic_institution'
}
  
export interface FactionIdeology {
    alignment: 'righteous' | 'demonic' | 'neutral';
    primaryValues: string[];
    conflictApproach: 'aggressive' | 'defensive' | 'diplomatic' | 'opportunistic';
    recruitmentPolicy: 'exclusive' | 'selective' | 'open' | 'hereditary';
}
  
export interface FactionMember {
    characterId: string;
    rank: string;
    joinDate: number;
    loyalty: number; // 0-100
}

export interface FactionResources {
    wealth: number;
    influence: number;
    militaryStrength: number;
    knowledgeBase: number;
    spiritualPower: number;
    territories: number;
}
  
export interface Territory {
    name: string;
    bounds: { x: [number, number]; y: [number, number] };
    controlLevel: number; // 0-100
    strategicValue: number;
    resources: string[];
}

export interface FactionRelationship {
    sourceId: string;
    targetId: string;
    type: string; // 'alliance', 'hostile', 'neutral', etc.
    strength: number; // -100 to 100
    isPublic: boolean;
    history: any[];
    lastUpdate: number;
}

export interface FactionGoal {}
export interface FactionEvent {}

// For FactionGenerator
export interface FactionTemplate {
    type: FactionType;
    ideology: FactionIdeology;
    basePowerLevel: number;
    baseResources: FactionResources;
    leaderRank: string;
    namePatterns: string[];
    leadershipRequirements?: {
        minExtraversion?: number;
        minConscientiousness?: number;
        minOpenness?: number;
    };
    description: string;
}