

export enum GameState {
    Exploring,
    Combat,
    Dialogue,
}

export enum ItemType {
    Stick = 1, Stone, Berry, Herb, Coin, IronSword, LeatherArmor, Scroll, Gem, QiSeed,
    SpiritwoodLog, SpiritwoodSword, IronOre,
}

export enum ItemQuality {
    Poor = 1, Common, Good, Rare, Epic,
}

export enum QuestType {
    Exploration = 1, Combat, Collection,
}

export enum SkillType {
    Swordsmanship = 1, Archery, Dodging, Climbing, Swimming, Herbalism
}

export enum BonusType { Stat, Damage, Defense, Dialogue, Gathering }
export enum CriticalType { None, Success, Failure }

export interface SkillBonus {
    type: BonusType;
    value: number;
    requiredLevel: number;
}

export interface SkillGainResult {
    experienceGained: number;
    leveledUp: boolean;
    newLevel: number;
    bonusesUnlocked: SkillBonus[];
}

export interface SkillCheckResult {
    succeeded: boolean;
    roll: number;
    total: number;
    margin: number;
    critical: boolean;
    criticalType: CriticalType;
}

export interface StatusEffect {
  type: 'poisoned' | 'defending' | string;
  turns: number;
  damage?: number;
}


// ===== ENTITY & CHARACTER TYPES =====
export interface EntityStats {
  health: number;
  maxHealth: number;
  attack: number;
  defense: number;
  speed: number;
  energy: number;
}

export interface PlayerData {
  id: string;
  position: { x: number; y: number; };
  stats: EntityStats;
  level: number;
  experience: number;
  skills: Map<string, number>;
}

export interface CreatureData {
  id: string; // Unique instance ID
  typeId: number; // From tblCreatureTypes
  name: string;
  isHostile: boolean;
  stats: EntityStats;
  position: { x: number; y: number; z: number; };
  statusEffects?: StatusEffect[];
  factionId?: string;
  lastMoveTimestamp?: number;
  passthroughTimestamp?: number;
}

// ===== ITEM & INVENTORY TYPES =====
export interface ItemData {
  id: string;
  typeId: number;
  quantity: number;
  qualityId: number;
}

// FIX: Exporting the LootEntry interface to make it accessible to other modules.
export interface LootEntry {
    itemId: ItemType;
    weight: number;
    minRoll: number;
}

// ===== QUEST TYPES =====
export interface QuestRequirement {
    type: 'visit_site' | 'kill_creature' | string;
    target: string;
    count: number;
}

export interface QuestReward {
    type: 'experience' | 'item';
    amount?: number;
    itemId?: ItemType;
    count?: number;
}

export interface QuestTemplate {
    id: string;
    title: string;
    description: string;
    typeId: QuestType;
    requirements: QuestRequirement[];
    rewards: QuestReward[];
}

export interface QuestData {
  id: string | number;
  name: string;
  description: string;
  objective_type: 'COLLECT' | 'HUNT';
  objective_target: string;
  objective_count: number;
  reward_xp: number;
  reward_item_id: number;
  reward_item_count: number;
  progress: { [key: string]: number };
  end_npc_id?: number;
  title?: string;
  typeId?: QuestType;
  requirements?: QuestRequirement[];
  isComplete?: boolean;
  targetLocation?: { x: number; y: number; };
  // FIX: Added rewards property to match QuestTemplate and support reward logic.
  rewards?: QuestReward[];
}


// ===== COMBAT TYPES =====
export interface CombatParticipant {
    id: string;
    entity: any;
    isPlayer: boolean;
    stats: EntityStats;
    initiative: number;
    statusEffects: StatusEffect[];
}

export interface CombatResult {
    hit: boolean;
    damage: number;
    remainingHealth: number;
    isFatal: boolean;
}

export interface CombatEncounter {
  id: string;
  participants: CombatParticipant[];
  turnIndex: number;
  log: string[];
  isActive: boolean;
}


// ===== DIALOGUE TYPES =====
export interface DialogueOption {
    text: string;
    action: () => void;
    skillCheck?: {
        skill: SkillType;
        difficulty: number;
    };
    disabled?: boolean;
    disabledText?: string;
}

export interface DialogueState {
    npc: CreatureData;
    text: string;
    quest?: any;
    options: DialogueOption[];
}

// ===== AI TYPES =====
export interface AIGoal {
    typeId: number;
    target: any | null;
    priority: number;
    startTime: number;
}