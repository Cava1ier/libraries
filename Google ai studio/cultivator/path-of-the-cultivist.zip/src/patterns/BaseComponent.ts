

import React from 'react';
import { ComponentFactory } from '../core/ComponentFactory';
import { ComponentRegistry } from '../registry/ComponentRegistry';

export abstract class BaseComponent<P = {}, S = {}> extends React.Component<P, S> {
  protected registry: ComponentRegistry = ComponentRegistry.getInstance();
  
  protected createChild(type: any, props?: any): React.ReactElement {
    // FIX: ComponentFactory has static methods and should not be instantiated.
    return ComponentFactory.create({ type, variant: 'default', props });
  }
  
  protected registerSelf(): void {
    this.registry.register(this.constructor.name, this.constructor as any);
  }
}