import React from 'react';
import { Component } from './core/Component';
import { AppData } from './dataApp';
import { ErrorBoundary } from './components/ErrorBoundary/ErrorBoundary';
import { ServiceFactory } from './core/ServiceFactory';
import { LocalizationService } from './services/LocalizationService';

interface AppState {
    appData: AppData | null;
}

export default class App extends Component<{}, AppState> {
    prefix = 'app-root';

    state: AppState = {
        appData: null
    };

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    componentDidMount() {
        const appData = new AppData(() => this.forceUpdate());
        this.setState({ appData });
        appData.initializeApp();
    }

    // FIX: Converted to arrow function to fix 'this' context.
    private renderLoading = () => {
        const { appData } = this.state;
        const loadingText = appData ? appData.loadingMessage : 'Initializing Application...';
        return React.createElement('div', { style: { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', width: '100vw', backgroundColor: '#35355e', color: '#ffffff', fontFamily: 'sans-serif', fontSize: '1.2rem'} },
            loadingText
        );
    }

    // FIX: Converted to arrow function to fix 'this' context.
    private renderApp = () => {
        const { appData } = this.state;
        if (!appData?.pluginManager) return null;

        const currentPage = appData.pluginManager.getCurrentPage();
        
        if (currentPage) {
            const { component, props } = currentPage;
            const finalProps = { ...props, appData, gameState: appData.gameState, pluginManager: appData.pluginManager };
            
            return React.createElement(ErrorBoundary, { pluginManager: appData.pluginManager },
                React.createElement(component, finalProps)
            );
        }
        
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        return React.createElement('div', {}, localizationService.get('error_no_page', {fallback: 'Error: No page could be loaded.'}));
    }

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { appData } = this.state;
        const isLoading = !appData || appData.isLoading || !appData.pluginManager;
        
        return isLoading ? this.renderLoading() : this.renderApp();
    }
}