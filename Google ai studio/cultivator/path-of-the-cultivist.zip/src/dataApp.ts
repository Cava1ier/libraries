import React from 'react';
import { PluginManager, Plugin } from './systems/plugin/PluginSystem';
import { SplashScreen } from './components/SplashScreen/SplashScreen';
import { MainMenu } from './components/MainMenu/MainMenu';
import { CharacterCreation } from './components/CharacterCreation/CharacterCreation';
import { AboutScreen } from './components/AboutScreen/AboutScreen';
import { GameWorld } from './components/GameWorld/GameWorld';
import { OCEANQuestionnaire } from './components/OCEANQuestionnaire/OCEANQuestionnaire';
import { ErrorPage } from './components/ErrorPage/ErrorPage';

import { registerServices } from './services/registerServices';
import { ServiceFactory } from './core/ServiceFactory';
import { GameCoordinatorService, GameCoordinatorContext } from './services/GameCoordinatorService';
import { SaveData, SaveService } from './services/SaveService';
import { DatabaseService } from './services/DatabaseService';
import { TileConfigRegistry } from './systems/tiles/TileConfigRegistry';
import { WorldService } from './services/WorldService';
import { FactionService } from './services/FactionService';
import { FactionSystemService } from './services/FactionSystemService';
import { CreatureService } from './services/CreatureService';
import { CreatureData } from './types/AdventureTypes';
import { QuestService } from './services/QuestService';
import { InventoryService } from './services/InventoryService';
import { WeatherService } from './services/WeatherService';
import { LocalizationService } from './services/LocalizationService';
import { ALL_STYLES } from './styles/AppStyles';
import { AppComponentLoader } from './systems/loader/AppComponentLoader';
import { DomService } from './services/DomService';

export class AppData {
    public gameCoordinator: GameCoordinatorService | null = null;
    public pluginManager: PluginManager | null = null;
    public isLoading: boolean = true;
    public loadingMessage: string = 'Initializing...';
    private forceUpdate: () => void;
    
    public get saveSystem(): SaveService { return ServiceFactory.create('SaveService'); }
    public get gameState(): any { return this.gameCoordinator; }

    constructor(forceUpdate: () => void) {
        this.forceUpdate = forceUpdate;
    }

    public async initializeApp() { await this.setupGame(null); }
    
    public async loadGame() {
        this.setLoading('Loading Saved Game...');
        const savedData = this.saveSystem.loadGame(1);
        if (savedData) await this.setupGame(savedData);
        else {
            this.setLoading('Load failed. Starting new game.', true);
            setTimeout(() => this.initializeApp(), 1500);
        }
    }

    private async setupGame(savedData: SaveData | null) {
        this.setLoading('Initializing...');
        
        try {
            this.injectGlobalStyles();
            await this._registerAndLoadCoreSystems();
            this._initializeWorld(savedData);
            this._setupUIManager(savedData);
        } catch (error) {
            console.error("Fatal initialization error:", error);
            this._handleInitializationError(error as Error);
        }
    }

    private async _registerAndLoadCoreSystems() {
        this.setLoading('Registering Services...');
        ServiceFactory.clear();
        registerServices();

        const domHandler = ServiceFactory.create<DomService>('DomService').handler;

        // Load all component styles centrally using the new StyleRegistry
        ALL_STYLES.forEach(styleDef => {
            const stylesString = styleDef.styles.join(';');
            const classNames = styleDef.classnames;
            const cssValues = styleDef.styleValues.map((valueArray: (string | null)[]) => {
                return valueArray.map(v => v === null ? 'null' : v).join(',');
            });

            AppComponentLoader.styleRegistry.registerStyles(
                styleDef.prefix,
                stylesString,
                classNames,
                cssValues
            );
        });
        
        domHandler.injectStylesheet(AppComponentLoader.styleRegistry);
        
        const lang = localStorage.getItem('language') || 'English';
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        await localizationService.loadLanguage(lang);

        this.loadingMessage = localizationService.get('initializing');
        this.forceUpdate();

        this.setLoading('Creating Core Systems...');
        const database = ServiceFactory.create<DatabaseService>('DatabaseService');
        database.setLanguage(lang);
        await database.loadDatabase();
        
        this.setLoading('Initializing Tile System...');
        TileConfigRegistry.initializeDefaultConfigs(database);
    }

    private _initializeWorld(savedData: SaveData | null) {
        this.setLoading('Populating World...');
        const worldService = ServiceFactory.create<WorldService>('WorldService');
        const creatureService = ServiceFactory.create<CreatureService>('CreatureService');
        worldService.setCreatureService(creatureService);

        if (!savedData) {
            const factionGenerator = ServiceFactory.create<FactionService>('FactionService');
            const factionSystem = ServiceFactory.create<FactionSystemService>('FactionSystemService');
            const database = ServiceFactory.create<DatabaseService>('DatabaseService');
            const allCharacters = database.getTable('characters').findAll();
            const startRegion = { x: [120, 140] as [number, number], y: [120, 140] as [number, number] };
            const factions = factionGenerator.generateFactionsForRegion(startRegion, allCharacters, 3);
            factionSystem.setFactions(factions);
            creatureService.spawnRovingNPCs(5);
        }
    }

    private _setupUIManager(savedData: SaveData | null) {
        this.setLoading('Loading UI...', false);
        const pm = new PluginManager(this.forceUpdate);
        const plugins: Plugin[] = [
            { id: 'splash', component: SplashScreen }, { id: 'menu', component: MainMenu },
            { id: 'questionnaire', component: OCEANQuestionnaire }, { id: 'character-creation', component: CharacterCreation },
            { id: 'about', component: AboutScreen }, { id: 'game-world', component: GameWorld },
            { id: 'error', component: ErrorPage }
        ];
        plugins.forEach(p => pm.registerPlugin(p));
        this.pluginManager = pm;

        if (savedData) {
            this.pluginManager.loadPage('game-world', { savedData });
        } else {
            this.pluginManager.loadPage('splash');
        }
    }

    private _handleInitializationError(error: Error) {
        this.pluginManager = new PluginManager(this.forceUpdate);
        this.pluginManager.registerPlugin({id: 'error', component: ErrorPage});
        this.pluginManager.loadPage('error', { message: error.message });
        this.setLoading('Error', false);
    }

    public createGameWorld(context: GameCoordinatorContext, savedData?: SaveData) {
        if(savedData) {
            ServiceFactory.create<QuestService>('QuestService').setActiveQuests(savedData.quests);
            ServiceFactory.create<InventoryService>('InventoryService').setItems(savedData.inventory);
            ServiceFactory.create<WeatherService>('WeatherService').setTime(savedData.time);

            if (savedData.factions) {
                const factions = savedData.factions.map((f: any) => ({ ...f, relationships: new Map(f.relationships) }));
                ServiceFactory.create<FactionSystemService>('FactionSystemService').loadFactionsFromSave(factions);
            }
            if (savedData.creatures) {
                const creatureService = ServiceFactory.create<CreatureService>('CreatureService');
                creatureService.creatures.clear();
                savedData.creatures.forEach((c: CreatureData) => creatureService.creatures.set(`${c.position.x},${c.position.y},${c.position.z}`, c));
            }
        }
        this.gameCoordinator = ServiceFactory.create('GameCoordinatorService', context);
    }

    private setLoading(message: string, isLoading: boolean = true) {
        this.loadingMessage = message;
        this.isLoading = isLoading;
        this.forceUpdate();
    }
    
    private injectGlobalStyles() {
        const keyframes = `
         @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
         @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
         @keyframes slideUp { from { transform: translateY(50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
         @keyframes pulse { 0%,100% { text-shadow: 0 0 4px #d4af37; border-color: #d4af37; } 50% { text-shadow: 0 0 12px #fff, 0 0 20px #d4af37; border-color: #fff; } }
         @keyframes shimmer { 0%,100% { background-color: #87CEEB; } 50% { background-color: #ADD8E6; } }
         @keyframes growAndFadeIn { from { transform: scale(0.2); opacity: 0; } to { transform: scale(1); opacity: 1; } }
         @keyframes combatGlow { 0%,100% { box-shadow: 0 0 3px rgba(212,175,55,0.4); } 50% { box-shadow: 0 0 10px rgba(255,255,255,0.7), 0 0 15px rgba(212,175,55,0.6); } }`;
        const styleId = 'cultivist-global-styles';
        if (!document.getElementById(styleId)) {
            const style = document.createElement('style');
            style.id = styleId;
            style.textContent = keyframes;
            document.head.appendChild(style);
        }
    }
}