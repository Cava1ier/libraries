
interface FrameworkConfig {
  registry: {
    autoRegister: boolean;
    scanPaths: string[];
    excludePatterns: string[];
  };
  factory: {
    enableCaching: boolean;
    lazyLoading: boolean;
    preloadComponents: string[];
  };
  documentation: {
    autoGenerate: boolean;
    outputPath: string;
    includePrivate: boolean;
  };
  development: {
    hotReload: boolean;
    debugMode: boolean;
    logLevel: 'error' | 'warn' | 'info' | 'debug';
  };
}

export class AppConfig {
  private static config: FrameworkConfig;
  
  static initialize(config: Partial<FrameworkConfig>): void {
    this.config = { ...this.getDefaults(), ...config };
  }

  static get<K extends keyof FrameworkConfig>(key: K): FrameworkConfig[K] {
    if (!this.config) {
        this.initialize({});
    }
    return this.config[key];
  }

  static update<K extends keyof FrameworkConfig>(
    key: K, 
    value: Partial<FrameworkConfig[K]>
  ): void {
    if (!this.config) {
        this.initialize({});
    }
    this.config[key] = { ...this.config[key], ...value };
  }

  private static getDefaults(): FrameworkConfig {
    return {
        registry: {
            autoRegister: false,
            scanPaths: [],
            excludePatterns: [],
        },
        factory: {
            enableCaching: true,
            lazyLoading: false,
            preloadComponents: [],
        },
        documentation: {
            autoGenerate: false,
            outputPath: './docs',
            includePrivate: false,
        },
        development: {
            hotReload: true,
            debugMode: false,
            logLevel: 'info',
        },
    };
  }
}
