
export class KeyMappingRegistry {
  private static movementKeys = new Map<string, {dx: number, dy: number}>([
    ['arrowup', {dx: 0, dy: -1}], ['w', {dx: 0, dy: -1}],
    ['arrowdown', {dx: 0, dy: 1}], ['s', {dx: 0, dy: 1}],
    ['arrowleft', {dx: -1, dy: 0}], ['a', {dx: -1, dy: 0}],
    ['arrowright', {dx: 1, dy: 0}], ['d', {dx: 1, dy: 0}],
    ['q', {dx: -1, dy: -1}], ['e', {dx: 1, dy: -1}],
    ['z', {dx: -1, dy: 1}], ['c', {dx: 1, dy: 1}],
  ]);

  private static modeKeys = new Map<string, string>([
    ['l', 'toggle_mode'],
    ['escape', 'escape'],
  ]);

  private static viewKeys = new Map<string, string>([
    [',', 'view_down'], ['<', 'view_down'],
    ['.', 'view_up'], ['>', 'view_up'],
  ]);

  static getMovement(key: string) { return this.movementKeys.get(key.toLowerCase()); }
  static getModeAction(key: string) { return this.modeKeys.get(key.toLowerCase()); }
  static getViewAction(key: string) { return this.viewKeys.get(key.toLowerCase()); }
}