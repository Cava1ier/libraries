import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { OCEANQuestionnaireData } from './dataOCEANQuestionnaire';
import { Question } from '../../types/OceanTypes';
import { ServiceFactory } from '../../core/ServiceFactory';
import { DatabaseService } from '../../services/DatabaseService';
import { RNGService } from '../../services/RNGService';
import { LocalizationService } from '../../services/LocalizationService';

const MINIGAME_SYMBOLS = ['水', '火', '木', '金', '土'];
const MINIGAME_SEQUENCE_LENGTH = 4;

interface OCEANQuestionnaireProps {
    gameState?: any;
    pluginManager: PluginManager;
}

interface MinigameState {
    status: 'idle' | 'showing' | 'playing' | 'finished';
    sequence: string[];
    playerSequence: string[];
    message: string;
}

interface OCEANQuestionnaireState {
    questionKey: number;
    data: OCEANQuestionnaireData | null;
    isAutoAnswering: boolean;
    minigameState: MinigameState;
}

export class OCEANQuestionnaire extends Component<OCEANQuestionnaireProps, OCEANQuestionnaireState> {
    prefix = 'ocean-q';

    state: OCEANQuestionnaireState = {
        questionKey: 0,
        data: null,
        isAutoAnswering: false,
        minigameState: {
            status: 'idle',
            sequence: [],
            playerSequence: [],
            message: ''
        }
    };
    
    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    componentDidMount() {
        const database = ServiceFactory.create<DatabaseService>('DatabaseService');
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        const initialMinigameState = {
            ...this.state.minigameState,
            message: localizationService.get('minigame_message_initial')
        };
        this.setState({ 
            data: new OCEANQuestionnaireData(database),
            minigameState: initialMinigameState
        });
    }

    // FIX: Converted to arrow function to fix 'this' context.
    handleAnswer = (answerIndex: number) => {
        if (!this.state.data || this.state.isAutoAnswering) return;
        this.state.data.answerQuestion(answerIndex);
        this.setState(prevState => ({ questionKey: prevState.questionKey + 1, data: this.state.data }));
    }

    // FIX: Kept as an arrow function as it's passed directly as an event handler.
    handleAutoAnswer = () => {
        if (!this.state.data) return;
        this.setState({ isAutoAnswering: true });
        
        const answerInterval = setInterval(() => {
            if (!this.state.data || this.state.data.getGameState().isComplete) {
                clearInterval(answerInterval);
                this.setState({ isAutoAnswering: false });
                return;
            }

            const currentQuestion = this.state.data.getCurrentQuestion();
            if (currentQuestion) {
                const rng = ServiceFactory.create<RNGService>('RNGService');
                const randomIndex = rng.next() % currentQuestion.answers.length;
                this.handleAnswer(randomIndex);
            }
        }, 1200);
    }

    // FIX: Kept as an arrow function as it's passed directly as an event handler.
    startMinigame = () => {
        const rng = ServiceFactory.create<RNGService>('RNGService');
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        const newSequence = Array.from({ length: MINIGAME_SEQUENCE_LENGTH }, () => MINIGAME_SYMBOLS[rng.next() % MINIGAME_SYMBOLS.length]);
        
        this.setState({
            minigameState: {
                status: 'showing',
                sequence: newSequence,
                playerSequence: [],
                message: localizationService.get('minigame_message_showing')
            }
        });
        
        let i = 0;
        const showInterval = setInterval(() => {
            const symbolDisplay = document.getElementById('minigame-symbol');
            if(symbolDisplay) {
                if (i < newSequence.length) {
                    symbolDisplay.textContent = newSequence[i];
                    symbolDisplay.style.opacity = '1';
                    setTimeout(() => { if(symbolDisplay) symbolDisplay.style.opacity = '0'; }, 600);
                    i++;
                } else {
                    clearInterval(showInterval);
                    this.setState(prevState => ({ minigameState: { ...prevState.minigameState, status: 'playing', message: localizationService.get('minigame_message_playing') }}));
                }
            } else {
                clearInterval(showInterval);
            }
        }, 800);
    }

    // FIX: Converted to arrow function to fix 'this' context.
    handleMinigameInput = (symbol: string) => {
        const { minigameState } = this.state;
        if (minigameState.status !== 'playing') return;

        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        const newPlayerSequence = [...minigameState.playerSequence, symbol];
        
        if (newPlayerSequence[newPlayerSequence.length - 1] !== minigameState.sequence[newPlayerSequence.length - 1]) {
            this.setState(prevState => ({ minigameState: { ...prevState.minigameState, status: 'finished', message: localizationService.get('minigame_message_finished_fail') }}));
            this.handleAnswer(1); // Failure answer
            return;
        }

        if (newPlayerSequence.length === minigameState.sequence.length) {
            this.setState(prevState => ({ minigameState: { ...prevState.minigameState, status: 'finished', message: localizationService.get('minigame_message_finished_success') }}));
            this.handleAnswer(0); // Success answer
            return;
        }

        this.setState(prevState => ({ minigameState: { ...prevState.minigameState, playerSequence: newPlayerSequence }}));
    }

    // FIX: Converted to arrow function to fix 'this' context.
    renderMinigame = (question: Question) => {
        const { minigameState } = this.state;
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        
        return React.createElement('div', { className: this.cls('minigame-container') },
            React.createElement('h3', { className: this.cls('question-title') }, localizationService.get(question.title)),
            React.createElement('p', { className: this.cls('question-context') }, localizationService.get(question.context)),
            React.createElement('div', { id: 'minigame-symbol-display', className: this.cls('minigame-symbol-display') },
                React.createElement('span', { id: 'minigame-symbol', className: this.cls('minigame-symbol'), style: { opacity: 0 } }, '')
            ),
            React.createElement('p', { className: this.cls('minigame-message') }, minigameState.message),
            minigameState.status === 'playing' && React.createElement('div', { className: this.cls('minigame-input-container') },
                ...MINIGAME_SYMBOLS.map(symbol => React.createElement('button', {
                    key: symbol,
                    className: this.cls('minigame-input-button'),
                    onClick: () => this.handleMinigameInput(symbol)
                }, symbol))
            ),
            minigameState.status === 'idle' && React.createElement('button', {
                className: this.cls('choice-button'),
                onClick: this.startMinigame
            }, localizationService.get(question.answers[0].text)),
             minigameState.status === 'finished' && React.createElement('button', {
                className: this.cls('choice-button'),
                onClick: () => this.setState({ minigameState: { ...minigameState, status: 'idle', message: localizationService.get('minigame_message_initial') }})
            }, localizationService.get('minigame_button_continue'))
        );
    }
    
    // FIX: Converted to arrow function to fix 'this' context.
    renderQuestion = (question: Question) => {
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        return React.createElement('div', { key: this.state.questionKey, className: this.cls('question-content') },
            React.createElement('h3', { className: this.cls('question-title') }, localizationService.get(question.title)),
            React.createElement('p', { className: this.cls('question-context') }, localizationService.get(question.context)),
            React.createElement('div', { className: this.cls('choice-container') },
                ...question.answers.map((answer, index) =>
                    React.createElement('button', {
                        key: index,
                        className: this.cls('choice-button'),
                        onClick: () => this.handleAnswer(index)
                    }, localizationService.get(answer.text))
                )
            )
        );
    }

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { data, isAutoAnswering } = this.state;
        const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
        if (!data) return React.createElement('div', {}, localizationService.get('loading'));

        const gameState = data.getGameState();
        const progress = data.getProgress();

        if (gameState.isComplete && gameState.profile) {
            this.props.pluginManager.loadPage('character-creation', { oceanScores: gameState.scores, oceanProfile: gameState.profile });
            return null;
        }

        const currentQuestion = data.getCurrentQuestion();
        const phase = data.getPhase();
        const phaseName = localizationService.get(phase.name);
        const progressText = localizationService.get('ocean_progress', { current: gameState.currentQuestionIndex + 1, total: data.getTotalQuestions() });

        return React.createElement('div', { className: this.cls('container') },
            React.createElement('div', { className: this.cls('panel') },
                React.createElement('div', { className: this.cls('panel-header') },
                    React.createElement('div', { className: this.cls('phase-indicator') }, localizationService.get('ocean_phase', { number: phase.number, name: phaseName })),
                    React.createElement('div', { className: this.cls('progress-counter') }, progressText),
                    React.createElement('div', { className: this.cls('progress-bar-container') },
                        React.createElement('div', { className: this.cls('progress-bar-fill'), style: { width: `${progress}%` } })
                    )
                ),
                
                React.createElement('div', { className: this.cls('panel-content') },
                    isAutoAnswering && React.createElement('div', { className: this.cls('oracle-thinking-container') },
                        React.createElement('div', { className: this.cls('oracle-spinner') }),
                        localizationService.get('ocean_oracle_thinking')
                    ),
                    
                    !isAutoAnswering && currentQuestion && (currentQuestion.type === 'interactive_minigame' 
                        ? this.renderMinigame(currentQuestion) 
                        : this.renderQuestion(currentQuestion))
                ),

                React.createElement('div', { className: this.cls('panel-footer') },
                    !isAutoAnswering && React.createElement('div', {
                        className: this.cls('auto-answer-text'),
                        onClick: this.handleAutoAnswer
                    }, localizationService.get('ocean_oracle_invoke'))
                )
            )
        );
    }
}