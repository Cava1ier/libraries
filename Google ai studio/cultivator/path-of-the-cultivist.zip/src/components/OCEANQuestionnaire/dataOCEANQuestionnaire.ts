import { DatabaseService } from "../../services/DatabaseService";
import { OceanScores, OceanProfile, GameState, Question, Answer } from '../../types/OceanTypes';

export class OCEANQuestionnaireData {
    public gameState: GameState;
    private questions: Question[];

    private phaseConfig = [
        { threshold: 4, name: 'ocean_phase_1', number: 1 },
        { threshold: 8, name: 'ocean_phase_2', number: 2 },
        { threshold: 12, name: 'ocean_phase_3', number: 3 },
        { threshold: 16, name: 'ocean_phase_4', number: 4 },
        { threshold: Infinity, name: 'ocean_phase_5', number: 5 },
    ];

    constructor(database: DatabaseService) {
        this.questions = this.loadData(database);
        this.gameState = this.initializeGameState();
    }

    private loadData(database: DatabaseService): Question[] {
        const questions: Question[] = [];
        const questionTable = database.getTable('tblOCEAN_Questions');
        const answerTable = database.getTable('tblOCEAN_Answers');

        if (!questionTable || !answerTable) {
            console.error("OCEAN Questionnaire tables not found in database.");
            return [];
        }

        questionTable.findAll().forEach((qRecord: any) => {
            const questionId = Number(qRecord.id);
            const answersForQuestion = answerTable.query((aRecord: any) => aRecord.question_id == questionId);
            
            const question: Question = {
                id: questionId,
                type: qRecord.type,
                title: qRecord.title,
                context: qRecord.context,
                trait: qRecord.trait,
                conflict: qRecord.conflict, // Load the new conflict field
                answers: answersForQuestion.map((aRecord: any) => ({
                    text: aRecord.text,
                    scores: this.parseScores(aRecord.scores)
                }))
            };
            
            questions.push(question);
        });
        
        questions.sort((a, b) => a.id - b.id);
        return questions;
    }

    private parseScores(scoreString: string): Partial<OceanScores> {
        const scores: Partial<OceanScores> = {};
        if (!scoreString) return scores;
        
        scoreString.split(',').forEach(part => {
            const [trait, value] = part.split(':');
            if (trait && value && ['o', 'c', 'e', 'a', 'n'].includes(trait)) {
                scores[trait as keyof OceanScores] = parseInt(value, 10);
            }
        });
        return scores;
    }

    private initializeGameState(): GameState {
        return {
            currentQuestionIndex: 0,
            scores: { o: 50, c: 50, e: 50, a: 50, n: 50 },
            isComplete: false
        };
    }

    public getCurrentQuestion(): Question | null {
        if (this.gameState.currentQuestionIndex >= this.questions.length) {
            return null;
        }
        return this.questions[this.gameState.currentQuestionIndex];
    }

    public answerQuestion(answerIndex: number): void {
        const currentQuestion = this.getCurrentQuestion();
        if (!currentQuestion || this.gameState.isComplete) return;

        if (answerIndex < 0 || answerIndex >= currentQuestion.answers.length) {
            console.error(`Invalid answer index ${answerIndex} for question ${currentQuestion.id}`);
            this.gameState.currentQuestionIndex++;
        } else {
            const selectedAnswer = currentQuestion.answers[answerIndex];
            
            // Nuanced Scoring: Apply a multiplier based on the current phase.
            // This makes questions later in the journey more impactful.
            const phase = this.getPhase().number;
            const multiplier = 1 + (phase - 1) * 0.1; // Phase 1: 1.0x, Phase 5: 1.4x

            const weightedScores: Partial<OceanScores> = {};
            for (const trait in selectedAnswer.scores) {
                const key = trait as keyof OceanScores;
                const originalScore = selectedAnswer.scores[key]!;
                weightedScores[key] = Math.round(originalScore * multiplier);
            }

            this.updateScores(weightedScores); // Use the new weighted scores
            this.gameState.currentQuestionIndex++;
        }

        if (this.gameState.currentQuestionIndex >= this.questions.length) {
            this.gameState.isComplete = true;
            this.gameState.profile = this.calculateProfile();
        }
    }

    private updateScores(answerScores: Partial<OceanScores>): void {
        Object.entries(answerScores).forEach(([trait, score]) => {
            if (score !== undefined) {
                const key = trait as keyof OceanScores;
                this.gameState.scores[key] = Math.max(0, Math.min(100, this.gameState.scores[key] + score));
            }
        });
    }

    private calculateProfile(): OceanProfile {
        const scores = this.gameState.scores;
        const profile: OceanProfile = {
            o: this.scoreToLevel(scores.o),
            c: this.scoreToLevel(scores.c),
            e: this.scoreToLevel(scores.e),
            a: this.scoreToLevel(scores.a),
            n: this.scoreToLevel(scores.n),
            profileId: ''
        };
        profile.profileId = `${profile.o[0]}${profile.c[0]}${profile.e[0]}${profile.a[0]}${profile.n[0]}`;
        return profile;
    }

    private scoreToLevel(score: number): 'L' | 'M' | 'H' {
        if (score <= 33) return 'L';
        if (score >= 67) return 'H';
        return 'M';
    }

    public getGameState(): GameState {
        return this.gameState;
    }

    public getProgress(): number {
        if (this.questions.length === 0) return 0;
        return (this.gameState.currentQuestionIndex / this.questions.length) * 100;
    }

    public getTotalQuestions(): number {
        return this.questions.length;
    }
    
    public getPhase(): { name: string, number: number } {
        const index = this.gameState.currentQuestionIndex;
        const phase = this.phaseConfig.find(p => index < p.threshold);
        // Fallback to the last phase if not found (should only happen for the last phase itself)
        return phase ? { name: phase.name, number: phase.number } : { name: 'ocean_phase_5', number: 5 };
    }
}