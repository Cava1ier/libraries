import React from 'react';
import { Component } from '../../core/Component';
import { GameWorldData } from './dataGameWorld';
import { TileConfigRegistry } from '../../systems/tiles/TileConfigRegistry';
import { MapRenderer } from '../../systems/renderer/MapRenderer';

const TILE_SIZE = 24;

interface GameWorldMapProps {
    data: GameWorldData;
    onTileClick: (worldX: number, worldY: number) => void;
}

type TileStyle = {
    color: string | null;
    bgColor: string | null;
    animation: string | null;
};

export class GameWorldMap extends Component<GameWorldMapProps, {}> {
    private canvasRef: React.RefObject<HTMLCanvasElement> = React.createRef();
    private renderer: MapRenderer | null = null;
    private animationFrameId: number = 0;
    
    prefix = 'game-world-map';

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    componentDidMount() {
        const canvas = this.canvasRef.current;
        if (canvas) {
            const tileStyles = new Map<string, TileStyle>();
            const tileConfigs = TileConfigRegistry.getAllConfigs();
            tileConfigs.forEach((config, type) => {
                tileStyles.set(type, {
                    color: config.styleValues[0] || '#FFFFFF',
                    bgColor: config.styleValues[1] || '#000000',
                    animation: config.styleValues[2] || null
                });
            });
            
            this.renderer = new MapRenderer(canvas, tileStyles);
            this.startAnimationLoop();
        }
    }

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    componentWillUnmount() {
        this.stopAnimationLoop();
    }
    
    // FIX: Converted to arrow function to fix 'this' context.
    startAnimationLoop = () => {
        const loop = () => {
            if (this.renderer) {
                this.renderer.draw(this.props.data);
            }
            this.animationFrameId = requestAnimationFrame(loop);
        };
        this.animationFrameId = requestAnimationFrame(loop);
    }
    
    // FIX: Converted to arrow function to fix 'this' context.
    stopAnimationLoop = () => {
        cancelAnimationFrame(this.animationFrameId);
    }

    // FIX: Kept as an arrow function as it's passed directly to onClick.
    handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
        const canvas = this.canvasRef.current;
        if (!canvas || !this.props.data) return;

        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;

        const tileX = Math.floor(x / TILE_SIZE);
        const tileY = Math.floor(y / TILE_SIZE);

        const { character, mapData } = this.props.data;
        const viewData = mapData.getMapViewData(character);
        
        const worldX = viewData.startX + tileX;
        const worldY = viewData.startY + tileY;

        this.props.onTileClick(worldX, worldY);
    }

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { data } = this.props;
        const modeIndicator = React.createElement('div', { className: this.cls('mode-indicator'), style:{textTransform: 'capitalize'}}, data.mapData.mode);
        
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('canvas', { ref: this.canvasRef, onClick: this.handleCanvasClick }),
            React.createElement('div', { className: this.cls('overlay-container') },
                modeIndicator
            )
        );
    }
}