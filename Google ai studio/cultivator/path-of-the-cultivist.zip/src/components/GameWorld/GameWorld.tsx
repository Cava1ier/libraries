import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { GameWorldMap } from './GameWorldMap';
import { GameWorldData } from './dataGameWorld';
import { CombatEncounter, DialogueState, ItemData, QuestData } from '../../types/AdventureTypes';
import { PANEL_SPECS } from '../../data/dPanelData';
import { TAB_SPECS } from '../../data/dTabData';
import { PanelFactory } from '../../data/dPanelFactory';
import { TabFactory } from '../../data/dTabFactory';
import { CombatPanel } from '../../ui/CombatPanel';
import { DialoguePanel } from '../../ui/DialoguePanel';
// FIX: QuestCompletionModal was not exported from its module.
import { QuestCompletionModal } from '../../ui/QuestCompletionModal';
import { ProgressionModal } from '../../ui/ProgressionModal';
import { CraftingModal } from '../../ui/CraftingModal';
import { ActionProgressPanel } from '../../ui/ActionProgressPanel';
import { AppComponentLoader } from '../../systems/loader/AppComponentLoader';
import { ServiceFactory } from '../../core/ServiceFactory';
import { WorldService } from '../../services/WorldService';
import { OceanProfile } from '../../types/OceanTypes';
import { MiniMap } from '../../ui/MiniMap';


interface GameWorldProps {
    gameState?: any;
    characterRecord?: any;
    pluginManager: PluginManager;
    appData: any;
}

interface GameWorldState {
    data: GameWorldData | null;
    activePanelId: string;
    activeCombat: CombatEncounter | null;
    activeDialogue: DialogueState | null;
    completedQuest: QuestData | null;
    isPanelCollapsed: boolean;
    isProgressionModalOpen: boolean;
    isCraftingModalOpen: boolean;
    isPopulatingFeatures: boolean;
    featurePopulationMessage: string;
}

export class GameWorld extends Component<GameWorldProps, GameWorldState> {
 prefix = 'game-world';
 
 state: GameWorldState = {
    data: null,
    activePanelId: PANEL_SPECS[0]?.id || '',
    activeCombat: null,
    activeDialogue: null,
    completedQuest: null,
    isPanelCollapsed: false,
    isProgressionModalOpen: false,
    isCraftingModalOpen: false,
    isPopulatingFeatures: false,
    featurePopulationMessage: 'Initializing...',
 };

 // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
 componentDidMount() {
    if (this.props.appData && (this.props.characterRecord || this.props.appData.saveSystem.loadGame(1))) {
        const gameData = new GameWorldData(
            this.props.appData,
            this.props.characterRecord,
            this.props.appData.saveSystem.loadGame(1),
            (combat) => this.setState({ activeCombat: combat }),
            (dialogue) => this.setState({ activeDialogue: dialogue }),
            (quest) => this.setState({ completedQuest: quest }),
            () => this.setState({ isProgressionModalOpen: true }),
            () => this.setState({ isCraftingModalOpen: true }),
            () => this.forceUpdate()
        );

        this.setState({ data: gameData }, async () => {
            const db = gameData.database;
            const worldService = ServiceFactory.create<WorldService>('WorldService');
            const sitesTable = db.getTable('world_sites');
            const characterRecord = this.props.characterRecord || this.props.appData.saveSystem.loadGame(1)?.characterData;

            if (sitesTable && sitesTable.findAll().length === 0 && characterRecord) {
                // New Game: Populate features which now also handles caching tiles.
                this.setState({ isPopulatingFeatures: true, featurePopulationMessage: 'Tailoring world to your profile...' });
                
                const scoreToLevel = (score: number): 'L'|'M'|'H' => score <= 33 ? 'L' : score >= 67 ? 'H' : 'M';
                const profile: OceanProfile = { 
                    o: scoreToLevel(characterRecord.ocean_o), c: scoreToLevel(characterRecord.ocean_c), 
                    e: scoreToLevel(characterRecord.ocean_e), a: scoreToLevel(characterRecord.ocean_a), 
                    n: scoreToLevel(characterRecord.ocean_n), profileId: ''
                };
                
                await worldService.populateFeatures(profile, (progress) => {
                    this.setState({ featurePopulationMessage: `${progress.stage} ${progress.percentage}%`});
                });

                this.setState({ isPopulatingFeatures: false });
            } else if (!worldService.isTileCacheInitialized()) {
                // Loaded Game: Tile cache isn't populated on startup anymore, so we do it here.
                this.setState({ isPopulatingFeatures: true, featurePopulationMessage: 'Loading world state...' });
                await worldService.loadTilesFromDb((p) => {
                    this.setState({ featurePopulationMessage: `Loading world state... ${p}%`});
                });
                this.setState({ isPopulatingFeatures: false });
            }

            if (gameData.gameCoordinator) {
                gameData.gameCoordinator.startGameLoop();
                gameData.gameCoordinator.eventService.subscribe('ui', (event) => {
                    if (event.title === 'open_progression_modal') {
                        this.openProgressionModal();
                    }
                });
            }
        });
        document.addEventListener('keydown', this.handleKeyDown);
    }
 }

 // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
 componentWillUnmount() {
    document.removeEventListener('keydown', this.handleKeyDown);
    this.state.data?.gameCoordinator.stopMovementAnimation();
    this.state.data?.gameCoordinator.stopGameLoop();
    this.state.data?.gameCoordinator.destroy();
 }

 handleKeyDown = (event: KeyboardEvent) => {
     this.state.data?.gameCoordinator.handleKeyDown(event.key, event.shiftKey);
 }

 handleTabClick = (panelId: string) => {
    this.setState({ activePanelId: panelId });
 }

 handleMapClick = (worldX: number, worldY: number) => {
    this.state.data?.gameCoordinator.movementController.handleMapClick(worldX, worldY);
 }
 
 handleCombatAction = (action: any) => {
    this.state.data?.gameCoordinator.handleCombatAction(action);
 }
 
 closeDialogue = () => {
    this.setState({ activeDialogue: null });
    this.state.data?.gameCoordinator.interactionController.endDialogue();
 }
 
 renderQuestTracker = (quest: any, character: any) => {
    if (!quest || !quest.targetLocation) {
        return null;
    }

    const dx = quest.targetLocation.x - character.x;
    const dy = quest.targetLocation.y - character.y;
    const angle = Math.atan2(dy, dx) * (180 / Math.PI) + 90;
    const distance = Math.round(Math.sqrt(dx*dx + dy*dy));

    const objectiveKey = `${quest.objective_type}_${quest.objective_target}`;
    const progress = quest.progress[objectiveKey] || 0;

    const objectiveText = `${quest.objective_target} (${progress}/${quest.objective_count})`;

    return React.createElement('div', { className: this.cls('quest-tracker') },
        React.createElement('h4', { className: this.cls('quest-tracker-title') }, quest.name),
        React.createElement('p', { className: this.cls('quest-tracker-objective') },
            React.createElement('span', {
                className: this.cls('quest-tracker-arrow'),
                style: { transform: `rotate(${angle}deg)`, display: 'inline-block' }
            }, '▲'),
            objectiveText,
            React.createElement('span', { className: this.cls('quest-tracker-distance') }, `(${distance}m)`)
        )
    );
 }

 togglePanel = () => this.setState(prev => ({ isPanelCollapsed: !prev.isPanelCollapsed }));

 openProgressionModal = () => {
    this.setState({ isProgressionModalOpen: true });
 }

 handleSpendAttributePoint = (stat: string) => {
    this.state.data?.character.spendAttributePoint(stat);
    this.forceUpdate();
 }

 handleCraftItem = (recipeId: number) => {
    this.state.data?.gameCoordinator.craftItem(recipeId);
    this.forceUpdate();
 }

 handleCloseCraftingModal = () => {
    this.state.data?.gameCoordinator.closeCraftingModal();
    this.setState({ isCraftingModalOpen: false });
 }

 private renderInfoPanel = () => {
    const { data, activePanelId, isPanelCollapsed } = this.state;
    if (!data) return null;

    const panels = PANEL_SPECS.map(spec =>
        PanelFactory.create(spec, spec.id === activePanelId, data, this.props.pluginManager)
    );
    const tabs = TAB_SPECS.map(spec =>
        TabFactory.create(spec, spec.panelId === activePanelId, this.handleTabClick)
    );

    const infoPanelContainerStyle = {
        flexBasis: isPanelCollapsed ? '0' : '30%',
        minWidth: isPanelCollapsed ? '0' : '350px',
        padding: isPanelCollapsed ? '0' : '0 0.5rem',
    };

    return React.createElement('div', { className: this.cls('column'), style: infoPanelContainerStyle },
        React.createElement('div', { className: this.cls('info-panel-container'), style: { display: isPanelCollapsed ? 'none' : 'flex' } },
            React.createElement('div', { className: this.cls('panel-container') },
                React.createElement('div', { className: this.cls('tabs-container') }, ...tabs),
                React.createElement('div', { className: this.cls('tab-content') }, ...panels)
            )
        ),
        React.createElement('button', {
            className: this.cls('panel-toggle-button'),
            style: { right: isPanelCollapsed ? '-40px' : '0px', transform: `translateY(-50%) rotate(${isPanelCollapsed ? '0deg' : '180deg'})` },
            onClick: this.togglePanel
        }, '❮')
    );
}

private renderMapArea = () => {
    const { data } = this.state;
    if (!data) return null;

    const miniMap = React.createElement(MiniMap, {
        character: data.character,
        worldService: data.gameCoordinator.worldService,
        discoveredTiles: data.gameCoordinator.discoveredTiles
    });

    return React.createElement('div', { className: this.cls('column'), style: { flexBasis: '70%', transition: 'flex-basis 0.3s ease', position: 'relative' } },
        React.createElement(GameWorldMap, { data: data, onTileClick: this.handleMapClick }),
        miniMap
    );
}

private renderOverlaysAndModals = () => {
    const { data, activeCombat, activeDialogue, completedQuest, isProgressionModalOpen, isCraftingModalOpen } = this.state;
    if (!data) return null;

    const recipes = data.database.getTable('tblRecipes')?.findAll() || [];

    return React.createElement(React.Fragment, null,
        activeCombat && React.createElement(CombatPanel, {
            combat: activeCombat,
            onCombatAction: this.handleCombatAction,
            inventory: data.inventorySystem.getItems(),
            database: data.database
        }),
        activeDialogue && React.createElement(DialoguePanel, { dialogue: activeDialogue, onClose: this.closeDialogue }),
        completedQuest && React.createElement(QuestCompletionModal, { quest: completedQuest, database: data.database, onClose: () => this.setState({ completedQuest: null }) }),
        isProgressionModalOpen && React.createElement(ProgressionModal, {
            character: data.character,
            onSpendPoint: this.handleSpendAttributePoint,
            onClose: () => this.setState({ isProgressionModalOpen: false })
        }),
        isCraftingModalOpen && React.createElement(CraftingModal, {
            recipes: recipes,
            inventory: data.inventorySystem,
            database: data.database,
            onCraft: this.handleCraftItem,
            onClose: this.handleCloseCraftingModal
        }),
        data.gameCoordinator.actionProgress && React.createElement(ActionProgressPanel, {
            actionProgress: data.gameCoordinator.actionProgress
        })
    );
}

 // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
 render() {
    const { data, isPopulatingFeatures, featurePopulationMessage } = this.state;
    
    if (!data || isPopulatingFeatures) {
        const loadingText = isPopulatingFeatures ? featurePopulationMessage : 'Loading World...';
        const loadingStyle = {
            display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', 
            width: '100vw', backgroundColor: '#1a1a2e', color: '#d4af37', fontFamily: 'sans-serif', fontSize: '1.2rem'
        };
        return React.createElement('div', { className: this.cls('container'), style: loadingStyle }, loadingText);
    }
    
    const trackedQuest = data.trackedQuest;

    return React.createElement('div', { className: this.cls('container') },
        React.createElement('div', { className: this.cls('content-area') },
            this.renderInfoPanel(),
            this.renderMapArea()
        ),
        this.renderQuestTracker(trackedQuest, data.character),
        this.renderOverlaysAndModals()
    );
 }
}