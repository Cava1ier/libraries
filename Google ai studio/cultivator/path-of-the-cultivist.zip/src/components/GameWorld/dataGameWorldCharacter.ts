

// This file is deprecated.
// The character's interaction with the game world (movement, actions) is now handled by the
// `dCharacterGameWorld` class in `src/data/dCharacterGameWorld.ts`.
// The character's state is managed by the `Character` class in `src/data/dCharacter.ts`.
// This file can be safely removed from the project.
