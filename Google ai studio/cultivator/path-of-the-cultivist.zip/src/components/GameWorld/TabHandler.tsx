import React from 'react';
import { Component } from '../../core/Component';
import { GameWorldData } from './dataGameWorld';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { PANEL_SPECS } from '../../data/dPanelData';
import { TAB_SPECS } from '../../data/dTabData';
import { PanelFactory } from '../../data/dPanelFactory';
import { TabFactory } from '../../data/dTabFactory';

interface TabHandlerProps {
    data: GameWorldData;
    pluginManager: PluginManager;
    activePanelId: string;
    onTabClick: (panelId: string) => void;
}

export class TabHandler extends Component<TabHandlerProps, {}> {
    // Re-use the prefix from GameWorld to inherit the necessary styles for tabs, panels, etc.
    // This avoids duplicating a large style definition and keeps changes minimal.
    prefix = 'game-world';

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { data, pluginManager, activePanelId, onTabClick } = this.props;

        const panels = PANEL_SPECS.map(spec =>
            PanelFactory.create(spec, spec.id === activePanelId, data, pluginManager)
        );
        
        const tabs = TAB_SPECS.map(spec =>
            TabFactory.create(spec, spec.panelId === activePanelId, onTabClick)
        );
        
        // This component renders the *content* of the info panel.
        return [
            React.createElement('div', { key: 'tabs-container', className: this.cls('tabs-container') },
                ...tabs
            ),
            React.createElement('div', {
                key: 'tab-content',
                className: this.cls('tab-content'),
            }, ...panels)
        ];
    }
}