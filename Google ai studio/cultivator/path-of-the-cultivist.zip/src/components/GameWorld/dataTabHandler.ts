import { TabSystem } from '../../systems/tabs/TabSystem';
import { BaseTab } from '../../systems/tabs/BaseTab';

export class TabHandlerData {
    public tabSystem: TabSystem;
    private forceUpdate: () => void;

    constructor(tabs: BaseTab[], initialTabId: string, forceUpdate: () => void) {
        this.tabSystem = new TabSystem(tabs, initialTabId);
        this.forceUpdate = forceUpdate;
    }

    public setActiveTab(tabId: string): void {
        this.tabSystem.setActiveTab(tabId);
        this.forceUpdate();
    }
}