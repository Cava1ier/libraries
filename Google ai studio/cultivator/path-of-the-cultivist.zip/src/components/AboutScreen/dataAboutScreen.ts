export class AboutScreenData {
    public readonly features: string[];

    constructor() {
        this.features = [
            'Registry-based CSS styling system for modular design',
            'Dwarf Fortress style world generation and exploration',
            'RimWorld inspired storytelling with OCEAN personality profiling',
            '13 unique cultivation stats displayed in spider web format',
            'Database table storage system for all game data',
            'Deterministic RNG system using 400 pre-generated numbers',
            'Seven literary conflicts integrated with character generation'
        ];
    }
}