import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { AboutScreenData } from './dataAboutScreen';
import { ServiceFactory } from '../../core/ServiceFactory';
import { LocalizationService } from '../../services/LocalizationService';

interface AboutScreenProps {
    pluginManager: PluginManager;
}

export class AboutScreen extends Component<AboutScreenProps, {}> {
 private data: AboutScreenData = new AboutScreenData();
 prefix = 'about';
 
 // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
 render() {
  const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
  return React.createElement('div', { className: this.cls('container') },
   React.createElement('div', { className: this.cls('content') },
    React.createElement('h1', { className: this.cls('title') }, localizationService.get('about_title')),
    React.createElement('p', { className: this.cls('text') }, localizationService.get('about_intro')),
    React.createElement('ul', { className: this.cls('feature-list') }, 
        this.data.features.map((feature, i) => React.createElement('li', { key: i, className: this.cls('feature-item') }, feature))
    ),
    React.createElement('button', { className: this.cls('button'), onClick: () => this.props.pluginManager.loadPage('menu') }, localizationService.get('about_button_return'))
   )
  );
 }
}