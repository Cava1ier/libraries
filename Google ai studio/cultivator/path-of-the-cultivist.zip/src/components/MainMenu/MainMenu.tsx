import React from 'react';
import { Component } from '../../core/Component';
import { PluginManager } from '../../systems/plugin/PluginSystem';
import { AppData } from '../../dataApp';
import { ServiceFactory } from '../../core/ServiceFactory';
import { LocalizationService } from '../../services/LocalizationService';

interface MainMenuProps {
    pluginManager: PluginManager;
    appData: AppData;
}

export class MainMenu extends Component<MainMenuProps, {}> {
 prefix = 'main-menu';

 // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
 render() {
  const { pluginManager, appData } = this.props;
  const hasSave = appData.saveSystem.hasSaveGame(1);
  const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');

  return React.createElement('div', { className: this.cls('container') },
   React.createElement('div', { className: this.cls('title-container') },
    React.createElement('h1', { className: this.cls('title') }, localizationService.get('main_menu_title')),
    React.createElement('p', { className: this.cls('subtitle') }, localizationService.get('main_menu_subtitle'))
   ),
   React.createElement('div', { className: this.cls('button-container') },
    React.createElement('button', { className: this.cls('button'), onClick: () => pluginManager.loadPage('questionnaire') }, localizationService.get('main_menu_button_begin')),
    React.createElement('button', { 
        className: this.cls('button') + (hasSave ? '' : ' ' + this.cls('button-disabled')), 
        disabled: !hasSave,
        onClick: () => appData.loadGame()
    }, localizationService.get('main_menu_button_load')),
    React.createElement('button', { className: this.cls('button') + ' ' + this.cls('button-disabled'), disabled: true }, localizationService.get('main_menu_button_techniques')),
    React.createElement('button', { className: this.cls('button'), onClick: () => pluginManager.loadPage('about') }, localizationService.get('main_menu_button_about'))
   )
  );
 }
}