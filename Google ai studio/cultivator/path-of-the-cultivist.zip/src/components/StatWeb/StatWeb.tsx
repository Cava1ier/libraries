import React from 'react';
import { Component } from '../../core/Component';

interface StatWebProps {
    stats: { name: string; value: number; max: number; }[];
    width?: number;
    height?: number;
    webKey?: number | string;
}

export class StatWeb extends Component<StatWebProps, {}> {
    prefix = 'stat-web';

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { stats, width = 300, height = 300, webKey } = this.props;

        if (!stats || stats.length === 0) {
            return null;
        }

        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) / 2 - 30;
        const levels = 5;
        const numStats = stats.length;

        const webLines: React.ReactElement[] = [];
        for (let i = 1; i <= levels; i++) {
            const levelRadius = (radius / levels) * i;
            let points = '';
            for (let j = 0; j < numStats; j++) {
                const angle = (j / numStats) * 2 * Math.PI - Math.PI / 2;
                const x = centerX + Math.cos(angle) * levelRadius;
                const y = centerY + Math.sin(angle) * levelRadius;
                points += `${x},${y} `;
            }
            webLines.push(React.createElement('polygon', { key: `level-${i}`, points: points.trim(), className: this.cls('web-line') }));
        }

        for (let i = 0; i < numStats; i++) {
            const angle = (i / numStats) * 2 * Math.PI - Math.PI / 2;
            const x = centerX + Math.cos(angle) * radius;
            const y = centerY + Math.sin(angle) * radius;
            webLines.push(React.createElement('line', { key: `radial-${i}`, x1: centerX, y1: centerY, x2: x, y2: y, className: this.cls('web-line') }));
        }
        
        let statPointsString = '';
        const pointsAndLabels = stats.map((stat, index) => {
            const angle = (index / numStats) * 2 * Math.PI - Math.PI / 2;
            const statRadius = (stat.value / stat.max) * radius;
            const x = centerX + Math.cos(angle) * statRadius;
            const y = centerY + Math.sin(angle) * statRadius;
            statPointsString += `${x},${y} `;

            const labelRadius = radius + 15;
            const labelX = centerX + Math.cos(angle) * labelRadius;
            const labelY = centerY + Math.sin(angle) * labelRadius;

            return [
                React.createElement('circle', {
                    key: `point-${index}`,
                    cx: x,
                    cy: y,
                    r: 4,
                    className: this.cls('stat-point'),
                    children: React.createElement('title', {}, `${stat.name.replace(/\n/g, ' ')}: ${stat.value}`)
                }),
                React.createElement('text', {
                    key: `label-${index}`,
                    x: labelX,
                    y: labelY,
                    className: this.cls('label')
                }, stat.name.split('\n').map((line, i) => React.createElement('tspan', {key: i, x: labelX, dy: `${i > 0 ? 1.2 : 0}em`}, line)))
            ];
        }).flat();
        
        const statPolygon = React.createElement('polygon', {
            points: statPointsString.trim(),
            className: this.cls('polygon')
        });

        const gradient = React.createElement('defs', {},
            React.createElement('radialGradient', { id: 'statGradient', cx: '50%', cy: '50%', r: '50%' },
                React.createElement('stop', { offset: '0%', 'stop-color': 'rgba(212, 175, 55, 0.8)' }),
                React.createElement('stop', { offset: '100%', 'stop-color': 'rgba(212, 175, 55, 0.3)' })
            )
        );

        return React.createElement('svg', { 
            key: webKey, 
            width: "100%", 
            height: "auto", 
            style: { maxWidth: `${width}px`, aspectRatio: '1 / 1' },
            viewBox: `0 0 ${width} ${height}` 
        },
            gradient,
            ...webLines,
            statPolygon,
            ...pointsAndLabels
        );
    }
}