import React from 'react';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';
import { BaseComponent } from '../patterns/BaseComponent';

export class Component<P = {}, S = {}> extends BaseComponent<P, S> {
 public nl: null = null;
 public prefix: string = '';

 cls(className: string): string {
    if (!this.prefix) {
        console.warn(`Component is missing a 'prefix'. Cannot generate class for '${className}'.`, this);
        return '';
    }
    return AppComponentLoader.cls(this.prefix, className);
 }
}