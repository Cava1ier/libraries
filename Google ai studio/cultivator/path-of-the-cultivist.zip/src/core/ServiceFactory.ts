



import { BaseService } from '../patterns/BaseService';

export interface ServiceConfig {
  name: string;
  dependencies?: string[];
  singleton?: boolean;
}

type ServiceImplementation<T extends BaseService> = new (...args: any[]) => T;

export class ServiceFactory {
  private static instances = new Map<string, any>();
  private static configs = new Map<string, ServiceConfig>();
  private static implementations = new Map<string, ServiceImplementation<any>>();

  static register<T extends BaseService>(config: ServiceConfig, implementation: ServiceImplementation<T>): void {
    // FIX: The value for the configs map should be the config object itself, not the implementation's name.
    // FIX: Key implementations by the service name (config.name) for consistency with how they are retrieved in `create`.
    this.configs.set(config.name, config);
    this.implementations.set(config.name, implementation);
  }

  // FIX: Allow passing additional arguments to the constructor for context-dependent services.
  static create<T extends BaseService>(name: string, ...constructorArgs: any[]): T {
    const implementation = this.implementations.get(name);
    const config = this.configs.get(name);

    if (!implementation || !config) {
        throw new Error(`Service '${name}' not registered.`);
    }

    if (config.singleton && this.instances.has(name)) {
      return this.instances.get(name) as T;
    }

    const dependencies = this.resolveDependencies(config.dependencies || []);
    // FIX: Prepend the extra arguments to the resolved dependencies when instantiating.
    const instance = new implementation(...constructorArgs, ...dependencies);

    if (config.singleton) {
      this.instances.set(name, instance);
    }

    return instance as T;
  }

  private static resolveDependencies(deps: string[]): any[] {
    return deps.map(depName => {
        const instance = this.create(depName);
        if (!instance) {
            throw new Error(`Dependency '${depName}' could not be resolved for a service.`);
        }
        return instance;
    });
  }
  
  static clear(): void {
      this.instances.clear();
      this.configs.clear();
      this.implementations.clear();
  }
}