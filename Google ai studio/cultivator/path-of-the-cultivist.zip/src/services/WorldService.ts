import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';
import { CreatureService } from './CreatureService';
import { BaseTile } from '../systems/tiles/BaseTile';
import { TilesFactory } from '../systems/tiles/TileFactory';
import { DatabaseService } from './DatabaseService';
import { OceanProfile } from '../types/OceanTypes';
import { WorldGenerator } from '../systems/generation/WorldGenerator';

export const WORLD_DEPTH = 10;

export class WorldService extends BaseService {
    private generator: WorldGenerator;
    private heightMapCache: number[][] | null = null;
    private tileCache: Map<string, BaseTile> = new Map();
    private visibilityCache: Map<string, BaseTile | null> = new Map();
    private oceanProfile: OceanProfile | null = null;
    private creatureService!: CreatureService;

    constructor(
        private rngService: RNGService, 
        private db: DatabaseService
    ) {
        super();
        this.generator = new WorldGenerator(rngService as any, db as any);
    }
    
    public setOceanProfile(profile: OceanProfile) {
        this.oceanProfile = profile;
    }

    public setCreatureService(system: CreatureService) {
        this.creatureService = system;
        this.creatureService.setWorldService(this);
    }

    public async generateBaseWorld(onProgress: (progress: { stage: string, percentage: number }) => void) {
        this.heightMapCache = await this.generator.generateAndLoadWorld(onProgress);
        // Tile cache is now populated after features are generated, not here.
    }

    public async populateFeatures(oceanProfile: OceanProfile, onProgress: (progress: { stage: string, percentage: number }) => void): Promise<void> {
        if (!this.heightMapCache || this.heightMapCache.length === 0) {
            console.error("Cannot populate features: heightmap is not generated or cached.");
            onProgress({ stage: 'Generating base terrain...', percentage: 0 });
            await this.generateBaseWorld(onProgress);
            if(!this.heightMapCache || this.heightMapCache.length === 0) {
                onProgress({stage: 'Fatal Error: Could not generate terrain.', percentage: 100});
                return;
            }
        }
        await this.generator.populateFeatures(oceanProfile, this.heightMapCache, onProgress);

        // After features are populated and tiles are modified, build the final tile cache.
        this.tileCache.clear();
        this.visibilityCache.clear();
        await this.loadTilesFromDb(p => onProgress({ stage: 'Finalizing world...', percentage: p }));
    }

    public getTile(x: number, y: number, z: number): BaseTile | undefined {
        return this.tileCache.get(`${x},${y},${z}`);
    }

    public getVisibleTile(x: number, y: number, startZ: number): BaseTile | null {
        const cacheKey = `${x},${y},${startZ}`;
        if (this.visibilityCache.has(cacheKey)) {
            return this.visibilityCache.get(cacheKey)!;
        }

        for (let z = startZ; z >= 0; z--) {
            const tile = this.getTile(x, y, z);
            if (tile && tile.type !== 'air') {
                this.visibilityCache.set(cacheKey, tile);
                return tile;
            }
        }
        
        this.visibilityCache.set(cacheKey, null);
        return null;
    }

    public async loadTilesFromDb(onProgress: (percentage: number) => void): Promise<void> {
        this.tileCache.clear();
        this.visibilityCache.clear();
        const tilesTable = this.db.getTable('world_tiles');
        if (!tilesTable) {
            onProgress(100);
            return;
        }
        
        const tileRecords = tilesTable.findAll();
        const totalTiles = tileRecords.length;
        if (totalTiles === 0) {
            onProgress(100);
            return;
        }

        const chunkSize = 2000;
        for (let i = 0; i < totalTiles; i += chunkSize) {
            const chunk = tileRecords.slice(i, i + chunkSize);
            for (const record of chunk) {
                const tile = TilesFactory.createTile(record);
                this.tileCache.set(tile.id, tile);
            }

            const percentage = Math.round(((i + chunkSize) / totalTiles) * 100);
            onProgress(Math.min(percentage, 100));
            await new Promise(resolve => setTimeout(resolve, 0));
        }
    }
    
    public isTileCacheInitialized(): boolean {
        return this.tileCache.size > 0;
    }

    public ensureAreaIsLoaded(worldX: number, worldY: number, radius: number) {
        // This is now a no-op as the world is pre-generated.
    }
}