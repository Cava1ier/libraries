
import { BaseService } from '../patterns/BaseService';
import { WorldService } from './WorldService';
import { BaseTile } from '../systems/tiles/BaseTile';
import { TileConfigRegistry } from '../systems/tiles/TileConfigRegistry';

interface PathNode {
    x: number; y: number; g: number; h: number; f: number; parent: PathNode | null;
}

export class PathfindingService extends BaseService {
    constructor(private worldService: WorldService) {
        super();
    }

    public findPath(start: {x: number, y: number, z: number}, end: {x: number, y: number, z: number}): {x: number, y: number}[] | null {
        const openSet: PathNode[] = [];
        const closedSet = new Set<string>();
        const startNode: PathNode = { x: start.x, y: start.y, g: 0, h: this.heuristic(start, end), f: this.heuristic(start, end), parent: null };
        openSet.push(startNode);

        while (openSet.length > 0) {
            let lowestIndex = 0;
            for (let i = 1; i < openSet.length; i++) if (openSet[i].f < openSet[lowestIndex].f) lowestIndex = i;
            const currentNode = openSet[lowestIndex];
            if (currentNode.x === end.x && currentNode.y === end.y) return this.reconstructPath(currentNode);
            openSet.splice(lowestIndex, 1);
            closedSet.add(`${currentNode.x},${currentNode.y}`);
            const neighbors = this.getNeighbors(currentNode, start.z);
            for (const neighbor of neighbors) {
                const neighborKey = `${neighbor.node.x},${neighbor.node.y}`;
                if (closedSet.has(neighborKey)) continue;
                const gScore = currentNode.g + neighbor.cost;
                const existingNode = openSet.find(n => n.x === neighbor.node.x && n.y === neighbor.node.y);
                if (!existingNode || gScore < existingNode.g) {
                    neighbor.node.parent = currentNode;
                    neighbor.node.g = gScore;
                    neighbor.node.h = this.heuristic({x: neighbor.node.x, y: neighbor.node.y}, end);
                    neighbor.node.f = neighbor.node.g + neighbor.node.h;
                    if (!existingNode) openSet.push(neighbor.node);
                }
            }
        }
        return null;
    }
    private getNeighbors(node: PathNode, z: number): {node: PathNode, cost: number}[] {
        const neighbors: {node: PathNode, cost: number}[] = [];
        for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
            if (dx === 0 && dy === 0) continue;
            const x = node.x + dx; const y = node.y + dy;
            const tile = this.worldService.getTile(x, y, z);
            if (tile && tile.canMoveTo({z: z})) {
                const isDiagonal = (dx & dy) !== 0;
                const cost = this.getMovementCost(tile) * (isDiagonal ? 1.414 : 1.0);
                neighbors.push({ node: { x, y, g: 0, h: 0, f: 0, parent: null }, cost });
            }
        }
        return neighbors;
    }
    private getMovementCost(tile: BaseTile): number { const config = TileConfigRegistry.get(tile.type); return config?.properties?.movementCost || 1; }
    private heuristic(a: {x:number,y:number}, b:{x:number,y:number}): number { const dx = b.x-a.x; const dy = b.y-a.y; return ((dx^(dx>>31))-(dx>>31))+((dy^(dy>>31))-(dy>>31)); }
    private reconstructPath(node: PathNode): {x: number, y: number}[] { const path = []; let c:PathNode|null=node; while(c){path.unshift({x:c.x,y:c.y});c=c.parent;} return path; }
}
