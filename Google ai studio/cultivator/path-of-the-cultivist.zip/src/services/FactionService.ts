
import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';
import { DatabaseService } from './DatabaseService';
import { WorldService } from './WorldService';
import { GeneratedCharacter } from '../systems/generation/character/Character.types';
import { Faction, FactionType, FactionIdeology, FactionMember, FactionResources, Territory, FactionTemplate, FactionRelationship } from '../types/SocialTypes';

export class FactionService extends BaseService {
    private factionTemplates: FactionTemplate[] = [];

    constructor(
        private rngService: RNGService,
        private db: DatabaseService,
        private worldService: WorldService
    ) {
        super();
        this.initializeFactionTemplates();
    }

    public generateFactionsForRegion(region: { x: [number, number]; y: [number, number] }, characters: GeneratedCharacter[], maxFactions: number = 3): Faction[] {
        const factions: Faction[] = [];
        const regionCharacters = characters.filter(char => char.x >= region.x[0] && char.x <= region.x[1] && char.y >= region.y[0] && char.y <= region.y[1]);
        for (let i = 0; i < maxFactions; i++) {
            const founder = this.selectFactionFounder(regionCharacters.filter(c => !factions.some(f => f.members.some(m => m.characterId === c.name))));
            if (founder) {
                const faction = this.generateFaction(founder, undefined, this.createTerritoryFromRegion(region));
                this.assignMembersToFaction(faction, regionCharacters);
                factions.push(faction);
            }
        }
        this.generateFactionRelationships(factions);
        return factions;
    }
    
    public generateFaction(founderCharacter?: GeneratedCharacter, factionType?: FactionType, territory?: Territory): Faction {
        const template = this.selectFactionTemplate(factionType, founderCharacter);
        return this.createFactionFromTemplate(template, founderCharacter, territory);
    }

    private selectFactionFounder(characters: GeneratedCharacter[]): GeneratedCharacter | null {
        if (characters.length === 0) return null;
        const leaders = characters.filter(char => char.ocean_e > 60 && char.ocean_c > 50 && char.cultivation_level >= 2);
        return leaders.length > 0 ? leaders[this.rngService.next() % leaders.length] : characters[this.rngService.next() % characters.length];
    }
    private selectFactionTemplate(preferredType?: FactionType, founder?: GeneratedCharacter): FactionTemplate {
        let candidates = this.factionTemplates;
        if (preferredType) candidates = candidates.filter(t => t.type === preferredType);
        if (founder) candidates = candidates.filter(t => this.isCharacterCompatibleWithFaction(founder, t));
        if (candidates.length === 0) candidates = this.factionTemplates;
        return candidates[this.rngService.next() % candidates.length];
    }
    private createFactionFromTemplate(template: FactionTemplate, founder?: GeneratedCharacter, territory?: Territory): Faction {
        const faction: Faction = {
            id: this.generateFactionId(), name: this.generateFactionName(template, founder), type: template.type,
            description: template.description, ideology: { ...template.ideology },
            powerLevel: template.basePowerLevel + (this.rngService.next() % 20),
            territory: territory ? [territory] : [], members: [], relationships: new Map(),
            resources: this.generateInitialResources(template), goals: [], history: [], isActive: true,
        };
        if (founder) faction.members.push({ characterId: founder.name, rank: template.leaderRank || 'Leader', joinDate: Date.now(), loyalty: 90 + (this.rngService.next() % 11) });
        return faction;
    }
    private generateFactionName(template: FactionTemplate, founder?: GeneratedCharacter): string {
        const namePatterns = template.namePatterns || ['{adjective} {noun}'];
        const pattern = namePatterns[this.rngService.next() % namePatterns.length];
        return pattern.replace('{founder}', founder?.name.split(' ')[0] || 'Ancient').replace('{type}', template.type.charAt(0).toUpperCase() + template.type.slice(1)).replace('{adjective}', this.getRandomFromTable('tblPreNameAdjectives')).replace('{noun}', this.getRandomFromTable('tblNouns')).replace('{element}', founder?.spiritual_roots || 'Mystic');
    }
    private assignMembersToFaction(faction: Faction, candidates: GeneratedCharacter[]): void {
        const maxMembers = Math.min(10, candidates.length);
        const memberCount = 2 + (this.rngService.next() % (maxMembers > 2 ? (maxMembers - 2) : 1));
        const compatibleCandidates = candidates.filter(char => char.name !== faction.members[0]?.characterId && this.isCharacterCompatibleWithFactionIdeology(char, faction.ideology));
        for (let i = 0; i < Math.min(memberCount, compatibleCandidates.length); i++) {
            faction.members.push({ characterId: compatibleCandidates[i].name, rank: 'Disciple', joinDate: Date.now(), loyalty: 50 + (this.rngService.next() % 40) });
        }
    }
    private generateFactionRelationships(factions: Faction[]): void {
        for (let i = 0; i < factions.length; i++) for (let j = i + 1; j < factions.length; j++) {
            const r = this.calculateFactionRelationship(factions[i], factions[j]);
            factions[i].relationships.set(factions[j].id, r);
            factions[j].relationships.set(factions[i].id, { ...r, sourceId: factions[j].id, targetId: factions[i].id });
        }
    }
    private calculateFactionRelationship(f1: Faction, f2: Faction): FactionRelationship {
        let base = 0;
        if (f1.ideology.alignment === f2.ideology.alignment) base += 20;
        else if ((f1.ideology.alignment === 'righteous' && f2.ideology.alignment === 'demonic') || (f1.ideology.alignment === 'demonic' && f2.ideology.alignment === 'righteous')) base -= 40;
        const final = Math.max(-100, Math.min(100, base + (this.rngService.next() % 21) - 10));
        return { sourceId: f1.id, targetId: f2.id, type: this.determineRelationshipType(final), strength: final, isPublic: true, history: [], lastUpdate: Date.now() };
    }
    private isCharacterCompatibleWithFaction(c: GeneratedCharacter, t: FactionTemplate): boolean {
        if (t.ideology.alignment === 'righteous' && c.karmic_burden > 60) return false;
        if (t.ideology.alignment === 'demonic' && c.karmic_burden < 40) return false;
        if (t.leadershipRequirements) {
            if (t.leadershipRequirements.minExtraversion && c.ocean_e < t.leadershipRequirements.minExtraversion) return false;
            if (t.leadershipRequirements.minConscientiousness && c.ocean_c < t.leadershipRequirements.minConscientiousness) return false;
        }
        return true;
    }
    private isCharacterCompatibleWithFactionIdeology(c: GeneratedCharacter, i: FactionIdeology): boolean {
        switch (i.alignment) {
            case 'righteous': return c.karmic_burden < 50 && c.ocean_a > 40;
            case 'demonic': return c.karmic_burden > 50 || c.ocean_a < 40;
            default: return true;
        }
    }
    private determineRelationshipType(s: number): string {
        if (s > 60) return 'alliance'; if (s > 20) return 'friendly';
        if (s > -20) return 'neutral'; if (s > -60) return 'hostile';
        return 'enemy';
    }
    private createTerritoryFromRegion(r: { x: [number, number]; y: [number, number] }): Territory {
        return { name: `Territory of ${r.x[0]},${r.y[0]}`, bounds: r, controlLevel: 70 + (this.rngService.next() % 31), strategicValue: 50 + (this.rngService.next() % 51), resources: ['spiritual_veins', 'herbs'] };
    }
    private generateInitialResources(t: FactionTemplate): FactionResources {
        const b = t.baseResources;
        return { wealth: b.wealth + (this.rngService.next() % 1000), influence: b.influence + (this.rngService.next() % 50), militaryStrength: b.militaryStrength + (this.rngService.next() % 100), knowledgeBase: b.knowledgeBase + (this.rngService.next() % 100), spiritualPower: b.spiritualPower + (this.rngService.next() % 200), territories: b.territories };
    }
    private getRandomFromTable(n: string): string { const t = this.db.getTable(n); return t && t.findAll().length > 0 ? t.findAll()[this.rngService.next() % t.findAll().length].name : 'Unknown'; }
    private generateFactionId(): string { return `faction_${Date.now()}_${this.rngService.next() % 10000}`; }
    private initializeFactionTemplates(): void {
        this.factionTemplates = [
            { type: FactionType.SECT, ideology: { alignment: 'righteous', primaryValues: ['cultivation', 'honor'], conflictApproach: 'defensive', recruitmentPolicy: 'selective' }, basePowerLevel: 60, baseResources: { wealth: 5000, influence: 40, militaryStrength: 70, knowledgeBase: 80, spiritualPower: 90, territories: 1 }, leaderRank: 'Sect Master', namePatterns: ['{element} {noun} Sect', 'Sacred {noun} Sect'], leadershipRequirements: { minConscientiousness: 60 }, description: 'A cultivation sect focused on righteous practices.' },
            { type: FactionType.DEMONIC_CULT, ideology: { alignment: 'demonic', primaryValues: ['power', 'domination'], conflictApproach: 'aggressive', recruitmentPolicy: 'open' }, basePowerLevel: 50, baseResources: { wealth: 3000, influence: 30, militaryStrength: 80, knowledgeBase: 60, spiritualPower: 70, territories: 1 }, leaderRank: 'Cult Master', namePatterns: ['{adjective} {noun} Cult', 'Blood {noun} Society'], description: 'A demonic cult that pursues forbidden power.' },
            { type: FactionType.CLAN, ideology: { alignment: 'neutral', primaryValues: ['family', 'tradition'], conflictApproach: 'defensive', recruitmentPolicy: 'hereditary' }, basePowerLevel: 40, baseResources: { wealth: 10000, influence: 60, militaryStrength: 50, knowledgeBase: 50, spiritualPower: 40, territories: 1 }, leaderRank: 'Patriarch', namePatterns: ['{founder} Clan', '{adjective} {noun} Family'], description: 'A powerful family-based organization.' }
        ];
    }
}
