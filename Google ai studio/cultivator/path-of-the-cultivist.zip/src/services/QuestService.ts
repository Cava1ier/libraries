

import { BaseService } from '../patterns/BaseService';
import { DatabaseService } from './DatabaseService';
import { InventoryService } from './InventoryService';
import { QuestData } from '../types/AdventureTypes';
import { Character } from '../data/dCharacter';

export class QuestService extends BaseService {
    private activeQuests: QuestData[] = [];
    private completedQuestIds: Set<number> = new Set();
    private allQuests: any[] = [];
    private character: Character | null = null;
    public onLevelUp: ((newLevel: number) => void) | null = null;
    public onQuestComplete: ((quest: QuestData) => void) | null = null;


    constructor(
      private database: DatabaseService, 
      private inventoryService: InventoryService
    ) {
        super();
        this.loadQuestsFromDB();
        this.activateInitialQuests();
    }

    public setCharacter(character: Character) {
        this.character = character;
    }

    private loadQuestsFromDB() {
        const questTable = this.database.getTable('tblQuests');
        if (questTable) this.allQuests = questTable.findAll();
    }
    private activateInitialQuests() {
        if (this.activeQuests.length === 0 && this.completedQuestIds.size === 0) {
            const initialQuest = this.allQuests.find(q => q.prereq_quest_id === 0);
            if (initialQuest) this.acceptQuest(initialQuest);
        }
    }
    public acceptQuest(quest: any) {
        if (!this.activeQuests.some(q => q.id === quest.id) && !this.completedQuestIds.has(quest.id)) {
            const newQuest: QuestData = { ...quest, progress: {} };
            this.setQuestTargetLocation(newQuest);
            this.activeQuests.push(newQuest);
        }
    }
    private setQuestTargetLocation(quest: QuestData) {
        const locationMap: { [key: number]: {x: number, y: number} } = { 1: { x: 120, y: 120 }, 2: { x: 125, y: 125 } };
        const location = locationMap[quest.id as number];
        if (location) quest.targetLocation = location;
    }
    public isQuestComplete(quest: QuestData) {
        const key = `${quest.objective_type}_${quest.objective_target}`;
        return (quest.progress[key] || 0) >= quest.objective_count;
    }
    public completeQuest(quest: QuestData) {
        if (quest.reward_item_id) this.inventoryService.addItem(quest.reward_item_id, quest.reward_item_count, 2);
        
        if (this.character && quest.reward_xp) {
            const result = this.character.addExperience(quest.reward_xp);
            if (result.leveledUp && this.onLevelUp && result.newLevel) {
                this.onLevelUp(result.newLevel);
            }
        }

        this.completedQuestIds.add(Number(quest.id));
        this.activeQuests = this.activeQuests.filter(q => q.id !== quest.id);

        if (this.onQuestComplete) {
            this.onQuestComplete(quest);
        }

        const nextQuest = this.allQuests.find(q => q.prereq_quest_id == quest.id);
        if (nextQuest) this.acceptQuest(nextQuest);
    }
    public getActiveQuests(): QuestData[] { return this.activeQuests; }
    public setActiveQuests(quests: QuestData[]) { this.activeQuests = quests; }
    public getCompletedQuestIds(): Set<number> { return this.completedQuestIds; }
    public updateProgress(type: 'COLLECT' | 'HUNT', target: string, count: number = 1) {
        this.activeQuests.forEach(q => {
            if (q.objective_type === type && q.objective_target === target) {
                const key = `${type}_${target}`;
                q.progress[key] = (q.progress[key] || 0) + count;
            }
        });
    }
    public getTrackedQuest(): QuestData | undefined { return this.activeQuests.find(q => q.targetLocation !== undefined); }
}