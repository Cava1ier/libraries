import { ServiceFactory } from '../core/ServiceFactory';

import { RNGService } from './RNGService';
import { DatabaseService } from './DatabaseService';
import { WorldService } from './WorldService';
import { PathfindingService } from './PathfindingService';
import { CharacterGenerationService } from './CharacterGenerationService';
import { InventoryService } from './InventoryService';
import { QuestService } from './QuestService';
import { CreatureService } from './CreatureService';
import { CombatService } from './CombatService';
import { DialogueService } from './DialogueService';
import { WeatherService } from './WeatherService';
import { SaveService } from './SaveService';
import { RelationshipService } from './RelationshipService';
import { FactionService } from './FactionService';
import { FactionSystemService } from './FactionSystemService';
import { SkillService } from './SkillService';
import { GameStateService } from '../systems/world/character/managers/GameStateManager';
import { EventService } from './EventService';
import { ActionService } from './ActionService';
import { VisionService } from './VisionService';
import { MovementService } from './MovementService';
import { GameCoordinatorService } from './GameCoordinatorService';
import { LocalizationService } from './LocalizationService';
import { DomService } from './DomService';

export function registerServices() {
    ServiceFactory.register({ name: 'DomService', singleton: true }, DomService);
    ServiceFactory.register({ name: 'RNGService', singleton: true }, RNGService);
    ServiceFactory.register({ name: 'DatabaseService', singleton: true }, DatabaseService);
    ServiceFactory.register({ name: 'SaveService', singleton: true }, SaveService);
    ServiceFactory.register({ name: 'GameStateService', singleton: true }, GameStateService);
    ServiceFactory.register({ name: 'EventService', singleton: true }, EventService);
    ServiceFactory.register({ name: 'LocalizationService', singleton: true }, LocalizationService);

    ServiceFactory.register({ name: 'WeatherService', singleton: true, dependencies: ['RNGService'] }, WeatherService);
    ServiceFactory.register({ name: 'InventoryService', singleton: true, dependencies: ['DatabaseService'] }, InventoryService);
    ServiceFactory.register({ name: 'QuestService', singleton: true, dependencies: ['DatabaseService', 'InventoryService'] }, QuestService);
    ServiceFactory.register({ name: 'FactionSystemService', singleton: true, dependencies: ['DatabaseService', 'WorldService', 'RNGService'] }, FactionSystemService);
    ServiceFactory.register({ name: 'CreatureService', singleton: true, dependencies: ['RNGService', 'DatabaseService', 'FactionSystemService'] }, CreatureService);
    ServiceFactory.register({ name: 'SkillService', singleton: true, dependencies: ['DatabaseService', 'RNGService'] }, SkillService);
    
    ServiceFactory.register({ name: 'WorldService', singleton: true, dependencies: ['RNGService', 'DatabaseService'] }, WorldService);
    ServiceFactory.register({ name: 'VisionService', singleton: true, dependencies: ['WorldService'] }, VisionService);
    ServiceFactory.register({ name: 'PathfindingService', singleton: true, dependencies: ['WorldService'] }, PathfindingService);
    ServiceFactory.register({ name: 'DialogueService', singleton: true, dependencies: ['DatabaseService', 'QuestService', 'FactionSystemService', 'SkillService', 'RNGService'] }, DialogueService);
    
    ServiceFactory.register({ name: 'RelationshipService', singleton: true, dependencies: ['RNGService', 'DatabaseService'] }, RelationshipService);
    ServiceFactory.register({ name: 'FactionService', singleton: true, dependencies: ['RNGService', 'DatabaseService', 'WorldService'] }, FactionService);
   
    ServiceFactory.register({ name: 'ActionService', singleton: true, dependencies: ['GameStateService', 'EventService'] }, ActionService);
    ServiceFactory.register({ name: 'MovementService', singleton: true, dependencies: ['WorldService', 'CreatureService', 'PathfindingService', 'InventoryService', 'QuestService', 'DatabaseService', 'SkillService'] }, MovementService);

    ServiceFactory.register({ name: 'CharacterGenerationService', singleton: true, dependencies: ['RNGService', 'DatabaseService', 'WorldService', 'RelationshipService'] }, CharacterGenerationService);
    ServiceFactory.register({ name: 'CombatService', singleton: true, dependencies: ['RNGService', 'InventoryService', 'DatabaseService'] }, CombatService);

    ServiceFactory.register({ name: 'GameCoordinatorService', dependencies: [
        'GameStateService', 'EventService', 'ActionService', 'MovementService', 'VisionService', 'SaveService',
        'DatabaseService', 'CreatureService', 'CombatService', 'DialogueService', 'QuestService', 'InventoryService', 'SkillService', 'RNGService', 'WorldService', 'FactionSystemService', 'WeatherService'
    ]}, GameCoordinatorService as any);
}