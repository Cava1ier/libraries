
import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';
import { DatabaseService } from './DatabaseService';
import { GeneratedCharacter } from '../systems/generation/character/Character.types';
import { Relationship, RelationshipType, RelationshipEvent } from '../types/SocialTypes';

export class RelationshipService extends BaseService {
    constructor(private rngService: RNGService, private db: DatabaseService) {
        super();
    }

    public generateRelationshipsForCharacter(character: GeneratedCharacter, existingCharacters: GeneratedCharacter[], maxRelationships: number = 3): Relationship[] {
        const relationships: Relationship[] = [];
        const candidates = this.findRelationshipCandidates(character, existingCharacters);
        for (let i = 0; i < Math.min(maxRelationships, candidates.length); i++) {
            const candidate = candidates[i];
            const relationshipType = this.determineRelationshipType(character, candidate);
            if (relationshipType) relationships.push(this.createRelationship(character, candidate, relationshipType));
        }
        return relationships;
    }

    private findRelationshipCandidates(c: GeneratedCharacter, existing: GeneratedCharacter[]): GeneratedCharacter[] {
        return existing.filter(o => o.name !== c.name)
            .map(o => ({ character: o, compatibility: this.calculateCompatibility(c, o) }))
            .sort((a, b) => b.compatibility - a.compatibility).slice(0, 10).map(item => item.character);
    }
    private calculateCompatibility(c1: GeneratedCharacter, c2: GeneratedCharacter): number {
        const ocean = (Math.abs(c1.ocean_e - c2.ocean_e) < 30 ? 10 : 0) + ((c1.ocean_a + c2.ocean_a) / 4) - ((c1.ocean_n + c2.ocean_n) / 8);
        const dist = Math.sqrt(Math.pow(c1.x - c2.x, 2) + Math.pow(c1.y - c2.y, 2));
        return ocean + Math.max(0, 50 - dist) + (c1.realm === c2.realm ? 20 : 0);
    }
    private determineRelationshipType(c1: GeneratedCharacter, c2: GeneratedCharacter): RelationshipType | null {
        const compat = this.calculateCompatibility(c1, c2);
        const rand = this.rngService.next() % 100;
        if (c1.ocean_a < 40 && c2.ocean_a < 40 && rand < 30) return RelationshipType.RIVALRY;
        if (Math.abs(c1.cultivation_level - c2.cultivation_level) >= 2 && rand < 20) return RelationshipType.MENTOR_STUDENT;
        if (compat > 60 && c1.ocean_a > 50 && c2.ocean_a > 50 && rand < 40) return RelationshipType.FRIENDSHIP;
        if (compat > 40 && c1.conflict_strength === c2.conflict_strength && rand < 25) return RelationshipType.ALLIANCE;
        return null;
    }
    private createRelationship(c1: GeneratedCharacter, c2: GeneratedCharacter, type: RelationshipType): Relationship {
        const baseStrengths: Record<RelationshipType, number> = { [RelationshipType.FRIENDSHIP]: 50, [RelationshipType.RIVALRY]: -30, [RelationshipType.MENTOR_STUDENT]: 40, [RelationshipType.ALLIANCE]: 30, [RelationshipType.FAMILY]: 70, [RelationshipType.ROMANTIC]: 60, [RelationshipType.MASTER_SERVANT]: 20, [RelationshipType.ENEMY]: -70, [RelationshipType.BUSINESS]: 10, [RelationshipType.SECT_MEMBER]: 25, };
        const finalStrength = Math.max(-100, Math.min(100, (baseStrengths[type] || 0) + (this.calculateCompatibility(c1, c2) - 50)));
        return {
            id: `${c1.name}_${c2.name}_${type}`, sourceCharacterId: c1.name, targetCharacterId: c2.name, type,
            strength: finalStrength, history: [{ type: 'meeting', description: 'Met under unknown circumstances.', strengthChange: 0, timestamp: Date.now() }],
            tags: [], isActive: true, createdAt: Date.now(), lastInteraction: Date.now()
        };
    }
}
