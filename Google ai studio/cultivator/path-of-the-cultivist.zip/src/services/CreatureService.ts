

import { BaseService } from '../patterns/BaseService';
import { RNGService } from './RNGService';
import { DatabaseService } from './DatabaseService';
import { CreatureData } from '../types/AdventureTypes';
import { FactionSystemService } from './FactionSystemService';
import { OceanProfile } from '../types/OceanTypes';
import { WorldService } from './WorldService';

export class CreatureService extends BaseService {
  public creatures: Map<string, CreatureData> = new Map();
  private worldService: WorldService | null = null;

  constructor(
    private rngService: RNGService, 
    private db: DatabaseService,
    private factionSystemService: FactionSystemService
  ) {
    super();
  }
  
  public setWorldService(ws: WorldService) {
      this.worldService = ws;
  }

  public updateCreatureAI() {
    if (!this.worldService) return;

    const now = Date.now();
    const moveCooldown = 5000; // 5 seconds

    for (const creature of this.creatures.values()) {
      if (creature.id.startsWith('player') || creature.isHostile) continue;
      
      const lastMove = creature.lastMoveTimestamp || 0;
      if (now - lastMove < moveCooldown) continue;

      const directions = [
        { dx: 0, dy: -1 }, { dx: 1, dy: 0 }, { dx: 0, dy: 1 }, { dx: -1, dy: 0 }
      ];
      const dir = directions[this.rngService.next() % directions.length];
      
      const currentPos = creature.position;
      const newPos = { x: currentPos.x + dir.dx, y: currentPos.y + dir.dy, z: currentPos.z };
      
      const targetTile = this.worldService.getTile(newPos.x, newPos.y, newPos.z);
      
      if (targetTile && targetTile.canMoveTo({}) && !this.getCreatureAt(newPos.x, newPos.y, newPos.z)) {
        this.moveCreature(creature.id, newPos.x, newPos.y, newPos.z);
        creature.lastMoveTimestamp = now;
      }
    }
  }

  public spawnCreatureForTile(x: number, y: number, z: number, biome: string, oceanProfile?: OceanProfile | null) {
    const key = `${x},${y},${z}`;
    if (this.creatures.has(key)) return;

    let spawnChance = 0.02; // Reduced from 0.05
    
    if (oceanProfile) {
        if (oceanProfile.n === 'H') { // High Neuroticism increases spawn rate
            spawnChance *= 1.5;
        }
        if (oceanProfile.e === 'L') { // Low Extraversion decreases spawn rate
            spawnChance *= 0.7;
        }
    }

    if (this.rngService.next() / 1000 > spawnChance) return;

    const creatureTypes = this.db.getTable('tblCreatureTypes').findAll();
    let creatureRecord;

    // High Neuroticism has a higher chance to spawn hostile creatures
    if (oceanProfile && oceanProfile.n === 'H' && this.rngService.nextInRange(0, 100) < 30) {
        const hostileCreatures = creatureTypes.filter(c => c.isHostile === 1);
        if (hostileCreatures.length > 0) {
            creatureRecord = hostileCreatures[this.rngService.nextInRange(0, hostileCreatures.length - 1)];
        }
    }

    if (!creatureRecord) {
        creatureRecord = creatureTypes[this.rngService.nextInRange(0, creatureTypes.length - 1)];
    }
    
    if (creatureRecord.name === 'Villager') return;

    const creature: CreatureData = {
      id: `c_${x}_${y}_${z}`,
      typeId: creatureRecord.id,
      name: creatureRecord.name,
      isHostile: creatureRecord.isHostile === 1,
      stats: {
        health: creatureRecord.health,
        maxHealth: creatureRecord.health,
        attack: creatureRecord.attack,
        defense: creatureRecord.defense,
        speed: creatureRecord.speed,
        energy: 100,
      },
      position: { x, y, z },
    };
    this.creatures.set(key, creature);
  }
  
  public spawnNpcById(npcId: number, x: number, y: number, z: number) {
      const key = `${x},${y},${z}`;
      const npcRecord = this.db.getTable('tblNPCs').find(npcId);
      const creatureType = this.db.getTable('tblCreatureTypes').find(6); // Villager

      const creature: CreatureData = {
        id: `npc_${npcId}`,
        typeId: creatureType.id,
        name: npcRecord.name,
        isHostile: false,
        stats: { ...creatureType, maxHealth: creatureType.health, energy: 100 },
        position: { x, y, z },
      };
      this.creatures.set(key, creature);
  }

  public spawnRovingNPCs(count: number) {
      const allFactions = this.factionSystemService.getAllFactions();
      if (allFactions.length === 0) return;

      for (let i = 0; i < count; i++) {
          const faction = allFactions[this.rngService.next() % allFactions.length];
          if (!faction.territory || faction.territory.length === 0) continue;

          const territory = faction.territory[0];
          const spawnX = this.rngService.nextInRange(territory.bounds.x[0], territory.bounds.x[1]);
          const spawnY = this.rngService.nextInRange(territory.bounds.y[0], territory.bounds.y[1]);
          const spawnZ = 5;

          const key = `${spawnX},${spawnY},${spawnZ}`;
          if (this.creatures.has(key)) continue;

          const villagerRecord = this.db.getTable('tblCreatureTypes').find(6);

          const npc: CreatureData = {
              id: `roving_${faction.id}_${i}`,
              typeId: villagerRecord.id,
              name: "Wandering Cultivator",
              isHostile: false,
              stats: {
                  health: villagerRecord.health, maxHealth: villagerRecord.health,
                  attack: villagerRecord.attack, defense: villagerRecord.defense,
                  speed: villagerRecord.speed, energy: 100
              },
              position: { x: spawnX, y: spawnY, z: spawnZ },
              factionId: faction.id
          };
          this.creatures.set(key, npc);
      }
  }

  public moveCreature(creatureId: string, newX: number, newY: number, newZ: number): boolean {
      let foundCreature: CreatureData | null = null;
      let oldKey: string | null = null;
      
      for (const [key, creature] of this.creatures.entries()) {
          if (creature.id === creatureId) {
              foundCreature = creature;
              oldKey = key;
              break;
          }
      }

      if (!foundCreature || !oldKey) return false;
      
      const newKey = `${newX},${newY},${newZ}`;
      if (this.creatures.has(newKey)) return false;
      
      foundCreature.position = { x: newX, y: newY, z: newZ };
      this.creatures.delete(oldKey);
      this.creatures.set(newKey, foundCreature);
      return true;
  }

  public getCreatureAt(x: number, y: number, z: number): CreatureData | undefined {
    return this.creatures.get(`${x},${y},${z}`);
  }

  public removeCreature(creature: CreatureData) {
    this.creatures.delete(`${creature.position.x},${creature.position.y},${creature.position.z}`);
  }
}