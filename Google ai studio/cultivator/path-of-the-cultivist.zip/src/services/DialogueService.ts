import { BaseService } from '../patterns/BaseService';
import { DatabaseService } from './DatabaseService';
import { QuestService } from './QuestService';
import { CreatureData, DialogueState, DialogueOption, SkillType } from '../types/AdventureTypes';
import { FactionSystemService } from './FactionSystemService';
import { SkillService } from './SkillService';
import { RNGService } from './RNGService';

export class DialogueService extends BaseService {
  constructor(
    private db: DatabaseService, 
    private questService: QuestService,
    private factionSystemService: FactionSystemService,
    private skillService: SkillService,
    private rngService: RNGService
  ) {
    super();
  }

  public getDialogue(npc: CreatureData): DialogueState {
    const npcId = npc.id.startsWith('npc_') ? npc.id.split('_')[1] : null;
    if (npcId) {
        const npcRecord = this.db.getTable('tblNPCs').find(npcId);
        if (npcRecord) {
            const activeQuests = this.questService.getActiveQuests();
            const completedQuests = this.questService.getCompletedQuestIds();

            for (const quest of activeQuests) {
                if (quest.end_npc_id == npcRecord.id && this.questService.isQuestComplete(quest)) {
                    const dialogueText = quest.id == 1 ? npcRecord.dialogue_end_quest_1 : npcRecord.dialogue_start_quest_2;
                    return {
                        npc,
                        text: dialogueText,
                        quest,
                        options: [{ text: "Complete Quest", action: () => this.questService.completeQuest(quest) }]
                    };
                }
            }
            
            const isQuest2Active = activeQuests.some(q => q.id == 2);
            if (npcId === '1' && isQuest2Active) {
                const text = npcRecord.dialogue_start_quest_2;
                let options: DialogueOption[] = [
                    { 
                        text: "[Persuade] Tell me more about the Verdant Lotus Clan.",
                        action: () => {},
                        skillCheck: {
                            skill: SkillType.Swordsmanship, // Placeholder for a social skill
                            difficulty: 15 
                        }
                    },
                    { text: "I will prove my worth.", action: () => {} }
                ];

                options.forEach(opt => {
                    if (opt.skillCheck) {
                        const check = this.skillService.performSkillCheck(opt.skillCheck.skill, opt.skillCheck.difficulty);
                        if (!check.succeeded) {
                            opt.disabled = true;
                            opt.disabledText = `${opt.text} (Skill Check Failed: ${check.total}/${opt.skillCheck.difficulty})`;
                        }
                    }
                });

                return { npc, text, options };
            }

            const allQuests = this.db.getTable('tblQuests').findAll();
            for (const quest of allQuests) {
                if(quest.start_npc_id == npcRecord.id && !activeQuests.some(q => q.id === quest.id) && !completedQuests.has(quest.id) && (quest.prereq_quest_id === 0 || completedQuests.has(quest.prereq_quest_id))) {
                    const dialogueText = quest.id == 1 ? npcRecord.dialogue_start_quest_1 : npcRecord.dialogue_start_quest_2;
                    return { npc, text: dialogueText, quest, options: [ { text: "Accept Quest", action: () => this.questService.acceptQuest(quest) }, { text: "Decline", action: () => {} } ] };
                }
            }
        }
    }
    
    if (npc.factionId) {
        const faction = this.factionSystemService.getFaction(npc.factionId);
        if (faction) {
            const allFactions = this.factionSystemService.getAllFactions();
            const otherFactions = allFactions.filter(f => f.id !== faction.id);
            const otherFaction = otherFactions.length > 0 ? otherFactions[this.rngService.next() % otherFactions.length] : null;

            const dialogues = [
                `Greetings. I am a disciple of the ${faction.name}. Our path is one of ${faction.ideology.primaryValues.join(' and ')}.`,
                `The winds of fate blow strangely in these lands. Have you heard any news from the ${otherFaction?.name || 'distant lands'}?`,
                `Be wary, traveler. The world is not as peaceful as it seems. Cultivators must be strong to survive.`
            ];
            const selectedDialogue = dialogues[this.rngService.next() % dialogues.length];
            
            return {
                npc,
                text: selectedDialogue,
                options: [{ text: "Farewell", action: () => {} }]
            };
        }
    }
    
    const genericDialogue = `Greetings, cultivator. I am ${npc.name}.`;
    return { npc, text: genericDialogue, options: [{ text: "Leave", action: () => {} }] };
  }
}