import { BaseService } from '../patterns/BaseService';

export interface GameEvent {
  id: string;
  type: 'movement' | 'combat' | 'interaction' | 'system' | 'quest' | 'ui';
  title: string;
  description: string;
  timestamp: number;
  data?: any;
}

type EventCallback = (event: GameEvent) => void;

export class EventService extends BaseService {
  private events: GameEvent[] = [];
  private maxEvents: number = 100;
  private subscribers: Map<string, EventCallback[]> = new Map();

  constructor() { super(); }

  public subscribe(eventType: string, callback: EventCallback) {
    if (!this.subscribers.has(eventType)) {
      this.subscribers.set(eventType, []);
    }
    this.subscribers.get(eventType)!.push(callback);
  }

  public addEvent(type: GameEvent['type'], title: string, description: string = "", data?: any): GameEvent {
    const event: GameEvent = {
      id: `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type, title, description, timestamp: Date.now(), data
    };
    this.events.unshift(event);
    if (this.events.length > this.maxEvents) this.events.pop();
    
    const specificSubs = this.subscribers.get(type) || [];
    const allSubs = this.subscribers.get('*') || [];
    [...specificSubs, ...allSubs].forEach(cb => cb(event));

    return event;
  }

  public getRecentEvents(count: number = 50): GameEvent[] {
    return this.events.slice(0, count);
  }
}
