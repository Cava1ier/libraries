
import { BaseService } from '../patterns/BaseService';
import { Character } from '../data/dCharacter';
import { GameWorldMapData } from '../components/GameWorld/dataGameWorldMap';
import { GameStateService } from '../systems/world/character/managers/GameStateManager';
import { EventService } from './EventService';
import { ActionService } from './ActionService';
import { MovementService } from './MovementService';
import { VisionService } from './VisionService';
import { SaveService } from './SaveService';
import { CreatureService } from './CreatureService';
import { CombatService } from './CombatService';
import { DialogueService } from './DialogueService';
import { QuestService } from './QuestService';
import { DatabaseService } from './DatabaseService';
import { InventoryService } from './InventoryService';
import { SkillService } from './SkillService';
import { RNGService } from './RNGService';
import { WorldService } from './WorldService';
import { FactionSystemService } from './FactionSystemService';
import { WeatherService } from './WeatherService';

import { InputHandler } from '../systems/world/character/handlers/InputHandler';
import { WorldUpdateManager } from '../systems/world/character/managers/WorldUpdateManager';
import { MovementController } from '../systems/world/character/controllers/MovementController';
import { CombatController } from '../systems/world/character/controllers/CombatController';
import { ExplorationController } from '../systems/world/character/controllers/ExplorationController';
import { InteractionController } from '../systems/world/character/controllers/InteractionController';
import { OceanProfile } from '../types/OceanTypes';

export interface GameCoordinatorContext {
    character: Character;
    mapData: GameWorldMapData;
    initialDiscoveredTiles?: string[];
    onUpdate: () => void;
    onCombatStart: (encounter: any) => void;
    onDialogueStart: (dialogue: any) => void;
    onQuestComplete: (quest: any) => void;
    onLevelUp: () => void;
    onCraftingStart: () => void;
}

export class GameCoordinatorService extends BaseService {
    public character: Character;
    public mapData: GameWorldMapData;
    public context: GameCoordinatorContext;
    private gameLoopInterval: number | null = null;

    // Controllers
    public movementController: MovementController;
    private combatController: CombatController;
    public explorationController: ExplorationController;
    public interactionController: InteractionController;
    private inputHandler: InputHandler;
    public worldUpdateManager: WorldUpdateManager;
    
    // Public getters for UI state
    get playerState() { return this.gameState.getPlayerState(); }
    get currentPath() { return this.gameState.getCurrentPath(); }
    get actionProgress() { return this.gameState.getActionProgress(); }
    get discoveredTiles() { return this.gameState.getDiscoveredTiles(); }
    get lineOfSightTiles() { return this.gameState.getLineOfSightTiles(); }

    constructor(
        context: GameCoordinatorContext,
        public gameState: GameStateService, public eventService: EventService, public actionService: ActionService,
        public movementService: MovementService, public visionService: VisionService, public saveService: SaveService,
        public db: DatabaseService, public creatureService: CreatureService, public combatService: CombatService,
        public dialogueService: DialogueService, public questService: QuestService, public inventoryService: InventoryService,
        public skillService: SkillService, public rngService: RNGService, public worldService: WorldService,
        public factionSystemService: FactionSystemService,
        public weatherService: WeatherService
    ) {
        super();
        this.context = context;
        this.character = context.character;
        this.mapData = context.mapData;

        if (context.initialDiscoveredTiles) {
            this.gameState.setDiscoveredTiles(context.initialDiscoveredTiles);
        }

        const scoreToLevel = (score: number): 'L'|'M'|'H' => score <= 33 ? 'L' : score >= 67 ? 'H' : 'M';
        const profile: OceanProfile = { o: scoreToLevel(this.character.ocean_o), c: scoreToLevel(this.character.ocean_c), e: scoreToLevel(this.character.ocean_e), a: scoreToLevel(this.character.ocean_a), n: scoreToLevel(this.character.ocean_n), profileId: ''};
        this.worldService.setOceanProfile(profile);

        this.worldUpdateManager = new WorldUpdateManager(this);
        this.inputHandler = new InputHandler(this);
        this.movementController = new MovementController(this);
        this.combatController = new CombatController(this);
        this.explorationController = new ExplorationController(this);
        this.interactionController = new InteractionController(this);
        
        this.initialize();
    }
    
    private initialize() {
        this.eventService.subscribe('system', (e) => { this.context.onUpdate(); });
        this.eventService.subscribe('ui', () => this.context.onUpdate());
        this.combatService.setUpdateCallback(this.context.onUpdate);
        this.movementService.animator.onStep = this.worldUpdateManager.onMovementStep;
        
        this.questService.setCharacter(this.character);
        this.questService.onLevelUp = (newLevel: number) => {
            this.eventService.addEvent('system', `You have reached Cultivation Level ${newLevel}!`, 'You have attribute points to spend.');
            this.context.onLevelUp();
        };
        this.questService.onQuestComplete = this.context.onQuestComplete;

        this.worldService.ensureAreaIsLoaded(this.character.x, this.character.y, 2);
        this.worldUpdateManager.updateVision();
        this.eventService.addEvent('system', 'Game initialized', 'Welcome to the world!');
    }

    public startGameLoop() {
        if (this.gameLoopInterval) return;
        this.gameLoopInterval = window.setInterval(() => this.tick(), 1000);
    }

    public stopGameLoop() {
        if (this.gameLoopInterval) {
            clearInterval(this.gameLoopInterval);
            this.gameLoopInterval = null;
        }
    }
    
    private tick() {
        this.weatherService.advanceTime(1);
        this.creatureService.updateCreatureAI();
        this.factionSystemService.updateFactionAI(this.character);
        this.context.onUpdate();
    }

    public handleKeyDown(key: string, shiftKey: boolean) { this.inputHandler.handleKeyDown(key, shiftKey); }
    public handleCombatAction(action: any) { this.combatController.handleCombatAction(action); }
    public performAction(actionId: string) { this.actionService.executeAction(actionId, { character: this.character, dependencies: this as any, gameWorld: this as any }); }
    public cancelCurrentAction() { this.actionService.cancelCurrentAction(); }
    
    public saveGame() {
        const saveData = {
            characterData: this.character.data,
            discoveredTiles: Array.from(this.discoveredTiles),
            inventory: this.inventoryService.getItems(),
            quests: this.questService.getActiveQuests(),
            time: this.weatherService.getTime(),
            factions: this.factionSystemService.getAllFactions().map(f => ({ ...f, relationships: Array.from(f.relationships.entries()) })),
            creatures: Array.from(this.creatureService.creatures.values()),
        };
        this.saveService.saveGame(saveData, 1);
        this.eventService.addEvent('system', 'Game Saved', 'Your progress has been recorded.');
    }

    public handlePlayerDefeat() {
        this.eventService.addEvent('system', 'You have fallen in battle.', 'You awaken, weakened, at a safe place...');
        this.character.qi_points = Math.floor(this.character.max_qi_points * 0.1);
        this.character.setPosition(128, 128, 5);
        this.stopMovementAnimation();
        this.worldUpdateManager.onMovementStep();
        this.context.onUpdate();
    }

    public stopMovementAnimation() { this.movementService.stopMovement(); }
    public updateAndRender() { this.worldUpdateManager.updateAndRender(); }
    public destroy() { this.stopGameLoop(); }
    
    public openCraftingModal() {
        this.context.onCraftingStart();
    }
    
    public closeCraftingModal() {
        // This could be handled by the UI component itself
    }

    public craftItem(recipeId: number) {
        const recipe = this.db.getTable('tblRecipes').find(recipeId);
        if (!recipe) {
            this.eventService.addEvent('system', 'Crafting Failed', 'Recipe not found.');
            return;
        }

        for (let i = 1; i <= 2; i++) {
            const reqItemId = recipe[`req_item_id_${i}`];
            const reqQuantity = recipe[`req_quantity_${i}`];
            if (reqItemId && !this.inventoryService.removeItem(reqItemId, reqQuantity)) {
                this.eventService.addEvent('system', 'Crafting Failed', 'Not enough ingredients.');
                return;
            }
        }
        
        this.inventoryService.addItem(recipe.result_item_id, recipe.result_quantity, 3); // Good quality
        const resultItem = this.db.getTable('tblItemTypes').find(recipe.result_item_id);
        this.eventService.addEvent('system', 'Crafting Successful!', `You crafted a ${resultItem.name}.`);
    }
}