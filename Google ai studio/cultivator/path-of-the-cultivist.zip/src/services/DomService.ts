import { BaseService } from '../patterns/BaseService';

export class DomService extends BaseService {
    private _handler: any = null;

    public get handler(): any {
        if (!this._handler) {
            // Access DomHandler from the global window object.
            // This is safer than relying on a declared global and makes the dependency explicit.
            if (typeof (window as any).DomHandler === 'undefined') {
                throw new Error("DomHandler is not defined on the window object. Ensure lib/StyleRegistry.js is loaded correctly.");
            }
            this._handler = new (window as any).DomHandler();
        }
        return this._handler;
    }
    
    constructor() {
        super();
    }
}
