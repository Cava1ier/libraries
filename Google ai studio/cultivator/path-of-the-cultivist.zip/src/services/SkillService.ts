
import { BaseService } from '../patterns/BaseService';
import { SkillType, SkillGainResult, SkillCheckResult, SkillBonus, BonusType, CriticalType } from '../types/AdventureTypes';
import { DatabaseService } from './DatabaseService';
import { RNGService } from './RNGService';

export class SkillService extends BaseService {
    private skillExperience: Map<SkillType, number> = new Map();
    private skillLevels: Map<SkillType, number> = new Map();
    private skillBonuses: Map<SkillType, SkillBonus[]> = new Map();

    constructor(
      private db: DatabaseService, 
      private rng: RNGService
    ) {
        super();
        this.initializeSkills();
        this.setupSkillBonuses();
    }

    private initializeSkills(): void {
        const skillTable = this.db.getTable('tblSkillTypes');
        if (!skillTable) return;
        skillTable.findAll().forEach(record => {
            const skillId = Number(record.id);
            if (!isNaN(skillId)) {
                this.skillExperience.set(skillId, 0);
                this.skillLevels.set(skillId, 1);
            }
        });
    }

    public gainExperience(skillType: SkillType, amount: number, difficulty: number = 1): SkillGainResult {
        const currentExp = this.skillExperience.get(skillType) || 0;
        const currentLevel = this.skillLevels.get(skillType) || 1;
        const adjustedAmount = this.calculateAdjustedExperience(amount, difficulty, currentLevel);
        const newExp = currentExp + adjustedAmount;
        this.skillExperience.set(skillType, newExp);
        const expForNextLevel = this.getExperienceForLevel(currentLevel + 1);
        const leveledUp = newExp >= expForNextLevel;
        if (leveledUp) {
            const newLevel = currentLevel + 1;
            this.skillLevels.set(skillType, newLevel);
            this.skillExperience.set(skillType, newExp - expForNextLevel);
            return { experienceGained: adjustedAmount, leveledUp: true, newLevel: newLevel, bonusesUnlocked: this.checkForNewBonuses(skillType, newLevel) };
        }
        return { experienceGained: adjustedAmount, leveledUp: false, newLevel: currentLevel, bonusesUnlocked: [] };
    }

    private calculateAdjustedExperience(amount: number, difficulty: number, currentLevel: number): number {
        return Math.max(1, Math.round((amount * (difficulty * 1.5)) / (1 + (currentLevel / 10))));
    }
    public getExperienceForLevel(level: number): number { return Math.floor(Math.pow(level, 2) * 100); }
    public getSkillLevel(skillType: SkillType): number { return this.skillLevels.get(skillType) || 1; }
    public getSkillExperience(skillType: SkillType): {current: number, required: number} {
        const level = this.getSkillLevel(skillType);
        return { current: this.skillExperience.get(skillType) || 0, required: this.getExperienceForLevel(level + 1) };
    }
    public performSkillCheck(skillType: SkillType, difficulty: number, circumstances: number = 0): SkillCheckResult {
        const skillLevel = this.skillLevels.get(skillType) || 1;
        const roll = this.rng.nextInRange(1, 20);
        const result = roll + skillLevel + circumstances;
        const succeeded = result >= difficulty;
        const isCritSuccess = roll === 20; const isCritFailure = roll === 1;
        return { succeeded: isCritSuccess || (succeeded && !isCritFailure), roll, total: result, margin: result - difficulty, critical: isCritSuccess || isCritFailure, criticalType: isCritSuccess ? CriticalType.Success : isCritFailure ? CriticalType.Failure : CriticalType.None };
    }
    private setupSkillBonuses(): void {
        this.skillBonuses.set(SkillType.Swordsmanship, [ { type: BonusType.Damage, value: 5, requiredLevel: 5 }, { type: BonusType.Damage, value: 10, requiredLevel: 10 }, ]);
        this.skillBonuses.set(SkillType.Herbalism, [ { type: BonusType.Gathering, value: 1, requiredLevel: 3 }, { type: BonusType.Gathering, value: 1, requiredLevel: 7 }, ]);
    }
    private checkForNewBonuses(skillType: SkillType, newLevel: number): SkillBonus[] {
        return (this.skillBonuses.get(skillType) || []).filter(b => b.requiredLevel === newLevel);
    }
}
