import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { QuestData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface QuestPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  quests: QuestData[];
  database: GameDatabase;
  pluginManager: PluginManager;
}

export class QuestPanel extends Component<QuestPanelProps, {}> {
  prefix = 'quest-panel';
  styles = ['display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 'margin-bottom', 'border-bottom', 'font-style', 'margin-top'];
  classnames = ['container', 'quest-item', 'quest-title', 'quest-desc', 'quest-type', 'quest-progress'];
  styleValues = [
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    ['flex', 'column', '1rem', nl, nl, nl, nl, nl, nl, nl], // container
    [nl, 'column', '0', 'sans-serif', '0.9rem', '#ccc', '0.5rem', '1px solid rgba(212,175,55,0.1)', nl, nl], // quest-item
    [nl, nl, nl, nl, '1rem', '#d4af37', '0.2rem', nl, nl, nl], // quest-title
    [nl, nl, nl, nl, '0.8rem', '#aaa', nl, nl, nl, nl],  // quest-desc
    [nl, nl, '0.5rem 0 0 0', nl, '0.7rem', '#888', nl, nl, 'italic', nl], // quest-type
    [nl, nl, nl, nl, '0.9rem', '#4caf50', nl, nl, nl, '0.5rem'] // quest-progress
  ];

  // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    const { quests, database } = this.props;

    if (quests.length === 0) {
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('p', { style: { color: '#888' } }, 'You have no active quests.')
        );
    }

    return React.createElement('div', { className: this.cls('container') },
        ...quests.map(quest => {
            const questTypeRecord = database.getTable('tblQuestTypes').find(quest.objective_type === 'COLLECT' ? 3 : 2);
            const questTypeName = questTypeRecord ? questTypeRecord.name : 'Unknown';
            const progressKey = `${quest.objective_type}_${quest.objective_target}`;
            const currentProgress = quest.progress[progressKey] || 0;
            const progressText = `(${currentProgress} / ${quest.objective_count})`;

            return React.createElement('div', { key: quest.id, className: this.cls('quest-item') },
                React.createElement('h4', { className: this.cls('quest-title') }, quest.name),
                React.createElement('p', { className: this.cls('quest-desc') }, quest.description),
                React.createElement('p', { className: this.cls('quest-progress') }, `${quest.objective_target}: ${progressText}`),
                React.createElement('p', { className: this.cls('quest-type') }, `Type: ${questTypeName}`)
            )
        })
    );
  }
}