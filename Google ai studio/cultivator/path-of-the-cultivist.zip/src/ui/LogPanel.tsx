import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface LogPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  worldEvents: any[];
  pluginManager: PluginManager;
}

interface LogPanelState {
  scrollTop: number;
}

const ITEM_HEIGHT = 38; // Estimated height in pixels for one event item
const PANEL_HEIGHT = 400; // The visible height of the scrollable area

export class LogPanel extends Component<LogPanelProps, LogPanelState> {
  prefix = 'log-panel';
  styles = [
    'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
    'margin-bottom', 'border-bottom', 'height', 'overflow-y', 'position', 'width', 'left', 'top'
  ];
  classnames = ['container', 'event-item', 'event-desc', 'event-consequence', 'sizer', 'item-wrapper'];
  styleValues = [
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    ['flex', 'column', '0', 'sans-serif', nl, nl, nl, nl, `${PANEL_HEIGHT}px`, 'auto', 'relative', nl, nl, nl], // container
    ['flex', 'column', '0.5rem 1rem', nl, '0.9rem', '#ccc', '0.5rem', '1px solid rgba(212,175,55,0.1)', nl, nl, nl, nl, nl, nl], // event-item
    [nl, nl, '0 0 0.2rem 0', nl, nl, '#fff', nl, nl, nl, nl, nl, nl, nl, nl], // event-desc
    [nl, nl, nl, nl, '0.8rem', '#888', nl, nl, nl, nl, nl, nl, nl, nl],  // event-consequence
    [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, 'relative', '100%', nl, nl], // sizer
    [nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, 'absolute', '100%', '0', '0'], // item-wrapper
  ];

    state: LogPanelState = {
        scrollTop: 0
    };

  handleScroll = (event: React.UIEvent<HTMLDivElement>) => {
    this.setState({ scrollTop: event.currentTarget.scrollTop });
  }

  // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
  render() {
    if (!this.props.isVisible) {
        return null;
    }
    
    const { worldEvents } = this.props;
    const { scrollTop } = this.state;

    const totalHeight = worldEvents.length * ITEM_HEIGHT;
    const startIndex = Math.floor(scrollTop / ITEM_HEIGHT);
    const visibleItemCount = Math.ceil(PANEL_HEIGHT / ITEM_HEIGHT) + 2; // +2 for buffer
    const endIndex = Math.min(worldEvents.length, startIndex + visibleItemCount);
    
    const visibleItems = worldEvents.slice(startIndex, endIndex);

    const itemNodes = visibleItems.map((event, index) => {
        const itemIndex = startIndex + index;
        return React.createElement('div', {
            key: itemIndex,
            className: this.cls('item-wrapper'),
            style: { top: `${itemIndex * ITEM_HEIGHT}px` }
        },
            React.createElement('div', { className: this.cls('event-item') },
                React.createElement('p', { className: this.cls('event-desc') }, `[${event.timestamp}] ${event.description}`),
                React.createElement('small', { className: this.cls('event-consequence') }, event.consequences)
            )
        );
    });

    return React.createElement('div', { 
        className: this.cls('container'),
        onScroll: this.handleScroll
    },
        React.createElement('div', { 
            className: this.cls('sizer'),
            style: { height: `${totalHeight}px` }
        }, ...itemNodes)
    );
  }
}