import React from 'react';
import { Component } from '../core/Component';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface ActionProgressPanelProps {
  actionProgress: {
    startTime: number;
    duration: number;
    actionId: string;
  };
}

interface ActionProgressPanelState {
  progress: number;
}

export class ActionProgressPanel extends Component<ActionProgressPanelProps, ActionProgressPanelState> {
  private animationFrameId: number = 0;

  prefix = 'action-progress';
  styles = [
    'position', 'bottom', 'left', 'width', 'padding', 'background-color', 'display', 'flex-direction',
    'align-items', 'color', 'font-size', 'height', 'border-radius', 'border', 'transition', 'text-shadow', 'z-index'
  ];
  classnames = ['container', 'label', 'progress-bar-container', 'progress-bar-fill'];
  styleValues = [
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    ['fixed', '2rem', '50%', '300px', '1rem', 'rgba(0,0,0,0.7)', 'flex', 'column', 'center', '#fff', '1rem', nl, '8px', '1px solid rgba(212,175,55,0.3)', 'transform 0.3s ease', '1px 1px 2px #000', '20'], // container
    [nl, nl, nl, nl, '0 0 0.5rem 0', nl, nl, nl, nl, '#d4af37', '0.9rem', nl, nl, nl, nl, nl, nl], // label
    [nl, nl, nl, '100%', nl, 'rgba(212,175,55,0.1)', nl, nl, nl, nl, nl, '8px', '4px', '1px solid rgba(212,175,55,0.3)', nl, nl, nl], // progress-bar-container
    [nl, nl, nl, nl, nl, '#d4af37', nl, nl, nl, nl, nl, '100%', '4px', nl, 'width 0.1s linear', nl, nl], // progress-bar-fill
  ];

    state: ActionProgressPanelState = {
        progress: 0,
    };
  
  componentDidMount() {
    this.startAnimation();
  }
  
  componentWillUnmount() {
    this.stopAnimation();
  }
  
  startAnimation = () => {
    const loop = () => {
      const { startTime, duration } = this.props.actionProgress;
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / duration) * 100);
      this.setState({ progress });
      this.animationFrameId = requestAnimationFrame(loop);
    };
    this.animationFrameId = requestAnimationFrame(loop);
  };
  
  stopAnimation = () => {
    cancelAnimationFrame(this.animationFrameId);
  };

  render() {
    const { actionId } = this.props.actionProgress;
    const labelText = `${actionId.charAt(0).toUpperCase() + actionId.slice(1)}...`;

    return React.createElement('div', { className: this.cls('container'), style: { transform: 'translateX(-50%)' } },
      React.createElement('label', { className: this.cls('label') }, labelText),
      React.createElement('div', { className: this.cls('progress-bar-container') },
        React.createElement('div', {
          className: this.cls('progress-bar-fill'),
          style: { width: `${this.state.progress}%` }
        })
      )
    );
  }
}