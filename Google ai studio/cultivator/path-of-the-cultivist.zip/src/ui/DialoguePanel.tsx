import React from 'react';
import { Component } from '../core/Component';
import { DialogueState } from '../types/AdventureTypes';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface DialoguePanelProps {
    dialogue: DialogueState;
    onClose: () => void;
}

export class DialoguePanel extends Component<DialoguePanelProps, {}> {
    prefix = 'dialogue-panel-placeholder';
    styles = ['padding', 'text-align', 'color', 'display', 'flex-direction', 'gap', 'margin-top'];
    classnames = ['container', 'title', 'text', 'options'];
    styleValues = [
        // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
        ['2rem', 'center', '#fff', nl, nl, nl, nl],
        [nl, nl, '#d4af37', nl, nl, nl, nl],
        ['1rem 0', nl, '#ccc', nl, nl, nl, nl],
        [nl, nl, nl, 'flex', 'column', '0.5rem', '1rem'],
    ];

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { dialogue, onClose } = this.props;
        const modalCls = (clsName: string) => AppComponentLoader.cls('modal', clsName);

        const optionButtons = dialogue.options.map((opt, i) =>
            React.createElement('button', {
                key: i,
                className: modalCls('button'),
                onClick: () => {
                    if (opt.action) opt.action();
                    onClose();
                },
                disabled: opt.disabled,
                title: opt.disabled ? opt.disabledText : ''
            }, opt.disabled ? opt.disabledText : opt.text)
        );

        return React.createElement('div', { className: modalCls('overlay') },
            React.createElement('div', { className: `${modalCls('panel-base')} ${this.cls('container')}` },
                React.createElement('h3', { className: this.cls('title') }, `Dialogue with ${dialogue.npc.name}`),
                React.createElement('p', { className: this.cls('text') }, dialogue.text),
                React.createElement('div', { className: this.cls('options') }, ...optionButtons)
            )
        );
    }
}