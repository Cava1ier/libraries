import React from 'react';
import { Component } from '../core/Component';
import { QuestData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

interface QuestCompletionModalProps {
  quest: QuestData;
  database: GameDatabase;
  onClose: () => void;
}

// FIX: Added export to the class definition.
export class QuestCompletionModal extends Component<QuestCompletionModalProps, {}> {
    prefix = 'quest-complete-modal';

    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { quest, onClose } = this.props;
        const modalCls = (clsName: string) => AppComponentLoader.cls('modal', clsName);

        const rewards = [];
        if (quest.reward_xp) {
            rewards.push(React.createElement('p', { key: 'xp', style:{color: '#ccc'} }, `Experience: ${quest.reward_xp}`));
        }
        if (quest.reward_item_id && quest.reward_item_count) {
            const item = this.props.database.getTable('tblItemTypes').find(quest.reward_item_id);
            if (item) {
                rewards.push(React.createElement('p', { key: 'item', style:{color: '#ccc'} }, `Item: ${item.name} x${quest.reward_item_count}`));
            }
        }

        return React.createElement('div', { className: modalCls('overlay') },
            React.createElement('div', { className: modalCls('panel-base'), style: { textAlign: 'center' } },
                React.createElement('h2', { style: {color: '#d4af37', fontSize: '1.8rem'} }, 'Quest Complete!'),
                React.createElement('h3', { style: {color: '#fff', fontSize: '1.4rem', margin: '0.5rem 0 1.5rem 0'} }, quest.name),
                React.createElement('div', null,
                    React.createElement('p', { style:{color: '#d4af37'} }, 'Rewards:'),
                    ...rewards
                ),
                React.createElement('button', {
                    className: modalCls('button'),
                    style: { marginTop: '2rem' },
                    onClick: onClose
                }, 'Continue')
            )
        );
    }
}