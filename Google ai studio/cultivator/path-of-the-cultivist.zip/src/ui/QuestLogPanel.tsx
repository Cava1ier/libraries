import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { QuestData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface QuestLogPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  quests: QuestData[];
  completedQuestIds: Set<number>;
  database: GameDatabase;
  pluginManager: PluginManager;
}

interface QuestLogPanelState {
    activeAccordion: 'active' | 'completed' | null;
}

export class QuestLogPanel extends Component<QuestLogPanelProps, QuestLogPanelState> {
  prefix = 'quest-log-panel';
  styles = [
      'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
      'margin-bottom', 'border-bottom', 'font-style', 'margin-top', 'justify-content',
      'cursor', 'background-color', 'border-radius', 'border', 'transition', 'overflow',
      'max-height', 'opacity'
    ];
  classnames = [
      'container', 'accordion-header', 'accordion-content', 'quest-item', 'quest-title', 
      'quest-desc', 'quest-progress', 'completed-item'
    ];
  styleValues = [
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    ['flex', 'column', '1rem', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // container
    ['flex', 'row', '0.5rem 1rem', 'sans-serif', '1rem', '#d4af37', nl, nl, nl, '0.5rem', 'space-between', 'pointer', 'rgba(212,175,55,0.1)', '5px', '1px solid rgba(212,175,55,0.2)', 'background-color 0.3s', nl, nl, nl], // accordion-header
    ['block', 'column', nl, nl, nl, '#ccc', nl, nl, nl, nl, nl, nl, 'rgba(0,0,0,0.2)', '0 0 5px 5px', '1px solid rgba(212,175,55,0.1)', 'max-height 0.35s ease-in-out, padding 0.35s ease-in-out, opacity 0.35s ease-in-out', 'hidden', '0', '0'], // accordion-content
    ['block', 'column', '0.5rem 0', nl, '0.9rem', '#ccc', '0.5rem', '1px solid rgba(212,175,55,0.05)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // quest-item
    [nl, nl, '0 0 0.2rem 0', 'serif', '1rem', '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // quest-title
    [nl, nl, nl, nl, '0.85rem', '#aaa', nl, nl, 'italic', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl],  // quest-desc
    [nl, nl, '0.5rem 0 0 0', nl, '0.9rem', '#4caf50', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // quest-progress
    [nl, nl, '0.3rem 0.5rem', nl, '0.9rem', '#888', '0.2rem', '1px solid rgba(128,128,128,0.1)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // completed-item
  ];
  
  state: QuestLogPanelState = {
    activeAccordion: 'active',
  };

  toggleAccordion = (accordion: 'active' | 'completed') => {
    this.setState(prevState => ({
      activeAccordion: prevState.activeAccordion === accordion ? null : accordion
    }));
  }

  renderAccordion = (
    title: string,
    id: 'active' | 'completed',
    count: number,
    content: React.ReactNode[]
  ) => {
    const isOpen = this.state.activeAccordion === id;
    return React.createElement('div', { key: id, style: { marginBottom: '0.5rem' } },
      React.createElement('div', { className: this.cls('accordion-header'), onClick: () => this.toggleAccordion(id) },
        React.createElement('span', {}, `${title} (${count})`),
        React.createElement('span', {}, isOpen ? '−' : '+')
      ),
      React.createElement('div', {
        className: this.cls('accordion-content'),
        style: {
          maxHeight: isOpen ? '250px' : '0',
          paddingTop: isOpen ? '0.5rem' : '0',
          paddingBottom: isOpen ? '0.5rem' : '0',
          opacity: isOpen ? 1 : 0,
          overflowY: isOpen ? 'auto' : 'hidden',
          paddingLeft: '1rem',
          paddingRight: '1rem',
        }
      }, ...content)
    );
  }

  render() {
    if (!this.props.isVisible) {
      return null;
    }
    
    const { quests, completedQuestIds, database } = this.props;

    const activeQuestContent = quests.length > 0 ? quests.map(quest => {
      const progressKey = `${quest.objective_type}_${quest.objective_target}`;
      const currentProgress = quest.progress[progressKey] || 0;
      const progressText = `(${currentProgress} / ${quest.objective_count})`;

      return React.createElement('div', { key: quest.id, className: this.cls('quest-item') },
        React.createElement('h4', { className: this.cls('quest-title') }, quest.name),
        React.createElement('p', { className: this.cls('quest-desc') }, quest.description),
        React.createElement('p', { className: this.cls('quest-progress') }, `${quest.objective_target}: ${progressText}`)
      );
    }) : [React.createElement('p', { key: 'none', className: this.cls('quest-desc'), style:{padding: '0.5rem 0'} }, 'No active quests.')];

    const allQuests = database.getTable('tblQuests').findAll();
    const completedQuestContent = completedQuestIds.size > 0 ? Array.from(completedQuestIds).map(id => {
        const questRecord = allQuests.find(q => q.id == id);
        return React.createElement('p', { key: id, className: this.cls('completed-item') }, questRecord ? `✓ ${questRecord.name}` : `✓ Unknown Quest #${id}`);
    }) : [React.createElement('p', { key: 'none', className: this.cls('quest-desc'), style:{padding: '0.5rem 0'} }, 'No completed quests.')];

    return React.createElement('div', { className: this.cls('container') },
        this.renderAccordion('Active Quests', 'active', quests.length, activeQuestContent),
        this.renderAccordion('Completed Quests', 'completed', completedQuestIds.size, completedQuestContent)
    );
  }
}