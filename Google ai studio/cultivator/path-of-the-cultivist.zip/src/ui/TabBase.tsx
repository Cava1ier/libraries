import React from 'react';
import { Component } from '../core/Component';
import { TabSpec } from '../data/dTabData';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface TabBaseProps {
  spec: TabSpec;
  isActive: boolean;
  onClick: (panelId: string) => void;
}

export class TabBase extends Component<TabBaseProps, {}> {
  prefix = 'tab-base';
  styles = [
      'padding', 'font-size', 'font-weight', 'color', 'background-color', 
      'border', 'border-radius', 'cursor', 'transition', 'display', 'align-items', 'gap'
    ];
  classnames = ['tab', 'tab-active'];
  styleValues = [
    [
        '0.5rem 1rem', '0.9rem', 'bold', '#888', 'rgba(0,0,0,0.2)', 
        '1px solid transparent', '5px 5px 0 0', 'pointer', 'background-color 0.3s, color 0.3s',
        'flex', 'center', '0.5rem'
    ], // tab
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    [
        nl, nl, nl, '#d4af37', 'rgba(0,0,0,0.4)', 
        '1px solid rgba(212,175,55,0.3)', nl, nl, nl,
        nl, nl, nl
    ]  // tab-active
  ];

  handleClick = () => {
    this.props.onClick(this.props.spec.panelId);
  };

  render() {
    const { spec, isActive } = this.props;
    const containerClass = this.cls('tab') + (isActive ? ` ${this.cls('tab-active')}` : '');
    
    return React.createElement('div', { className: containerClass, onClick: this.handleClick },
      React.createElement('span', { 'aria-hidden': 'true' }, spec.icon),
      spec.label
    );
  }
}