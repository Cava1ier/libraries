import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface SettingsPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
}

export class SettingsPanel extends Component<SettingsPanelProps, {}> {
  prefix = 'settings-panel';
  styles = ['display', 'flex-direction', 'color', 'font-size', 'padding', 'border-bottom'];
  classnames = ['container', 'title', 'body'];
  styleValues = [
    ['flex', 'column', '#fff', '1rem', '1rem', '1px solid rgba(212,175,55,0.3)'], // container
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    [nl, nl, '#d4af37', '1.2rem', '0 0 0.5rem 0', nl],          // title
    [nl, nl, '#ccc', '0.9rem', nl, nl]                      // body
  ];

  // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
  render() {
    if (!this.props.isVisible) {
      return null;
    }
    return React.createElement('div', { className: this.cls('container') },
      React.createElement('h2', { className: this.cls('title') }, this.props.spec.title),
      React.createElement('p', { className: this.cls('body') }, 'Settings will be configured here.')
    );
  }
}