import React from 'react';
import { Component } from '../core/Component';
import { PanelSpec } from '../data/dPanelData';
import { PluginManager } from '../systems/plugin/PluginSystem';
import { ServiceFactory } from '../core/ServiceFactory';
import { LocalizationService } from '../services/LocalizationService';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface OptionsPanelProps {
  spec: PanelSpec;
  isVisible: boolean;
  pluginManager: PluginManager;
}

export class OptionsPanel extends Component<OptionsPanelProps, {}> {
  prefix = 'options-panel';
  styles = [
      'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
      'justify-content', 'margin-bottom', 'border-bottom', 'width', 'background-color', 'height',
      'overflow-y', 'gap', 'align-items'
  ];
  classnames = ['container', 'option-row', 'option-label', 'button-group', 'lang-button'];
  styleValues = [
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    ['flex', 'column', '1rem', nl, nl, '#ccc', nl, nl, nl, nl, nl, 'auto', 'auto', '1rem', 'flex-start'], // container
    ['flex', 'row', '0.5rem 0', 'sans-serif', '1rem', nl, 'space-between', nl, '1px solid rgba(212,175,55,0.1)', '100%', nl, nl, nl, nl, 'center'], // option-row
    [nl, nl, nl, nl, nl, '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, nl], // option-label
    ['flex', 'row', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.5rem', nl], // button-group
    [nl, nl, '0.5rem 1rem', nl, '0.9rem', '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl], // lang-button
  ];

  setLanguage = (lang: string) => {
    localStorage.setItem('language', lang);
    window.location.reload();
  }

  render() {
    if (!this.props.isVisible) {
      return null;
    }

    const localizationService = ServiceFactory.create<LocalizationService>('LocalizationService');
    const currentLang = localizationService.language;

    const baseButtonCls = this.cls('lang-button');
    const buttonStyle = (isActive: boolean) => ({
      backgroundColor: isActive ? '#d4af37' : 'rgba(255,255,255,0.1)',
      color: isActive ? '#1a1a2e' : '#fff',
      border: `1px solid ${isActive ? '#a08428' : '#555'}`,
      cursor: 'pointer',
      borderRadius: '5px'
    });

    return React.createElement('div', { className: this.cls('container') },
      React.createElement('h3', { className: this.cls('option-label'), style:{fontSize: '1.2rem'} }, localizationService.get('panel_options_title')),
      React.createElement('div', { className: this.cls('option-row') },
        React.createElement('span', { className: this.cls('option-label') }, localizationService.get('panel_options_language_label')),
        React.createElement('div', { className: this.cls('button-group') },
          React.createElement('button', { 
            className: baseButtonCls, 
            style: buttonStyle(currentLang === 'English'), 
            onClick: () => this.setLanguage('English') 
          }, 'English'),
          React.createElement('button', { 
            className: baseButtonCls, 
            style: buttonStyle(currentLang === 'Spanish'), 
            onClick: () => this.setLanguage('Spanish') 
          }, 'Español')
        )
      )
    );
  }
}