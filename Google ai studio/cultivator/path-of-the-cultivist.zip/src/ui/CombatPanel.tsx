import React from 'react';
import { Component } from '../core/Component';
import { CombatEncounter, ItemData } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface CombatPanelProps {
  combat: CombatEncounter;
  onCombatAction: (action: { type: string, id?: any }) => void;
  inventory: ItemData[];
  database: GameDatabase;
}

interface CombatPanelState {
    hoveredActionId: string | null;
}

export class CombatPanel extends Component<CombatPanelProps, CombatPanelState> {
    // Initialized ref as a class property.
    private logContainerRef: React.RefObject<HTMLDivElement> = React.createRef();

    prefix = 'combat-panel';
    styles = [
        'padding', 'text-align', 'color', 'font-weight', 'display', 'justify-content', 'gap', 'flex-wrap', 'width',
        'background-color', 'border-radius', 'border', 'overflow-y', 'position', 'height', 'transition', 'text-shadow',
        'font-size', 'margin-top', 'margin-bottom', 'align-items'
    ];
    classnames = [
        'container', 'title', 'participant-stats', 'stats-row', 'action-container', 'health-bar-container', 'health-bar-fill', 'health-bar-text',
        'combat-log', 'log-entry'
    ];
    styleValues = [
        // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
        ['2rem', 'center', '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1.5rem', nl, '0.5rem', nl], // container
        [nl, nl, '#d4af37', 'bold', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1.5rem', nl, '0.5rem', nl], // title
        ['1rem 0', 'left', '#eee', nl, 'block', nl, nl, nl, '100%', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // participant-stats
        ['0.2rem 0', nl, nl, nl, 'flex', 'space-between', '1rem', nl, '100%', nl, nl, nl, nl, 'relative', nl, nl, nl, '0.9rem', nl, nl, 'center'], // stats-row
        ['1rem 0', nl, nl, nl, 'flex', 'center', '0.5rem', 'wrap', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '1rem', nl, nl], // action-container
        [nl, nl, nl, nl, nl, nl, nl, nl, '100%', 'rgba(0,0,0,0.5)', '4px', '1px solid #555', 'hidden', 'relative', '22px', nl, nl, '0.9rem', nl, nl, nl], // health-bar-container
        [nl, nl, nl, nl, nl, nl, nl, nl, nl, '#f44336', '4px', nl, nl, nl, '100%', 'width 0.5s ease-in-out', nl, nl, nl, nl, nl], // health-bar-fill
        [nl, 'center', '#fff', 'bold', nl, 'center', nl, nl, '100%', nl, nl, nl, nl, 'absolute', nl, nl, '1px 1px 2px #000', '0.8rem', nl, nl, nl], // health-bar-text
        ['0.5rem', 'left', '#ccc', nl, nl, nl, nl, nl, '100%', 'rgba(0,0,0,0.3)', '5px', '1px solid #444', 'auto', nl, '100px', nl, nl, nl, '1rem', '1rem', nl], // combat-log
        ['0.2rem 0', 'left', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, '0.85rem', nl, nl, nl], // log-entry
    ];

    // FIX: Replaced constructor with a direct state initializer.
    state: CombatPanelState = {
        hoveredActionId: null
    };
    
    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    componentDidUpdate(prevProps: CombatPanelProps) {
        if (this.props.combat.log.length > prevProps.combat.log.length) {
            const logContainer = this.logContainerRef.current;
            if (logContainer) {
                logContainer.scrollTop = logContainer.scrollHeight;
            }
        }
    };
    
    // FIX: Converted to arrow function to fix 'this' context.
    private renderParticipant = (participant: any) => {
        const healthPercent = (participant.stats.health / participant.stats.maxHealth) * 100;
        return React.createElement('div', { key: participant.id, className: this.cls('participant-stats') },
            React.createElement('div', { className: this.cls('stats-row') },
                React.createElement('span', {}, participant.entity.name),
                React.createElement('span', {}, `Lvl ${participant.entity.cultivation_level || 'N/A'}`)
            ),
            React.createElement('div', { className: this.cls('health-bar-container') },
                React.createElement('div', { className: this.cls('health-bar-fill'), style: { width: `${healthPercent}%` } }),
                React.createElement('span', { className: this.cls('health-bar-text') }, `${participant.stats.health} / ${participant.stats.maxHealth}`)
            )
        );
    }

    // FIX: Converted to arrow function to fix 'this' context.
    private renderActions = () => {
        const { onCombatAction, inventory, database } = this.props;
        const player = this.props.combat.participants.find(p => p.isPlayer);
        if (!player) return null;

        const skills = database.getTable('tblCombatSkills')?.findAll() || [];
        const usableItems = inventory
            .map(item => ({ item, effect: database.getTable('tblItemCombatEffects')?.query((r: any) => r.item_id == item.typeId)[0] }))
            .filter(data => data.effect);

        const currentTurnParticipant = this.props.combat.participants[this.props.combat.turnIndex];
        const isPlayerTurn = currentTurnParticipant && currentTurnParticipant.isPlayer;

        const baseButtonCls = AppComponentLoader.cls('combat-button', 'base');
        const buttonStyle = (isHovered: boolean) => ({
            transform: isHovered ? 'scale(1.05)' : 'scale(1)',
            boxShadow: isHovered ? '0 0 10px rgba(212,175,55,0.7)' : 'none',
            opacity: isPlayerTurn ? 1 : 0.6,
            cursor: isPlayerTurn ? 'pointer' : 'not-allowed',
        });

        return React.createElement('div', { className: this.cls('action-container') },
            // Attack and Defend
            React.createElement('button', {
                className: baseButtonCls,
                style: buttonStyle(this.state.hoveredActionId === 'attack'),
                onMouseEnter: () => this.setState({ hoveredActionId: 'attack' }),
                onMouseLeave: () => this.setState({ hoveredActionId: null }),
                onClick: () => onCombatAction({ type: 'attack' }),
                disabled: !isPlayerTurn
            }, 'Attack'),
            React.createElement('button', {
                className: baseButtonCls,
                style: buttonStyle(this.state.hoveredActionId === 'defend'),
                onMouseEnter: () => this.setState({ hoveredActionId: 'defend' }),
                onMouseLeave: () => this.setState({ hoveredActionId: null }),
                onClick: () => onCombatAction({ type: 'defend' }),
                disabled: !isPlayerTurn
            }, 'Defend'),

            // Skills
            ...skills.map((skill: any) => React.createElement('button', {
                key: `skill-${skill.id}`,
                className: baseButtonCls,
                style: buttonStyle(this.state.hoveredActionId === `skill-${skill.id}`),
                onMouseEnter: () => this.setState({ hoveredActionId: `skill-${skill.id}` }),
                onMouseLeave: () => this.setState({ hoveredActionId: null }),
                onClick: () => onCombatAction({ type: 'skill', id: skill.id }),
                disabled: !isPlayerTurn || player.entity.qi_points < skill.qi_cost
            }, `${skill.name} (${skill.qi_cost} Qi)`)),

            // Items
            ...usableItems.map(({ item, effect }) => React.createElement('button', {
                key: `item-${item.id}`,
                className: baseButtonCls,
                style: buttonStyle(this.state.hoveredActionId === `item-${item.id}`),
                onMouseEnter: () => this.setState({ hoveredActionId: `item-${item.id}` }),
                onMouseLeave: () => this.setState({ hoveredActionId: null }),
                onClick: () => onCombatAction({ type: 'item', id: item.typeId }),
                disabled: !isPlayerTurn
            }, `${database.getTable('tblItemTypes').find(item.typeId)?.name} (x${item.quantity})`)),

            // Flee
            React.createElement('button', {
                className: baseButtonCls,
                style: {...buttonStyle(this.state.hoveredActionId === 'flee'), borderColor: '#aaa', color: '#aaa'},
                onMouseEnter: () => this.setState({ hoveredActionId: 'flee' }),
                onMouseLeave: () => this.setState({ hoveredActionId: null }),
                onClick: () => onCombatAction({ type: 'flee' }),
                disabled: !isPlayerTurn
            }, 'Flee'),
        );
    }
    
    // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
    render() {
        const { combat } = this.props;
        const modalCls = (clsName: string) => AppComponentLoader.cls('modal', clsName);
        
        const player = combat.participants.find(p => p.isPlayer);
        const opponent = combat.participants.find(p => !p.isPlayer);

        return React.createElement('div', { className: modalCls('overlay') },
            React.createElement('div', { 
                className: `${modalCls('panel-base')} ${this.cls('container')}`,
                style: { animation: 'combatGlow 2s infinite', maxWidth: '600px'}
            },
                React.createElement('h2', { className: this.cls('title') }, 'Combat Encounter!'),
                opponent && this.renderParticipant(opponent),
                player && this.renderParticipant(player),
                this.renderActions(),
                React.createElement('div', { ref: this.logContainerRef, className: this.cls('combat-log') },
                    ...combat.log.map((entry, i) => React.createElement('p', { key: i, className: this.cls('log-entry') }, entry))
                )
            )
        );
    }
}