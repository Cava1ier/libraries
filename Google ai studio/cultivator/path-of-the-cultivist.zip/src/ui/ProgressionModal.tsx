import React from 'react';
import { Component } from '../core/Component';
import { Character } from '../data/dCharacter';
import { AppComponentLoader } from '../systems/loader/AppComponentLoader';

// FIX: Added const for null shorthand used in style definitions.
const nl = null;

interface ProgressionModalProps {
  character: Character;
  onSpendPoint: (stat: string) => void;
  onClose: () => void;
}

export class ProgressionModal extends Component<ProgressionModalProps, {}> {
  prefix = 'progression-modal';
  styles = [
    'display', 'flex-direction', 'padding', 'font-family', 'font-size', 'color', 
    'justify-content', 'margin-bottom', 'border-bottom', 'font-style', 'margin-top',
    'background', 'border-radius', 'border', 'align-items', 'width', 'gap',
    'cursor', 'transition', 'font-weight'
  ];
  classnames = ['title', 'points-display', 'stat-row', 'stat-name', 'stat-value', 'spend-button'];
  styleValues = [
    // FIX: Replaced this.nl with nl to avoid 'this' access during initialization.
    [nl, nl, nl, 'serif', '1.8rem', '#d4af37', nl, '1rem', '1px solid rgba(212,175,55,0.2)', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // title
    [nl, nl, '0 1rem 1rem 1rem', nl, '1.2rem', '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl, '100%', nl, nl, nl, nl], // points-display
    ['flex', 'row', '0.5rem 1rem', 'sans-serif', '1rem', '#ccc', 'space-between', '0.5rem', nl, nl, nl, nl, nl, nl, 'center', '100%', '0.5rem', nl, nl, nl], // stat-row
    [nl, nl, nl, nl, nl, '#fff', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl], // stat-name
    [nl, nl, nl, nl, nl, '#d4af37', nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, nl, 'bold'], // stat-value
    ['flex', nl, '0.1rem 0.5rem', nl, '1rem', '#1a1a2e', 'center', nl, nl, nl, nl, '#d4af37', '50%', '1px solid #a08428', 'center', 'auto', nl, 'pointer', 'background-color 0.2s', 'bold'], // spend-button
  ];

  // FIX: Converted to arrow function to fix 'this' context.
  renderStat = (label: string, value: number, statKey: string) => {
    const { onSpendPoint, character } = this.props;
    return React.createElement('div', { key: statKey, className: this.cls('stat-row') },
      React.createElement('span', { className: this.cls('stat-name') }, label),
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '0.5rem' }},
        React.createElement('span', { className: this.cls('stat-value') }, value),
        React.createElement('button', {
          className: this.cls('spend-button'),
          onClick: () => onSpendPoint(statKey),
          disabled: character.attribute_points === 0,
          style: { opacity: character.attribute_points > 0 ? 1 : 0.5 }
        }, '+')
      )
    );
  }

  // FIX: Reverted to a standard class method for React lifecycle methods to ensure correct 'this' context and type inference.
  render() {
    const { character, onClose } = this.props;
    const modalCls = (clsName: string) => AppComponentLoader.cls('modal', clsName);

    const statsToUpgrade = [
      { label: 'Body Tempering', key: 'body_tempering', value: character.body_tempering },
      { label: 'Soul Strength', key: 'soul_strength', value: character.soul_strength },
      { label: 'Dao Comprehension', key: 'dao_comprehension', value: character.dao_comprehension },
      { label: 'Mental Fortitude', key: 'mental_fortitude', value: character.data.mental_fortitude },
      { label: 'Physical Resilience', key: 'physical_resilience', value: character.data.physical_resilience },
    ];

    return React.createElement('div', { className: modalCls('overlay') },
      React.createElement('div', { className: modalCls('panel-base'), style: { maxWidth: '400px' } },
        React.createElement('h2', { className: this.cls('title') }, 'Cultivation Breakthrough'),
        React.createElement('p', { className: this.cls('points-display') }, `Attribute Points: ${character.attribute_points}`),
        ...statsToUpgrade.map(s => this.renderStat(s.label, s.value, s.key)),
        React.createElement('button', { 
            className: modalCls('button'), 
            style: { marginTop: '1.5rem' },
            onClick: onClose 
        }, 'Done')
      )
    );
  }
}