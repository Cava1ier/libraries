
import { SkillType, SkillGainResult, SkillCheckResult, SkillBonus, BonusType, CriticalType } from '../types/AdventureTypes';
import { GameDatabase } from '../systems/database/Database';
import { RNGSystem } from '../systems/rng/RNGSystem';

export class dSkillSystem {
    private skillExperience: Map<SkillType, number> = new Map();
    private skillLevels: Map<SkillType, number> = new Map();
    private skillBonuses: Map<SkillType, SkillBonus[]> = new Map();
    private db: GameDatabase;
    private rng: RNGSystem;

    constructor(database: GameDatabase, rng: RNGSystem) {
        this.db = database;
        this.rng = rng;
        this.initializeSkills();
        this.setupSkillBonuses();
    }

    private initializeSkills(): void {
        const skillTable = this.db.getTable('tblSkillTypes');
        if (!skillTable) {
            console.warn("Skill System: 'tblSkillTypes' not found in database. Skills will not be initialized.");
            return;
        }
        const skillRecords = skillTable.findAll();
        skillRecords.forEach(record => {
            const skillId = Number(record.id);
            if (!isNaN(skillId)) {
                this.skillExperience.set(skillId, 0);
                this.skillLevels.set(skillId, 1);
            }
        });
    }

    public gainExperience(skillType: SkillType, amount: number, difficulty: number = 1): SkillGainResult {
        const currentExp = this.skillExperience.get(skillType) || 0;
        const currentLevel = this.skillLevels.get(skillType) || 1;
        
        const adjustedAmount = this.calculateAdjustedExperience(amount, difficulty, currentLevel);
        const newExp = currentExp + adjustedAmount;
        
        this.skillExperience.set(skillType, newExp);
        
        const expForNextLevel = this.getExperienceForLevel(currentLevel + 1);
        const leveledUp = newExp >= expForNextLevel;
        
        if (leveledUp) {
            const newLevel = currentLevel + 1;
            this.skillLevels.set(skillType, newLevel);
            this.skillExperience.set(skillType, newExp - expForNextLevel);
            
            return {
                experienceGained: adjustedAmount,
                leveledUp: true,
                newLevel: newLevel,
                bonusesUnlocked: this.checkForNewBonuses(skillType, newLevel)
            };
        }
        
        return {
            experienceGained: adjustedAmount,
            leveledUp: false,
            newLevel: currentLevel,
            bonusesUnlocked: []
        };
    }

    private calculateAdjustedExperience(amount: number, difficulty: number, currentLevel: number): number {
        const difficultyBonus = (difficulty * 1.5);
        const levelPenalty = 1 + (currentLevel / 10);
        return Math.max(1, Math.round((amount * difficultyBonus) / levelPenalty));
    }

    public getExperienceForLevel(level: number): number {
        return Math.floor(Math.pow(level, 2) * 100);
    }
    
    public getSkillLevel(skillType: SkillType): number {
        return this.skillLevels.get(skillType) || 1;
    }
    
    public getSkillExperience(skillType: SkillType): {current: number, required: number} {
        const level = this.getSkillLevel(skillType);
        return {
            current: this.skillExperience.get(skillType) || 0,
            required: this.getExperienceForLevel(level + 1)
        };
    }

    public performSkillCheck(skillType: SkillType, difficulty: number, circumstances: number = 0): SkillCheckResult {
        const skillLevel = this.skillLevels.get(skillType) || 1;
        const roll = this.rng.nextInRange(1, 20);
        
        const totalBonus = skillLevel + circumstances;
        const result = roll + totalBonus;
        
        const succeeded = result >= difficulty;
        const isCriticalSuccess = roll === 20;
        const isCriticalFailure = roll === 1;
        
        return {
            succeeded: isCriticalSuccess || (succeeded && !isCriticalFailure),
            roll: roll,
            total: result,
            margin: result - difficulty,
            critical: isCriticalSuccess || isCriticalFailure,
            criticalType: isCriticalSuccess ? CriticalType.Success : isCriticalFailure ? CriticalType.Failure : CriticalType.None
        };
    }

    private setupSkillBonuses(): void {
        this.skillBonuses.set(SkillType.Swordsmanship, [
            { type: BonusType.Damage, value: 5, requiredLevel: 5 },
            { type: BonusType.Damage, value: 10, requiredLevel: 10 },
        ]);
        this.skillBonuses.set(SkillType.Herbalism, [
            { type: BonusType.Gathering, value: 1, requiredLevel: 3 },
            { type: BonusType.Gathering, value: 1, requiredLevel: 7 },
        ]);
    }
    
    private checkForNewBonuses(skillType: SkillType, newLevel: number): SkillBonus[] {
        const bonuses = this.skillBonuses.get(skillType) || [];
        return bonuses.filter(b => b.requiredLevel === newLevel);
    }
}
