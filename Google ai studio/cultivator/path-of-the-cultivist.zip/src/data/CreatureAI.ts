


import { CreatureData, AIGoal } from '../types/AdventureTypes';

export class CreatureAI {
  private lastUpdateTime: number = 0;
  private currentGoal: AIGoal | null = null;
  
  constructor(private creature: CreatureData) {}

  public shouldUpdate(currentTime: number): boolean {
    const updateInterval = this.getUpdateInterval();
    return (currentTime - this.lastUpdateTime) > updateInterval;
  }

  public update(allCreatures: Map<string, CreatureData>, currentTime: number): void {
    this.lastUpdateTime = currentTime;
    
    // Branchless AI state machine
    const hasGoal = this.currentGoal ? 1 : 0;
    const needsNewGoal = hasGoal ^ 1; // XOR to flip
    
    if (needsNewGoal) {
      this.currentGoal = this.selectNewGoal(allCreatures);
    }
    
    if (this.currentGoal) {
      this.executeGoal(this.currentGoal, allCreatures);
    }
  }

  private selectNewGoal(allCreatures: Map<string, CreatureData>): AIGoal {
    // Numeric IDs correspond to tblAIGoalTypes: 1:Wander, 2:Hunt, 3:Flee, 4:Rest
    const goalTypes = [1, 2, 3, 4];
    const weights = this.calculateGoalWeights(allCreatures);
    
    return {
      typeId: this.weightedRandomSelect(goalTypes, weights),
      target: null,
      priority: 1,
      startTime: Date.now()
    };
  }

  private calculateGoalWeights(allCreatures: Map<string, CreatureData>): number[] {
    const nearbyThreats = this.countNearbyThreats(allCreatures);
    const nearbyPrey = this.countNearbyPrey(allCreatures);
    const energyLevel = this.creature.stats.energy;
    
    // Bitwise weight calculation
    const fleeWeight = nearbyThreats << 2; // Multiply by 4
    const huntWeight = (nearbyPrey & (this.creature.isHostile ? 1 : 0)) << 1; // Multiply by 2 if hostile
    const restWeight = (100 - energyLevel) >> 2; // Divide by 4
    const wanderWeight = 10; // Base wander tendency
    
    return [wanderWeight, huntWeight, fleeWeight, restWeight];
  }

  private getUpdateInterval(): number {
    // Different creatures update at different rates
    const baseInterval = 1000; // 1 second
    const speedModifier = this.creature.stats.speed;
    return baseInterval >> (speedModifier >> 2); // Faster creatures update more often
  }

  // --- Placeholder Methods ---
  private countNearbyThreats(allCreatures: Map<string, CreatureData>): number {
      // In a real implementation, this would scan for hostile creatures in a radius.
      return 0;
  }

  private countNearbyPrey(allCreatures: Map<string, CreatureData>): number {
      // In a real implementation, this would scan for non-hostile creatures.
      return 0;
  }

  private weightedRandomSelect(items: any[], weights: number[]): any {
      // In a real implementation, this would select an item based on weights.
      return items[0];
  }

  private executeGoal(goal: AIGoal, allCreatures: Map<string, CreatureData>): void {
      // In a real implementation, this would contain the logic for each goal type.
  }
}