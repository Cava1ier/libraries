
import { RNGSystem } from '../systems/rng/RNGSystem';
import { CreatureData, EntityStats } from '../types/AdventureTypes';
import { CreatureAI } from './CreatureAI';
import { GameDatabase } from '../systems/database/Database';

// Assuming RegionTileData is defined elsewhere from previous context
interface RegionTileData {
    x: number; y: number;
    biomeType: number; // Using number to align with BiomeType enum
    hasRiver: boolean;
}

export class CreatureSystem {
  public creatures: Map<string, CreatureData> = new Map();
  public aiUpdateQueue: CreatureAI[] = [];
  
  constructor(private rng: RNGSystem, private db: GameDatabase) {}

  public spawnCreaturesInRegion(regionX: number, regionY: number, regionData: RegionTileData): void {
    const creatureCount = this.calculateCreatureDensity(regionData);
    
    for (let i = 0; i < creatureCount; i++) {
      const creature = this.generateCreature(regionX, regionY, regionData.biomeType);
      this.creatures.set(creature.id, creature);
      this.aiUpdateQueue.push(new CreatureAI(creature));
    }
  }

  private calculateCreatureDensity(regionData: RegionTileData): number {
    // Bitwise density calculation based on biome
    const biomeDensity = [3, 5, 2, 1, 1, 4]; // Plains, Forest, Hills, Mountains, Desert, Swamp
    const baseDensity = biomeDensity[regionData.biomeType] || 2;
    const riverBonus = regionData.hasRiver ? 1 : 0;
    
    return (baseDensity + riverBonus) & 0x7; // Max 7 creatures per region
  }

  private generateCreature(regionX: number, regionY: number, biome: number): CreatureData {
    const creatureTypeIds = this.getCreatureTypesForBiome(biome);
    const selectedTypeId = creatureTypeIds[this.rng.next() % creatureTypeIds.length];
    const creatureRecord = this.db.getTable('tblCreatureTypes').find(selectedTypeId);
    
    return {
      id: `creature_${regionX}_${regionY}_${this.rng.next()}`,
      typeId: selectedTypeId,
      position: {
        x: (regionX * 16) + (this.rng.next() % 16),
        y: (regionY * 16) + (this.rng.next() % 16),
        z: 5
      },
      isHostile: creatureRecord ? creatureRecord.isHostile === 1 : false,
      stats: this.generateCreatureStats(selectedTypeId),
      name: creatureRecord ? creatureRecord.name : 'Unknown Creature'
    };
  }

  private getCreatureTypesForBiome(biome: number): number[] {
    // Lookup table for biome-appropriate creatures using their database IDs
    const biomeCreatures = [
      [1, 2, 3], // Plains: Deer, Wolf, Rabbit
      [4, 2, 5],   // Forest: Bear, Wolf, Boar
      [6, 7, 2],  // Hills: Goat, Eagle, Wolf
      [7, 6],                     // Mountains: Eagle, Goat
      [8, 9],                 // Desert: Snake, Scorpion
      [10, 8, 5]   // Swamp: Frog, Snake, Boar
    ];
    
    return biomeCreatures[biome] || [3]; // Default to Rabbit
  }

  private generateCreatureStats(typeId: number): EntityStats {
    // Placeholder stats generation
    return { health: 50, maxHealth: 50, energy: 100, speed: 5, attack: 5, defense: 5 };
  }

  public updateCreatureAI(deltaTime: number): void {
    this.aiUpdateQueue.forEach(ai => {
      if (ai.shouldUpdate(deltaTime)) {
        ai.update(this.creatures, deltaTime);
      }
    });
  }
}
