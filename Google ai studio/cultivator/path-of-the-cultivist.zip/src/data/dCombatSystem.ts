
import { RNGSystem } from '../systems/rng/RNGSystem';
import { CombatEncounter, CreatureData, CombatParticipant, EntityStats } from '../types/AdventureTypes';
import { dInventorySystem } from './dInventorySystem';
import { GameDatabase } from '../systems/database/Database';

export class dCombatSystem {
  public currentCombat: CombatEncounter | null = null;
  private rng: RNGSystem;
  private inventorySystem: dInventorySystem;
  private database: GameDatabase;
  private onUpdate: () => void = () => {};

  constructor(rng: RNGSystem, inventorySystem: dInventorySystem, database: GameDatabase) {
    this.rng = rng;
    this.inventorySystem = inventorySystem;
    this.database = database;
  }

  public setUpdateCallback(callback: () => void) {
    this.onUpdate = callback;
  }

  public startCombat(player: any, creature: CreatureData): CombatEncounter {
    const playerStats: EntityStats = {
        health: player.qi_points,
        maxHealth: 1000,
        attack: 5 + Math.floor(player.body_tempering / 5),
        defense: 5 + Math.floor(player.physical_resilience / 10),
        speed: 5 + Math.floor(player.fate_threads / 10),
        energy: 100
    };

    const playerParticipant: CombatParticipant = {
      id: 'player',
      entity: player,
      isPlayer: true,
      stats: JSON.parse(JSON.stringify(playerStats)),
      initiative: this.rng.nextInRange(1, 20) + playerStats.speed,
      statusEffects: [],
    };

    const creatureParticipant: CombatParticipant = {
      id: creature.id,
      entity: creature,
      isPlayer: false,
      stats: JSON.parse(JSON.stringify(creature.stats)),
      initiative: this.rng.nextInRange(1, 20) + creature.stats.speed,
      statusEffects: [],
    };

    const participants = [playerParticipant, creatureParticipant];
    participants.sort((a, b) => b.initiative - a.initiative);

    this.currentCombat = {
      id: `combat_${Date.now()}`,
      participants,
      turnIndex: -1,
      log: [`Combat started with ${creature.name}! ${participants[0].entity.name} has the initiative.`],
      isActive: true,
    };

    this.processNextTurn();
    return this.currentCombat;
  }
  
  public handlePlayerAction(action: { type: string, id?: any }) {
    if (!this.currentCombat || !this.currentCombat.isActive) return;
    const participant = this.currentCombat.participants[this.currentCombat.turnIndex];
    if (!participant.isPlayer) {
        this.currentCombat.log.push("It is not your turn!");
        return;
    }

    let result: any;
    switch (action.type) {
        case 'attack': result = this.playerAttack(); break;
        case 'defend': result = this.playerDefend(); break;
        case 'skill': result = this.playerUseSkill(action.id); break;
        case 'item': result = this.playerUseItem(action.id); break;
        case 'flee':
            this.currentCombat.log.push("You fled from combat.");
            this.currentCombat.isActive = false;
            break;
    }
    
    if (result?.combatEnded) {
        this.currentCombat.isActive = false;
    } else if (this.currentCombat.isActive) {
        this.processNextTurn();
    }
  }

  private processNextTurn() {
    if (!this.currentCombat || !this.currentCombat.isActive) return;

    this.currentCombat.turnIndex = (this.currentCombat.turnIndex + 1) % this.currentCombat.participants.length;
    const participant = this.currentCombat.participants[this.currentCombat.turnIndex];

    this.processTurnEffects(participant);

    if (participant.stats.health <= 0) {
      this.processNextTurn();
      return;
    }

    if (!participant.isPlayer) {
      setTimeout(() => {
        if (this.currentCombat?.isActive) {
          this.processCreatureTurn(participant);
          this.onUpdate();
        }
      }, 750);
    }
  }

  private processCreatureTurn(creature: CombatParticipant) {
      if (!this.currentCombat || !this.currentCombat.isActive) return;
      
      const player = this.currentCombat.participants.find(p => p.isPlayer);
      if (!player) return;

      const result = this.executeAttack(creature, player);
      this.currentCombat.log.push(result.log);
      
      if (player.stats.health <= 0) {
          this.currentCombat.log.push(`You have been defeated!`);
          this.currentCombat.isActive = false;
      } else {
          this.processNextTurn();
      }
  }

  public endCombat() {
    this.currentCombat = null;
  }

  private processTurnEffects(participant: CombatParticipant) {
    if (!participant.statusEffects) participant.statusEffects = [];
    participant.statusEffects = participant.statusEffects.map((effect: any) => ({
      ...effect,
      turns: effect.turns - 1,
    })).filter((effect: any) => effect.turns > 0);
  }

  private playerAttack(): { log: string, combatEnded: boolean, playerWon: boolean } {
    const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
    const creature = this.currentCombat!.participants.find(p => !p.isPlayer)!;
    const result = this.executeAttack(player, creature);
    this.currentCombat!.log.push(result.log);

    if (creature.stats.health <= 0) {
      this.currentCombat!.log.push(`${creature.entity.name} defeated!`);
      return { log: result.log, combatEnded: true, playerWon: true };
    }
    return { log: result.log, combatEnded: false, playerWon: false };
  }
  
  public playerDefend(): { log: string } {
      const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
      const log = "You brace for the next attack.";
      player.statusEffects.push({ type: 'defending', turns: 2 });
      this.currentCombat!.log.push(log);
      return { log };
  }
  
  public playerUseSkill(skillId: number): { log: string, combatEnded: boolean, playerWon: boolean } {
    const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
    const creature = this.currentCombat!.participants.find(p => !p.isPlayer)!;
    const skill = this.database.getTable('tblCombatSkills').find(skillId);
    
    if (!skill || player.entity.qi_points < skill.qi_cost) {
      const log = !skill ? "Skill not found." : "Not enough Qi.";
      this.currentCombat!.log.push(log);
      return { log, combatEnded: false, playerWon: false };
    }

    player.entity.qi_points -= skill.qi_cost;
    let log = `You used ${skill.name}.`;
    
    if (skill.effect_type === 'DAMAGE') {
      const statValue = skill.effect_value_stat !== 'none' ? (player.entity[skill.effect_value_stat] || 0) : 0;
      const damage = skill.effect_value_base + Math.floor(statValue * skill.effect_value_multiplier);
      creature.stats.health -= damage;
      log += ` It dealt ${damage} damage.`;
    } else if (skill.effect_type === 'HEAL') {
      const healAmount = skill.effect_value_base;
      player.entity.qi_points = Math.min(1000, player.entity.qi_points + healAmount);
      log += ` You recover ${healAmount} Qi.`;
    }
    
    this.currentCombat!.log.push(log);

    if (creature.stats.health <= 0) {
      this.currentCombat!.log.push(`${creature.entity.name} defeated!`);
      return { log, combatEnded: true, playerWon: true };
    }
    
    return { log, combatEnded: false, playerWon: false };
  }
  
  public playerUseItem(itemId: number): { log: string, combatEnded: boolean, playerWon: false } {
    const player = this.currentCombat!.participants.find(p => p.isPlayer)!;
    const itemRecord = this.database.getTable('tblItemTypes').find(itemId);
    const itemEffect = this.database.getTable('tblItemCombatEffects').query((r: any) => r.item_id == itemId)[0];

    let log = "You don't have that item.";
    if (itemRecord && itemEffect && this.inventorySystem.removeItem(itemId, 1)) {
        log = `You used a ${itemRecord.name}.`;
        if (itemEffect.effect_type === 'HEAL') {
            player.entity.qi_points = Math.min(1000, player.entity.qi_points + parseInt(itemEffect.effect_value));
            log += ` You recover ${itemEffect.effect_value} Qi.`;
        }
    } else if (itemRecord) {
        log = `You can't use ${itemRecord.name} in combat.`;
    }
    this.currentCombat!.log.push(log);
    
    return { log, combatEnded: false, playerWon: false };
  }

  private executeAttack(attacker: CombatParticipant, defender: CombatParticipant) {
    const isDefending = defender.statusEffects.some(e => e.type === 'defending');
    const attackRoll = this.rng.nextInRange(1, 20) + attacker.stats.attack;
    const defenseValue = defender.stats.defense + (isDefending ? 5 : 0);

    if (attackRoll > defenseValue) {
      let damage = this.rng.nextInRange(Math.floor(attacker.stats.attack / 2), attacker.stats.attack);
      if (isDefending) {
          damage = Math.floor(damage / 2);
          this.currentCombat?.log.push(`${defender.entity.name} defends!`);
      }
      defender.stats.health -= damage;
      return { damage, log: `${attacker.entity.name} hits ${defender.entity.name} for ${damage} damage.` };
    } else {
      return { damage: 0, log: `${attacker.entity.name}'s attack is blocked by ${defender.entity.name}.` };
    }
  }
}
