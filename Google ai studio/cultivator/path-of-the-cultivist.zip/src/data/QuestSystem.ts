

import { RNGSystem } from '../systems/rng/RNGSystem';
// FIX: Imported missing QuestTemplate and QuestReward types.
import { QuestData, QuestTemplate, QuestReward, QuestType, ItemType } from '../types/AdventureTypes';

// Assuming RegionTileData is defined elsewhere
interface RegionTileData { x: number; y: number; }

export class QuestSystem {
  private activeQuests: QuestData[] = [];
  private completedQuests: string[] = [];
  private questTemplates: QuestTemplate[] = [];

  constructor(private rng: RNGSystem) {
    this.initializeQuestTemplates();
  }

  private initializeQuestTemplates(): void {
    this.questTemplates = [
      {
        id: 'explore_ruins',
        title: 'Ancient Mysteries',
        description: 'Explore the ruins to the {direction} and report back.',
        // FIX: Property 'type' does not exist on type 'QuestTemplate', changed to 'typeId'.
        typeId: QuestType.Exploration,
        requirements: [{ type: 'visit_site', target: 'ruins', count: 1 }],
        // FIX: Property 'item' does not exist in type 'QuestReward', changed to 'itemId'.
        rewards: [{ type: 'experience', amount: 100 }, { type: 'item', itemId: ItemType.Coin, count: 50 }]
      },
      {
        id: 'slay_beast',
        title: 'Beast Hunter',
        description: 'A dangerous {creature_type} has been spotted near {location}. Eliminate the threat.',
        // FIX: Property 'type' does not exist on type 'QuestTemplate', changed to 'typeId'.
        typeId: QuestType.Combat,
        requirements: [{ type: 'kill_creature', target: 'wolf', count: 1 }],
        // FIX: Property 'item' does not exist in type 'QuestReward', changed to 'itemId'.
        rewards: [{ type: 'experience', amount: 200 }, { type: 'item', itemId: ItemType.IronSword, count: 1 }]
      }
    ];
  }

  public generateRandomQuest(playerLevel: number, nearbyRegions: RegionTileData[]): QuestData | null {
    const availableTemplates = this.questTemplates.filter(template => 
      this.isQuestAppropriate(template, playerLevel)
    );
    
    if (availableTemplates.length === 0) return null;
    
    const template = availableTemplates[this.rng.next() % availableTemplates.length];
    return this.instantiateQuest(template, nearbyRegions);
  }

  private instantiateQuest(template: QuestTemplate, regions: RegionTileData[]): QuestData {
    const targetRegion = regions[this.rng.next() % regions.length];
    
    return {
      id: `${template.id}_${this.rng.next()}`,
      name: template.title, // Add name property
      title: template.title,
      description: this.fillQuestDescription(template.description, targetRegion),
      // FIX: Property 'type' does not exist on type 'QuestData' or 'QuestTemplate', changed to 'typeId'.
      typeId: template.typeId,
      requirements: [...template.requirements],
// FIX: The QuestData type was missing the 'rewards' property. It has been added to AdventureTypes.ts.
      rewards: [...template.rewards],
      progress: {},
      isComplete: false,
      targetLocation: { x: targetRegion.x, y: targetRegion.y },
      // Added dummy properties to satisfy the base QuestData type
      objective_type: 'HUNT',
      objective_target: 'N/A',
      objective_count: 0,
      reward_xp: 0,
      reward_item_id: 0,
      reward_item_count: 0,
    };
  }

  public updateQuestProgress(questId: string, progressType: string, target: string, amount: number = 1): void {
    const quest = this.activeQuests.find(q => q.id === questId);
    if (!quest || !quest.requirements) return;
    
    const key = `${progressType}_${target}`;
    quest.progress[key] = (quest.progress[key] || 0) + amount;
    
    quest.isComplete = quest.requirements.every(req => {
      const progressKey = `${req.type}_${req.target}`;
      return (quest.progress[progressKey] || 0) >= req.count;
    });
    
    if (quest.isComplete) {
      this.completeQuest(questId);
    }
  }

  private completeQuest(questId: string): void {
    const questIndex = this.activeQuests.findIndex(q => q.id === questId);
    if (questIndex >= 0) {
      const quest = this.activeQuests.splice(questIndex, 1)[0];
      this.completedQuests.push(questId);
// FIX: The QuestData type was missing the 'rewards' property. It has been added to AdventureTypes.ts.
      quest.rewards?.forEach(reward => {
        this.awardReward(reward);
      });
    }
  }
  
  public getActiveQuests(): QuestData[] {
      return this.activeQuests;
  }

  // --- Placeholder Methods ---
  private isQuestAppropriate(template: QuestTemplate, playerLevel: number): boolean {
    return true; // In a real implementation, this would check player level against quest difficulty.
  }

  private fillQuestDescription(description: string, targetRegion: RegionTileData): string {
    return description.replace('{direction}', 'east').replace('{creature_type}', 'wolf').replace('{location}', 'forest');
  }

  private awardReward(reward: QuestReward): void {
    // In a real implementation, this would grant XP or items to the player.
  }
}