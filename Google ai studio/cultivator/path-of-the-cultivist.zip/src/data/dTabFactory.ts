import React from 'react';
import { TabSpec } from './dTabData';
import { TabBase } from '../ui/TabBase';

export class TabFactory {
  static create(spec: TabSpec, isActive: boolean, onClick: (panelId: string) => void): React.ReactElement {
    const props = { spec, isActive, onClick, key: spec.id };
    return React.createElement(TabBase, props);
  }
}