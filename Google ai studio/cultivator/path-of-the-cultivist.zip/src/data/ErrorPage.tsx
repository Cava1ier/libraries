import React from 'react';
import { Component } from '../core/Component';
import { PluginManager } from '../systems/plugin/PluginSystem';

interface ErrorPageProps {
    message?: string;
    pluginManager: PluginManager;
}

export class ErrorPage extends Component<ErrorPageProps, {}> {
    prefix = 'error-page';
    
    handleReturnToMenu = () => {
        this.props.pluginManager.loadPage('menu');
    }

    render() {
        const message = this.props.message || "An unknown error occurred.";
        return React.createElement('div', { className: this.cls('container') },
            React.createElement('h1', { className: this.cls('title') }, 'A Path Was Lost'),
            React.createElement('p', { className: this.cls('message') }, message),
            React.createElement('button', { className: this.cls('button'), onClick: this.handleReturnToMenu }, 'Return to the Main Menu')
        );
    }
}