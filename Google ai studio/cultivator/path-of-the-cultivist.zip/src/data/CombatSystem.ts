

import { RNGSystem } from '../systems/rng/RNGSystem';
import { PlayerData, CreatureData, EntityStats, CombatEncounter, CombatParticipant, CombatResult } from '../types/AdventureTypes';

export class CombatSystem {
  public currentCombat: CombatEncounter | null = null;
  
  constructor(private rng: RNGSystem) {}

  // FIX: Rewrote initiateCombat to create a CombatEncounter object that matches the type definition.
  public initiateCombat(player: PlayerData, creature: CreatureData): CombatEncounter {
    const playerParticipant: CombatParticipant = {
        id: player.id,
        entity: player,
        isPlayer: true,
        stats: { ...player.stats },
        initiative: this.rollInitiative(player.stats),
        statusEffects: []
    };
    const creatureParticipant: CombatParticipant = {
        id: creature.id,
        entity: creature,
        isPlayer: false,
        stats: { ...creature.stats },
        initiative: this.rollInitiative(creature.stats),
        statusEffects: []
    };
    
    const participants = [playerParticipant, creatureParticipant];
    participants.sort((a, b) => b.initiative - a.initiative);

    this.currentCombat = {
      id: `combat_${Date.now()}`,
      participants: participants,
      turnIndex: 0,
      log: [`Combat started with ${creature.name}! ${participants[0].entity.name} has initiative.`],
      isActive: true,
    };
    
    return this.currentCombat;
  }

  private rollInitiative(stats: EntityStats): number {
    const roll = (this.rng.next() % 20) + 1;
    return stats.speed + roll;
  }

  public executeAttack(attacker: CombatParticipant, defender: CombatParticipant): CombatResult {
    // FIX: Use participant's direct `stats` property for combat calculations.
    const attackRoll = this.rollD20() + attacker.stats.attack;
    const defenseValue = defender.stats.defense;
    
    // Branchless hit calculation: isHit will be 1 if attackRoll > defenseValue, otherwise 0
    const isHit = ((defenseValue - attackRoll) >> 31) & 1;
    
    if (isHit) {
      // FIX: Use participant's direct `stats` property for combat calculations.
      const damage = this.calculateDamage(attacker.stats.attack); // Use attack for damage base
      defender.stats.health -= damage;
      
      return {
        hit: true,
        damage: damage,
        // FIX: Use participant's direct `stats` property for combat calculations.
        remainingHealth: defender.stats.health,
        isFatal: defender.stats.health <= 0
      };
    }
    
    // FIX: Use participant's direct `stats` property for combat calculations.
    return { hit: false, damage: 0, remainingHealth: defender.stats.health, isFatal: false };
  }

  private rollD20(): number {
    return (this.rng.next() % 20) + 1;
  }

  private calculateDamage(attack: number): number {
    const baseDamage = (this.rng.next() % 6) + 1; // 1d6
    return baseDamage + (attack >> 1); // Add half of attack
  }

  public getCurrentCombat(): CombatEncounter | null {
      return this.currentCombat;
  }
}