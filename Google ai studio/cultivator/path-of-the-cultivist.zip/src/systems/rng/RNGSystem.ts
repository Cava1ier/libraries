export class RNGSystem {
 private numbers: number[];
 private currentIndex: number;
 private seed: number;

 constructor(initialNumbers?: number[], seed?: number) {
  this.currentIndex = 0;

  if (initialNumbers && initialNumbers.length > 0) {
   this.numbers = initialNumbers;
   // When providing an initial array, the seed is not used for generation,
   // but we initialize it for consistency.
   this.seed = seed ?? Date.now();
  } else {
   // If no initial numbers, generate them using a seed.
   // Fall back to a time-based seed if none is provided.
   this.seed = seed ?? Date.now();
   this.numbers = [];
   this.generateNumbers();
  }
 }
 
 /**
  * A simple Linear Congruential Generator (LCG) for seeded random numbers.
  * @returns a pseudo-random number between 0 and 1.
  */
 private seededRandom() {
    this.seed = (this.seed * 1664525 + 1013904223) % Math.pow(2, 32);
    return this.seed / Math.pow(2, 32);
 }

 generateNumbers() {
  this.numbers = Array.from({ length: 400 }, () => Math.floor(this.seededRandom() * 1000));
 }
 
 next() {
  const num = this.numbers[this.currentIndex];
  this.currentIndex = (this.currentIndex + 1) % this.numbers.length;
  return num;
 }
 
 nextInRange(min: number, max: number) {
  if (this.numbers.length === 0) {
    return min;
  }
  return min + (this.next() % (max - min + 1));
 }

 getNumbers(): number[] {
    return [...this.numbers];
 }

 public setCurrentIndex(index: number): void {
    if (this.numbers.length > 0) {
        this.currentIndex = index % this.numbers.length;
    }
 }

 public getCurrentIndex(): number {
    return this.currentIndex;
 }
}
