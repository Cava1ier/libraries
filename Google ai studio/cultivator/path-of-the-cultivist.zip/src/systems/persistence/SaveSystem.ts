
import { Character } from "../../data/dCharacter";
import { dInventorySystem } from "../../data/dInventorySystem";
import { dQuestSystem } from "../../data/dQuestSystem";
import { WeatherSystem } from "../environment/WeatherSystem";

const SAVE_KEY = 'cultivist_savegame';

export interface SaveData {
    characterData: any;
    quests: any[];
    inventory: any[];
    time: any;
    discoveredTiles: string[];
}

export class SaveSystem {
    public saveGame(gameState: any): boolean {
        try {
            const characterGameWorld = gameState.characterGameWorld;
            const saveData: SaveData = {
                characterData: (characterGameWorld.character as Character).data,
                quests: (gameState.questSystem as dQuestSystem).getActiveQuests(),
                inventory: (gameState.inventorySystem as dInventorySystem).getItems(),
                time: (gameState.weatherSystem as WeatherSystem).getTime(),
                discoveredTiles: Array.from(characterGameWorld.discoveredTiles),
            };
            
            const json = JSON.stringify(saveData);
            localStorage.setItem(SAVE_KEY, json);
            console.log("Game Saved!");
            return true;
        } catch (error) {
            console.error("Failed to save game:", error);
            return false;
        }
    }

    public loadGame(): SaveData | null {
        try {
            const json = localStorage.getItem(SAVE_KEY);
            if (!json) return null;
            
            const loadedData: SaveData = JSON.parse(json);
            console.log("Game Loaded!", loadedData);
            return loadedData;
        } catch (error) {
            console.error("Failed to load game:", error);
            return null;
        }
    }
    
    public hasSaveGame(): boolean {
        return localStorage.getItem(SAVE_KEY) !== null;
    }
}
