import { GameWorldData } from '../../components/GameWorld/dataGameWorld';
import { BaseTile } from '../tiles/BaseTile';
import { CreatureData } from '../../types/AdventureTypes';

// Configuration for rendering
export const TILE_SIZE = 24;
const FONT_SIZE = 20;

type TileStyle = {
    color: string | null;
    bgColor: string | null;
    animation?: string | null;
};

const resourceIcons: { [key: string]: { icon: string, color: string } } = {
    'herb_node': { icon: '🌿', color: '#90EE90' },
    'iron_vein_ore': { icon: '💎', color: '#B0C4DE' },
    'spiritwood_tree': { icon: '🌳', color: '#98FB98' },
    'ancient_forge': { icon: '🔥', color: '#FF8C00' },
};

export class MapRenderer {
    private ctx: CanvasRenderingContext2D;
    private tileStyles: Map<string, TileStyle>;

    constructor(
        canvas: HTMLCanvasElement,
        tileStyles: Map<string, TileStyle>
    ) {
        this.ctx = canvas.getContext('2d')!;
        this.tileStyles = tileStyles;

        const VIEWPORT_WIDTH = 31;
        const VIEWPORT_HEIGHT = 21;
        canvas.width = VIEWPORT_WIDTH * TILE_SIZE;
        canvas.height = VIEWPORT_HEIGHT * TILE_SIZE;

        this.ctx.font = `bold ${FONT_SIZE}px monospace`;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
    }

    private drawQuestMarker(quest: any, viewStartX: number, viewStartY: number, timestamp: number) {
        const { x, y } = quest.targetLocation;
        const screenX = (x - viewStartX) * TILE_SIZE;
        const screenY = (y - viewStartY) * TILE_SIZE;
    
        // Check if the marker is within the visible canvas area
        if (screenX >= -TILE_SIZE && screenX < this.ctx.canvas.width && screenY >= -TILE_SIZE && screenY < this.ctx.canvas.height) {
            const pulseValue = Math.sin(timestamp / 200) * 0.4 + 0.6; // Opacity pulse
            const sizePulse = Math.sin(timestamp / 200) * 2; // Size pulse
            const colorPulse = Math.round(Math.sin(timestamp / 300) * 55 + 200); // Color pulse (yellow to white)

            this.ctx.globalAlpha = pulseValue;
            this.ctx.fillStyle = `rgb(255, ${colorPulse}, 0)`;
            this.ctx.font = `bold ${FONT_SIZE + sizePulse}px monospace`;
            
            // Add a shadow for better visibility
            this.ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
            this.ctx.shadowBlur = 10;
            
            this.ctx.fillText('★', screenX + TILE_SIZE / 2, screenY + TILE_SIZE / 2 + 2);

            // Reset context properties
            this.ctx.globalAlpha = 1.0;
            this.ctx.shadowBlur = 0;
            this.ctx.font = `bold ${FONT_SIZE}px monospace`;
        }
    }

    public draw(data: GameWorldData) {
        const timestamp = performance.now();
        // FIX: Replaced non-existent `characterGameWorld` with `gameCoordinator`.
        const { character, mapData, currentPath, gameCoordinator, creatures, trackedQuest } = data;
        const viewData = mapData.getMapViewData(character.data);

        this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);

        // Draw tiles with fog of war
        viewData.rows.forEach((row, y) => {
            row.tiles.forEach((tileData, x) => {
                this.drawTile(tileData, x, y, mapData.viewZ, timestamp, gameCoordinator.discoveredTiles, gameCoordinator.lineOfSightTiles);
            });
        });
        
        // Draw path line
        if (currentPath && currentPath.length > 0) {
            this.drawPath(currentPath, viewData.startX, viewData.startY);
        }
        
        // Draw creatures
        creatures.forEach(creature => {
            this.drawCreature(creature, viewData.startX, viewData.startY, mapData.viewZ, gameCoordinator.lineOfSightTiles);
        });

        // Draw player
        this.drawPlayer(character.data, viewData.startX, viewData.startY, mapData.viewZ);
        
        // Draw quest marker on top of characters and terrain for maximum visibility
        if (trackedQuest && trackedQuest.targetLocation) {
            this.drawQuestMarker(trackedQuest, viewData.startX, viewData.startY, timestamp);
        }

        // Draw cursor in 'look' mode
        if (mapData.mode === 'look') {
            this.drawCursor(mapData.cursorPos, viewData.startX, viewData.startY, timestamp);
        }
    }

    private drawTile(tileData: any, x: number, y: number, viewZ: number, timestamp: number, discovered: Set<string>, los: Set<string>) {
        const screenX = x * TILE_SIZE;
        const screenY = y * TILE_SIZE;

        if (!tileData.tile) {
            return; // Don't draw empty space
        }
        
        const tile = tileData.tile as BaseTile;
        const tileKey = `${tile.x},${tile.y}`; // 2D Fog of War for simplicity at current viewZ
        
        const isDiscovered = discovered.has(tileKey);
        if (!isDiscovered) {
            this.ctx.fillStyle = '#050505';
            this.ctx.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
            return;
        }

        const isVisible = los.has(tileKey);
        const style = this.tileStyles.get(tile.type) || { color: '#FFF', bgColor: '#111' };
        const zDiff = viewZ - tile.z;
        const opacity = zDiff > 0 ? Math.max(0.1, 1.0 - zDiff * 0.18) : 1.0;

        let bgColor = style.bgColor!;
        let fgColor = style.color!;

        if (style.animation?.includes('shimmer')) {
            const shimmerValue = Math.sin(timestamp / 500) * 0.2 + 0.8;
            fgColor = this.adjustHexOpacity(style.color!, shimmerValue);
        }
        if (style.animation?.includes('pulse')) {
            const pulseValue = Math.sin(timestamp / 300) * 0.3 + 0.7;
            bgColor = this.adjustHexOpacity(style.bgColor!, pulseValue + 0.2);
        }

        this.ctx.globalAlpha = 1.0;
        this.ctx.fillStyle = bgColor;
        this.ctx.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);

        if (tile.type === 'up_slope' || tile.type === 'down_slope') {
            const pulseValue = Math.sin(timestamp / 300) * 5 + 10;
            this.ctx.shadowBlur = pulseValue;
            this.ctx.shadowColor = 'rgba(255, 255, 150, 0.7)';
        }

        this.ctx.globalAlpha = opacity;
        this.ctx.fillStyle = fgColor;
        this.ctx.fillText(tile.symbol, screenX + TILE_SIZE / 2, screenY + TILE_SIZE / 2 + 2);

        // Draw resource icon if applicable and visible
        const resource = resourceIcons[tile.type];
        if (resource && isVisible) {
            this.ctx.globalAlpha = 1.0; // Ensure icon is not transparent
            this.ctx.fillStyle = resource.color;
            this.ctx.font = `bold ${FONT_SIZE - 8}px monospace`; // Smaller font for icon
            this.ctx.fillText(resource.icon, screenX + TILE_SIZE / 2, screenY + TILE_SIZE / 2 + 2);
            this.ctx.font = `bold ${FONT_SIZE}px monospace`; // Reset font
        }

        this.ctx.shadowBlur = 0;
        this.ctx.shadowColor = 'transparent';

        if (!isVisible) {
            this.ctx.globalAlpha = 0.6;
            this.ctx.fillStyle = 'rgba(0,0,0,0.7)';
            this.ctx.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
        }
    }

    private drawPlayer(character: any, viewStartX: number, viewStartY: number, viewZ: number) {
        const screenX = (character.x - viewStartX) * TILE_SIZE;
        const screenY = (character.y - viewStartY) * TILE_SIZE;
        const zDiff = viewZ - character.z;
        
        this.ctx.globalAlpha = (zDiff === 0) ? 1.0 : 0.5;
        this.ctx.fillStyle = '#d4af37';
        this.ctx.fillText('仙', screenX + TILE_SIZE / 2, screenY + TILE_SIZE / 2 + 2);
    }

    private drawCreature(creature: CreatureData, viewStartX: number, viewStartY: number, viewZ: number, los: Set<string>) {
        if (!los.has(`${creature.position.x},${creature.position.y}`)) return;

        const screenX = (creature.position.x - viewStartX) * TILE_SIZE;
        const screenY = (creature.position.y - viewStartY) * TILE_SIZE;
        const zDiff = viewZ - creature.position.z;
        
        if (screenX < -TILE_SIZE || screenX > this.ctx.canvas.width || screenY < -TILE_SIZE || screenY > this.ctx.canvas.height) {
            return;
        }

        this.ctx.globalAlpha = (zDiff === 0) ? 1.0 : 0.5;
        this.ctx.fillStyle = creature.isHostile ? '#ff4d4d' : '#4d94ff';
        const symbol = creature.isHostile ? creature.name.charAt(0) : '人';
        this.ctx.fillText(symbol, screenX + TILE_SIZE / 2, screenY + TILE_SIZE / 2 + 2);
    }

    private drawCursor(cursorPos: {x: number, y: number}, viewStartX: number, viewStartY: number, timestamp: number) {
        const screenX = (cursorPos.x - viewStartX) * TILE_SIZE;
        const screenY = (cursorPos.y - viewStartY) * TILE_SIZE;
        
        const pulseValue = Math.sin(timestamp / 200) * 0.4 + 0.6;

        this.ctx.globalAlpha = pulseValue;
        this.ctx.strokeStyle = '#d4af37';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(screenX + 1, screenY + 1, TILE_SIZE - 2, TILE_SIZE - 2);
    }
    
    private drawPath(path: {x: number, y: number}[], viewStartX: number, viewStartY: number) {
        this.ctx.globalAlpha = 0.6;
        this.ctx.fillStyle = '#FFFFFF';
        
        path.forEach(p => {
            const screenX = (p.x - viewStartX) * TILE_SIZE;
            const screenY = (p.y - viewStartY) * TILE_SIZE;

            if (screenX < 0 || screenX > this.ctx.canvas.width || screenY < 0 || screenY > this.ctx.canvas.height) {
                return;
            }
            
            this.ctx.fillText('·', screenX + TILE_SIZE / 2, screenY + TILE_SIZE / 2 + 2);
        });
    }

    private adjustHexOpacity(hex: string, alpha: number): string {
        if (!hex) return 'rgba(0,0,0,0)';
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
}