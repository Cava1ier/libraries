

import { RNGSystem } from '../rng/RNGSystem';

const WORLD_WIDTH = 100;
const WORLD_HEIGHT = 100;
const WORLD_DEPTH = 10;

// --- Helper Functions ---

function generateMap(rng: RNGSystem, numIslands: number, baseRadius: number, heightVariation: number) {
    const map = Array(WORLD_WIDTH).fill(0).map(() => Array(WORLD_HEIGHT).fill(0));
    for (let i = 0; i < numIslands; i++) {
        const randX = rng.nextInRange(0, WORLD_WIDTH - 1);
        const randY = rng.nextInRange(0, WORLD_HEIGHT - 1);
        const randRadius = rng.nextInRange(baseRadius, baseRadius * 2);
        const randHeight = rng.nextInRange(1, heightVariation);

        for (let x = 0; x < WORLD_WIDTH; x++) {
            for (let y = 0; y < WORLD_HEIGHT; y++) {
                const dist = Math.sqrt(Math.pow(x - randX, 2) + Math.pow(y - randY, 2));
                if (dist < randRadius) {
                    map[x][y] += Math.ceil(randHeight * (1 - dist / randRadius));
                }
            }
        }
    }
    return map;
}

function determineBiome(height: number, moisture: number): string {
    if (height < 3) return 'Ocean';
    if (height > 7) {
        if (moisture < 3) return 'RockyPeak';
        return 'SnowyPeak';
    }
    if (height > 5) return 'Mountains';
    if (moisture > 6) return 'Swamp';
    if (moisture > 4) return 'Forest';
    if (moisture < 2) return 'Desert';
    return 'Plains';
}

function getTileData(x: number, y: number, z: number, height: number, biome: string, rng: RNGSystem) {
    let type = 'air', symbol = ' ';

    if (z < height) {
        type = 'rock'; symbol = '山';
    } else if (z === height) {
        switch (biome) {
            case 'Ocean': type = 'water'; symbol = '~'; break;
            case 'Swamp': type = rng.next() % 3 === 0 ? 'ground' : 'water'; symbol = type === 'ground' ? '.' : '≈'; break;
            case 'Forest': type = rng.next() % 4 === 0 ? 'tree' : 'ground'; symbol = type === 'tree' ? '木' : '.'; break;
            case 'Desert': type = 'sand'; symbol = '…'; break;
            case 'RockyPeak': case 'Mountains': type = 'rock'; symbol = '▲'; break;
            case 'SnowyPeak': type = 'snow'; symbol = '❄'; break;
            case 'Plains': type = 'grassland'; symbol = ','; break;
            default: type = 'ground'; symbol = '.'; break;
        }
    }

    const passable = type !== 'rock' && type !== 'tree';
    return { x, y, z, type, biome, symbol, color: '', bg_color: '', passable };
}

// --- Main Worker Logic ---

self.addEventListener('message', (e) => {
    if (e.data.command === 'generate') {
        const rng = new RNGSystem(e.data.rngNumbers);

        const heightMap = generateMap(rng, 5, 15, 4);
        const moistureMap = generateMap(rng, 8, 10, 3);

        const tiles = [];

        for (let x = 0; x < WORLD_WIDTH; x++) {
            for (let y = 0; y < WORLD_HEIGHT; y++) {
                const height = heightMap[x][y];
                const moisture = moistureMap[x][y];
                const biome = determineBiome(height, moisture);

                // Generate tile stack for this coordinate
                for (let z = 0; z < WORLD_DEPTH; z++) {
                    const tileData = getTileData(x, y, z, height, biome, rng);
                    if (tileData.type !== 'air') {
                        tiles.push(tileData);
                    }
                }
            }
            const progress = Math.round(((x + 1) / WORLD_WIDTH) * 100);
            self.postMessage({ type: 'progress', progress });
        }

        self.postMessage({ type: 'complete', tiles, heightMap, rngIndex: rng.getCurrentIndex() });
    }
});
