
import { OceanScores } from '../Character.types';
import { StatCalculator } from './StatCalculator';

export class KarmicBurdenCalculator extends StatCalculator {
    public calculate(oceanScores: OceanScores): number {
        const base = 80;
        const randomRange = 11;

        const value = base - Math.floor(oceanScores.a * 0.9) + this.randomFromRange(randomRange);
        return Math.max(0, value);
    }
}
