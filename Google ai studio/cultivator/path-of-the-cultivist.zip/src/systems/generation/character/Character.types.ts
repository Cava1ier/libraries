
export interface OceanScores {
    o: number; // Openness
    c: number; // Conscientiousness
    e: number; // Extraversion
    a: number; // Agreeableness
    n: number; // Neuroticism
}

export interface Position {
    x: number;
    y: number;
    z: number;
}

export interface CharacterStats {
    cultivation_level: number;
    qi_points: number;
    max_qi_points: number;
    body_tempering: number;
    soul_strength: number;
    dao_comprehension: number;
    spiritual_roots: string;
    meridian_purity: number;
    elemental_affinity: number;
    karmic_burden: number;
    heavenly_tribulation: number;
    fate_threads: number;
    spiritual_roots_value: number;
    mental_fortitude: number;
    physical_resilience: number;
    attack: number;
    defense: number;
    speed: number;
}

export interface GeneratedCharacter extends CharacterStats, Position {
    id?: number; // Optional because it's added by the database
    name: string;
    realm: string;
    ocean_o: number;
    ocean_c: number;
    ocean_e: number;
    ocean_a: number;
    ocean_n: number;
    conflict_strength: string;
    conflict_like_1: string;
    conflict_like_2: string;
    conflict_abhor: string;
    story_archetype: string;
}