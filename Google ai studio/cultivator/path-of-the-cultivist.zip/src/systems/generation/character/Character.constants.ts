
export class CharacterConstants {
    public static readonly LITERARY_CONFLICTS = [
        'Man vs Nature', 'Man vs Man', 'Man vs Self', 'Man vs Society',
        'Man vs Technology', 'Man vs Supernatural', 'Man vs Fate'
    ] as const;

    public static readonly ELEMENTS = [
        'Fire', 'Water', 'Earth', 'Metal', 'Wood', 'Lightning', 'Ice', 'Wind'
    ] as const;
    
    public static readonly OCEAN_RANGE = { min: 15, max: 75, range: 61 };
    
    public static readonly ARCHETYPE_THRESHOLDS = { high: 55, low: 35 };
}
