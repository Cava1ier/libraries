
import { RNGService } from '../../../../services/RNGService';
import { WorldService } from '../../../../services/WorldService';
import { Position } from '../Character.types';

export class PositionService {
    constructor(private worldSystem: WorldService, private rng: RNGService) {}

    public findStartPosition(initialX: number = 128, initialY: number = 128, initialZ: number = 5): Position {
        this.worldSystem.ensureAreaIsLoaded(initialX, initialY, 2); // Ensure a larger area is ready
        
        const searchRadius = 20; // Increased search radius
        const maxAttempts = 100; // Increased attempts

        for (let i = 0; i < maxAttempts; i++) {
            const x = initialX + this.rng.nextInRange(-searchRadius, searchRadius);
            const y = initialY + this.rng.nextInRange(-searchRadius, searchRadius);
            
            // Prioritize finding a tile at the target Z-level first
            let tile = this.worldSystem.getTile(x, y, initialZ);
            if (tile && tile.canMoveTo({})) {
                return { x, y, z: tile.z };
            }

            // If not found, look downwards from the sky to find the ground
            for (let z = initialZ + 5; z >= 0; z--) {
                tile = this.worldSystem.getTile(x, y, z);
                if (tile && tile.type !== 'air' && tile.canMoveTo({})) {
                    return { x, y, z: tile.z };
                }
            }
        }
        
        console.warn("Could not find a valid starting position after 100 attempts. Defaulting to initial coordinates.");
        return { x: initialX, y: initialY, z: initialZ }; // Fallback
    }
}
