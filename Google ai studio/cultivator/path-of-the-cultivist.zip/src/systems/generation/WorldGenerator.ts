import { RNGSystem } from '../rng/RNGSystem';
import { GameDatabase } from '../database/Database';
import { OceanProfile } from '../../types/OceanTypes';

export const WORLD_WIDTH = 100;
export const WORLD_HEIGHT = 100;
export const WORLD_DEPTH = 10;

export class WorldGenerator {
 private rng: RNGSystem;
 private db: GameDatabase;

 constructor(rngSystem: RNGSystem, database: GameDatabase) {
  this.rng = rngSystem;
  this.db = database;
 }
 
 public async generateAndLoadWorld(onProgress: (progress: { stage: string, percentage: number }) => void): Promise<number[][]> {
    const tilesTable = this.db.getTable('world_tiles');
    if (tilesTable && tilesTable.findAll().length > 0) {
        onProgress({ stage: 'World found in database', percentage: 100 });
        return [];
    }

    onProgress({ stage: 'Generating world data...', percentage: 0 });

    const generatedData = await this.generateWorldData((percentage) => {
        onProgress({ stage: 'Generating world data...', percentage });
    });

    onProgress({ stage: 'Storing world in database...', percentage: 0 });
    
    const generatedTiles = generatedData.tiles;
    if (!tilesTable) {
        this.db.tables.world_tiles = new (this.db.tables.characters as any).constructor('world_tiles', ['x', 'y', 'z', 'type', 'biome', 'symbol', 'passable']);
    }

    const chunkSize = 1000;
    for (let i = 0; i < generatedTiles.length; i += chunkSize) {
        const chunk = generatedTiles.slice(i, i + chunkSize);
        await new Promise(resolve => setTimeout(() => {
            chunk.forEach(tileData => tilesTable.insert(tileData));
            const percentage = Math.round(((i + chunkSize) / generatedTiles.length) * 100);
            onProgress({ stage: 'Storing world in database...', percentage: Math.min(percentage, 100) });
            resolve(true);
        }, 0));
    }
    
    onProgress({ stage: 'World generation complete', percentage: 100 });
    return generatedData.heightMap;
 }

 private generateWorldData(onProgress: (progress: number) => void): Promise<any> {
    return new Promise((resolve, reject) => {
        const worker = new Worker(new URL('./world-generator.worker.ts', import.meta.url), { type: 'module' });

        worker.onmessage = (e) => {
            if (e.data.type === 'progress') {
                onProgress(e.data.progress);
            } else if (e.data.type === 'complete') {
                if (typeof e.data.rngIndex === 'number') {
                    this.rng.setCurrentIndex(e.data.rngIndex);
                }
                worker.terminate();
                resolve(e.data);
            }
        };

        worker.onerror = (error) => {
            console.error('World generation worker error:', error);
            worker.terminate();
            reject(error);
        };
        
        worker.postMessage({
            command: 'generate',
            rngNumbers: this.rng.getNumbers()
        });
    });
 }

 private async _recursivelyPopulate(x: number, y: number, sites: any[], creatures: any[], oceanProfile: OceanProfile, heightMap: number[][], onProgress: (progress: { stage: string; percentage: number; }) => void): Promise<void> {
    if (x >= WORLD_WIDTH) {
        return; // Base case: reached the end of the world map
    }
    
    const tilesTable = this.db.getTable('world_tiles');
    if(tilesTable) {
        const z = heightMap[x][y];
        const surfaceTileRecord = tilesTable.query((t: any) => t.x == x && t.y == y && t.z == z)[0];
        if (surfaceTileRecord && z > 0) {
            this._generateInteractiveTile(surfaceTileRecord, oceanProfile);
            this._generateSite(x, y, z, surfaceTileRecord.biome, oceanProfile, sites);
            this._generateCreatureSpawn(x, y, z, surfaceTileRecord.biome, oceanProfile, creatures);
        }
    }

    // Determine next coordinate for recursion
    let nextX = x;
    let nextY = y + 1;
    if (nextY >= WORLD_HEIGHT) {
        nextX++;
        nextY = 0;
        const percentage = Math.round(((nextX) / WORLD_WIDTH) * 100);
        onProgress({ stage: 'Populating world features...', percentage });
    }
    
    // Asynchronous recursive call to avoid stack overflow and keep UI responsive
    return new Promise(resolve => {
        setTimeout(() => {
            this._recursivelyPopulate(nextX, nextY, sites, creatures, oceanProfile, heightMap, onProgress).then(resolve);
        }, 0);
    });
 }

 public async populateFeatures(oceanProfile: OceanProfile, heightMap: number[][], onProgress: (progress: { stage: string, percentage: number }) => void) {
    onProgress({ stage: 'Populating world features...', percentage: 0 });
    
    const sites: any[] = [];
    const creatures: any[] = [];
    
    await this._recursivelyPopulate(0, 0, sites, creatures, oceanProfile, heightMap, onProgress);

    const sitesTable = this.db.getTable('world_sites');
    if (sitesTable) sites.forEach(site => sitesTable.insert(site));
    
    const creaturesTable = this.db.getTable('world_creatures');
    if (creaturesTable) creatures.forEach(creature => creaturesTable.insert(creature));

    onProgress({ stage: 'Features populated.', percentage: 100 });
 }

 private _generateInteractiveTile(tileRecord: any, oceanProfile: OceanProfile) {
    const uninteractableTypes = ['water', 'rock', 'snow', 'cliff_face'];
    if (uninteractableTypes.includes(tileRecord.type)) {
        return;
    }

    let resourceChance = 0.01; // Base 1% chance
    if (oceanProfile.c === 'H') resourceChance *= 1.5; // High Conscientiousness: more organized resources
    if (oceanProfile.o === 'H') resourceChance *= 1.3; // High Openness: find more interesting things
    if (oceanProfile.c === 'L') resourceChance *= 0.7;

    if (this.rng.next() / 1000 > resourceChance) return;

    const biome = tileRecord.biome;
    const terrainTypesTable = this.db.getTable('tblTerrainTypes');
    if (!terrainTypesTable) return;

    let newType = '';
    const roll = this.rng.next() % 100;

    if (biome.includes('Forest') || biome.includes('Plains')) {
        if (roll < 60) newType = 'herb_node';
        else if (roll < 70) newType = 'spiritwood_tree';
    } else if (biome.includes('Mountain') || biome.includes('Hills') || biome.includes('RockyPeak')) {
        if (roll < 50) newType = 'iron_vein_ore';
        else if (roll < 55) newType = 'ancient_forge'; // More common near mountains
    }

    // Rare finds, less biome-dependent
    if (roll > 98 && oceanProfile.o === 'H') { // ~2% chance for High Openness
        newType = 'healing_spring';
    } else if (roll > 99) { // 1% chance for anyone
        newType = 'shrine_center';
    }
    
    if (newType) {
        const newTileTypeRecord = terrainTypesTable.query((r: any) => r.type === newType)[0];
        if (newTileTypeRecord) {
            tileRecord.type = newTileTypeRecord.type;
            tileRecord.symbol = newTileTypeRecord.symbol;
        }
    }
 }

 private _generateSite(x: number, y: number, z: number, biome: string, oceanProfile: OceanProfile, sites: any[]) {
    let siteChance = 0.0025;
    if (oceanProfile.o === 'H') siteChance *= 1.5;
    if (oceanProfile.o === 'L') siteChance *= 0.7;
    if (oceanProfile.c === 'H') siteChance *= 1.2;
    if (oceanProfile.a === 'H') siteChance *= 0.8;
    if (oceanProfile.n === 'H') siteChance *= 1.4;

    if (this.rng.next() / 1000 > siteChance) return;

    const poiRoll = this.rng.next() % 100;
    let type = 'ancient_ruins', name = 'Forgotten Ruins', properties = JSON.stringify({ lootTable: 'ruins_common' });
    
    let hostileChance = 40;
    if (oceanProfile.a === 'H') hostileChance -= 20;
    if (oceanProfile.n === 'H') hostileChance += 20;

    if ((biome.includes('Mountain') || biome.includes('RockyPeak')) && poiRoll < hostileChance) {
        type = 'monster_lair'; name = 'Beast Lair'; properties = JSON.stringify({ creatureId: 7 });
    } else if (biome.includes('Forest') && poiRoll < 30) {
        type = 'hermit_shack'; name = 'Secluded Hermitage'; properties = JSON.stringify({ npcId: this.rng.nextInRange(2, 5) });
    } else if (biome.includes('Swamp') && poiRoll < 50) {
        type = 'sunken_temple'; name = 'Sunken Spirit Temple'; properties = JSON.stringify({ lootTable: 'temple_rare' });
    } else if (biome.includes('Plains') && oceanProfile.o === 'H' && poiRoll < 20) {
        type = 'spirit_gate'; name = 'Shimmering Spirit Gate'; properties = JSON.stringify({});
    }

    sites.push({ x, y, z, type, name, properties });
 }

 private _generateCreatureSpawn(x: number, y: number, z: number, biome: string, oceanProfile: OceanProfile, creatures: any[]) {
    let spawnChance = 0.08;
    if (oceanProfile.n === 'H') spawnChance *= 1.5;
    if (oceanProfile.a === 'H') spawnChance *= 0.6;
    if (oceanProfile.e === 'L') spawnChance *= 0.8;
    
    if (this.rng.next() / 1000 > spawnChance) return;
    
    let typeId = 3;
    if (biome.includes('Forest')) typeId = this.rng.nextInRange(0, 100) < (oceanProfile.n === 'H' ? 80 : 60) ? 2 : 4;
    else if (biome.includes('Mountain') || biome.includes('RockyPeak')) typeId = 17;
    else if (biome.includes('Plains')) typeId = this.rng.nextInRange(0, 100) < 80 ? 1 : 3;
    else if (biome.includes('Swamp')) typeId = 14;
    else if (biome.includes('Desert')) typeId = 26;
    
    creatures.push({ x, y, z, typeId });
 }
}
