



import { RNGSystem } from '../rng/RNGSystem';
import { BaseTile } from '../tiles/BaseTile';
import { TilesFactory } from '../tiles/TileFactory';
import { dCreatureSystem } from '../../data/dCreatureSystem';


// Using bitwise operations for faster coordinate calculations
export const REGION_SIZE_BITS = 5; // 2^5 = 32
export const REGION_SIZE = 1 << REGION_SIZE_BITS;
export const REGION_MASK = REGION_SIZE - 1;
export const WORLD_DEPTH = 10;

class Region {
    public tiles: Map<string, BaseTile> = new Map();
    private heightMap: number[][];
    private moistureMap: number[][];
    private creatureSystem: dCreatureSystem | null = null;

    constructor(public regionX: number, public regionY: number, rng: RNGSystem, creatureSystem: dCreatureSystem | null) {
        this.heightMap = Array(REGION_SIZE).fill(0).map(() => Array(REGION_SIZE).fill(0));
        this.moistureMap = Array(REGION_SIZE).fill(0).map(() => Array(REGION_SIZE).fill(0));
        this.creatureSystem = creatureSystem;
        this.generate(rng);
    }
    
    private generate(rng: RNGSystem) {
        // 1. Generate Heightmap
        for (let i = 0; i < 3; i++) {
            const randX = rng.nextInRange(0, REGION_SIZE - 1);
            const randY = rng.nextInRange(0, REGION_SIZE - 1);
            const randRadius = rng.nextInRange(5, 15);
            const randHeight = rng.nextInRange(1, 4);

            for (let x = 0; x < REGION_SIZE; x++) {
                for (let y = 0; y < REGION_SIZE; y++) {
                    const dist = Math.sqrt(Math.pow(x - randX, 2) + Math.pow(y - randY, 2));
                    if (dist < randRadius) {
                        this.heightMap[x][y] += Math.ceil(randHeight * (1 - dist / randRadius));
                    }
                }
            }
        }
        
        // 2. Generate Moisturemap
        for (let i = 0; i < 4; i++) {
            const randX = rng.nextInRange(0, REGION_SIZE - 1);
            const randY = rng.nextInRange(0, REGION_SIZE - 1);
            const randRadius = rng.nextInRange(10, 20);
            const randMoisture = rng.nextInRange(1, 5);
    
            for (let x = 0; x < REGION_SIZE; x++) {
                for (let y = 0; y < REGION_SIZE; y++) {
                    const dist = Math.sqrt(Math.pow(x - randX, 2) + Math.pow(y - randY, 2));
                    if (dist < randRadius) {
                        this.moistureMap[x][y] += Math.ceil(randMoisture * (1 - dist / randRadius));
                    }
                }
            }
        }

        // 3. Generate tiles based on both maps
        for (let x = 0; x < REGION_SIZE; x++) {
            for (let y = 0; y < REGION_SIZE; y++) {
                const height = this.heightMap[x][y];
                const moisture = this.moistureMap[x][y];
                for (let z = 0; z < WORLD_DEPTH; z++) {
                    const tileData = this.getTileData(x, y, z, height, moisture, rng);
                    if (tileData.type !== 'air') {
                        const tile = TilesFactory.createTile(tileData);
                        this.tiles.set(`${x},${y},${z}`, tile);
                        
                        if (this.creatureSystem && z === height && tile.canMoveTo({})) {
                           this.creatureSystem.spawnCreatureForTile(tile.x, tile.y, tile.z, tile.biome);
                        }
                    }
                }
            }
        }
        this.generatePOIs(rng);
    }

    private determineBiome(height: number, moisture: number): string {
        if (this.regionX === 4 && this.regionY === 4) {
            if (height < 3) return 'Ocean';
            if (moisture > 3) return 'Forest';
            return 'Plains';
        }

        if (height < 3) return 'Ocean';
        if (height > 7) {
            if (moisture < 3) return 'RockyPeak';
            return 'SnowyPeak';
        }
        if (height > 5) return 'Mountains';
    
        if (moisture > 6) return 'Swamp';
        if (moisture > 4) return 'Forest';
        if (moisture < 2) return 'Desert';
        
        return 'Plains';
    }

    private getTileData(localX: number, localY: number, z: number, height: number, moisture: number, rng: RNGSystem) {
        const worldX = (this.regionX << REGION_SIZE_BITS) + localX;
        const worldY = (this.regionY << REGION_SIZE_BITS) + localY;

        let type = 'air', biome = 'Sky', symbol = ' ';
        
        if (z < height) {
            type = 'rock'; biome = 'Bedrock'; symbol = '山';
        } else if (z === height) {
            biome = this.determineBiome(height, moisture);
            
            switch (biome) {
                case 'Ocean': type = 'water'; symbol = '~'; biome = 'Sunken Spirit Lake'; break;
                case 'Swamp': type = 'water'; symbol = '≈'; biome = 'Misty Swamp'; if (rng.next() % 4 < 1) type = 'ground'; break;
                case 'Forest': type = 'ground'; symbol = '.'; biome = 'Whispering Bamboo Forest'; if (rng.next() % 5 < 2) type = 'tree'; break;
                case 'Desert': type = 'sand'; symbol = '…'; biome = 'Scorched Sands'; break;
                case 'RockyPeak': case 'Mountains': type = 'rock'; symbol = '▲'; biome = 'Jade Pillar Mountains'; if (rng.next() % 10 < 3) type = 'ground'; break;
                case 'SnowyPeak': type = 'snow'; symbol = ' '; biome = 'Frozen Summit'; break;
                case 'Plains': default: type = 'ground'; symbol = '.'; biome = 'Celestial Plains'; break;
            }
            if ((type === 'ground' || type === 'rock') && biome === 'Forest' && rng.next() % 20 === 0) { type = 'herb_node'; symbol = '草'; }
            
            const isCliff = this.heightMap[localX]?.[localY-1] < height - 1;
            if(isCliff) { type = 'cliff_face'; symbol = '║'; biome = 'Cliffside'; }
        }

        return { x: worldX, y: worldY, z, type, biome, symbol };
    }
    
    private generatePOIs(rng: RNGSystem) {
        if (this.regionX === 4 && this.regionY === 4) {
             const villageX = 128, villageY = 128;
             const localX = villageX & REGION_MASK;
             const localY = villageY & REGION_MASK;
             const surfaceZ = this.heightMap[localX][localY];
             if(surfaceZ) this.creatureSystem?.spawnNpcById(1, villageX, villageY, surfaceZ);
        }
        if (rng.nextInRange(0, 10) === 0) { // Increased chance for caves
            const startX = rng.nextInRange(5, REGION_SIZE - 6);
            const startY = rng.nextInRange(5, REGION_SIZE - 6);
            const surfaceZ = this.heightMap[startX][startY];
            const surfaceTile = this.getTile(startX, startY, surfaceZ);
            if (surfaceTile && (surfaceTile.type === 'rock' || surfaceTile.type === 'ground')) {
                this.generateCave(startX, startY, surfaceZ, rng);
            }
        }
    }

    private generateCave(localX: number, localY: number, entranceZ: number, rng: RNGSystem) {
        const worldX = (this.regionX << REGION_SIZE_BITS) + localX;
        const worldY = (this.regionY << REGION_SIZE_BITS) + localY;
        
        const entranceData = { x: worldX, y: worldY, z: entranceZ, type: 'cave_entrance', biome: 'Cave Mouth', symbol: '回' };
        this.tiles.set(`${localX},${localY},${entranceZ}`, TilesFactory.createTile(entranceData));

        let currentX = localX;
        let currentY = localY;
        let currentZ = entranceZ - 1;
        
        const caveSize = rng.nextInRange(15, 40);

        for (let i = 0; i < caveSize && currentZ > 0; i++) {
            const worldCaveX = (this.regionX << REGION_SIZE_BITS) + currentX;
            const worldCaveY = (this.regionY << REGION_SIZE_BITS) + currentY;

            // Carve out a 2x2 area to make caves more spacious
            for (let dx = 0; dx <= 1; dx++) {
                for (let dy = 0; dy <= 1; dy++) {
                    const carveX = currentX + dx;
                    const carveY = currentY + dy;
                    if (carveX >= REGION_SIZE || carveY >= REGION_SIZE) continue;

                    const floorData = { 
                        x: worldCaveX + dx, y: worldCaveY + dy, z: currentZ, 
                        type: 'cave_floor', biome: 'Dank Cave', symbol: '·' 
                    };
                    this.tiles.set(`${carveX},${carveY},${currentZ}`, TilesFactory.createTile(floorData));

                    // Spawn cave creatures
                    if (this.creatureSystem) {
                        this.creatureSystem.spawnCreatureForTile(worldCaveX + dx, worldCaveY + dy, currentZ, 'Dank Cave');
                    }
                }
            }

            // Move the digger
            currentX += rng.nextInRange(-1, 1);
            currentY += rng.nextInRange(-1, 1);
            
            // Boundary checks
            currentX = Math.max(1, Math.min(REGION_SIZE - 2, currentX));
            currentY = Math.max(1, Math.min(REGION_SIZE - 2, currentY));

            if (rng.nextInRange(0, 4) === 0) { // 25% chance to dig down
                currentZ--;
            }
        }
    }

    public getTile(localX: number, localY: number, z: number): BaseTile | undefined {
        // This implementation doesn't look down through air tiles, it gets the exact tile.
        return this.tiles.get(`${localX},${localY},${z}`);
    }
}

export class WorldSystem {
    private regions: Map<string, Region> = new Map();
    private rng: RNGSystem;
    private creatureSystem: dCreatureSystem | null = null;

    constructor(rng: RNGSystem) {
        this.rng = rng;
    }
    
    public setCreatureSystem(system: dCreatureSystem) {
        this.creatureSystem = system;
    }

    public getTile(worldX: number, worldY: number, z: number): BaseTile | undefined {
        const regionX = worldX >> REGION_SIZE_BITS;
        const regionY = worldY >> REGION_SIZE_BITS;
        const localX = worldX & REGION_MASK;
        const localY = worldY & REGION_MASK;

        const region = this.loadRegion(regionX, regionY);
        return region.getTile(localX, localY, z);
    }
    
    // FIX: Added getVisibleTile method to find the topmost non-air tile at a location.
    // This is required by the map rendering and inspection logic.
    public getVisibleTile(x: number, y: number, startZ: number): BaseTile | null {
        for (let z = startZ; z >= 0; z--) {
            const tile = this.getTile(x, y, z);
            if (tile && tile.type !== 'air') {
                return tile;
            }
        }
        return null;
    }

    public ensureAreaIsLoaded(worldX: number, worldY: number, radius: number) {
        const regionX = worldX >> REGION_SIZE_BITS;
        const regionY = worldY >> REGION_SIZE_BITS;
        for(let dx = -radius; dx <= radius; dx++) {
            for(let dy = -radius; dy <= radius; dy++) {
                this.loadRegion(regionX + dx, regionY + dy);
            }
        }
    }
    
    private loadRegion(regionX: number, regionY: number): Region {
        const regionKey = `${regionX},${regionY}`;
        let region = this.regions.get(regionKey);
        if (!region) {
            region = new Region(regionX, regionY, this.rng, this.creatureSystem);
            this.regions.set(regionKey, region);
        }
        return region;
    }
}