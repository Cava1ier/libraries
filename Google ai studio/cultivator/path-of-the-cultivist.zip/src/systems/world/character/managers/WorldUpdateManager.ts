import { GameCoordinatorService } from '../../../../services/GameCoordinatorService';

export class WorldUpdateManager {
  constructor(private gameCoordinator: GameCoordinatorService) {}

  public onMovementStep = () => {
    const { character, worldService } = this.gameCoordinator;
    worldService.ensureAreaIsLoaded(character.x, character.y, 2);
    this.updateVision();
    this.gameCoordinator.mapData.followCharacter(character.data);
    this.updateAndRender();
  }

  public updateVision() {
    const { visionService, character, gameState } = this.gameCoordinator;
    const visionResult = visionService.calculateLineOfSight(character, gameState.getDiscoveredTiles());
    gameState.updateVision(visionResult);
  }

  public updateTileInfo() {
    this.gameCoordinator.mapData.updateInspectedTile(this.gameCoordinator.character.data, this.gameCoordinator.worldService);
  }

  public updateAndRender() {
    this.updateTileInfo();
    this.gameCoordinator.context.onUpdate();
  }
}
