import { Character } from '../../../../data/dCharacter';
import { GameWorldDependencies, GameWorldCallbacks } from '../CharacterWorld.types';

export class SaveLoadManager {
  constructor(
    private character: Character,
    private dependencies: GameWorldDependencies,
    private callbacks: GameWorldCallbacks,
    private discoveredTiles: Set<string>
  ) {}

  public saveGame() {
    this.callbacks.addEvent('Saving game...', '');

    const saveData = this.prepareSaveData();
    const success = this.dependencies.saveSystem.saveGame(saveData, 1);

    this.callbacks.addEvent(
      success ? 'Game saved successfully.' : 'Save failed.',
      success ? 'Your progress is secure.' : 'Could not save your progress.'
    );
    this.callbacks.forceUpdate();
  }

  private prepareSaveData() {
    const factions = this.dependencies.factionSystem.getAllFactions();
    const serializableFactions = factions.map((f: any) => ({
      ...f,
      relationships: Array.from(f.relationships.entries()),
    }));

    const creatures = this.dependencies.creatureSystem.creatures;
    const serializableCreatures = Array.from(creatures.values());

    return {
      characterData: this.character.data,
      discoveredTiles: Array.from(this.discoveredTiles),
      inventory: this.dependencies.inventorySystem.getItems(),
      quests: this.dependencies.questSystem.getActiveQuests(),
      time: this.dependencies.weatherSystem.getTime(),
      factions: serializableFactions,
      creatures: serializableCreatures,
    };
  }
}