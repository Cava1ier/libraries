
import { CombatEncounter, DialogueState, QuestData } from '../../../types/AdventureTypes';
import { WorldService } from '../../../services/WorldService';

export type PlayerState = 'idle' | 'cultivating' | 'moving' | 'exploring' | 'combat' | 'dialogue' | 'meditating';
export type InteractionMode = 'move' | 'look';

export interface GameWorldDependencies {
  worldSystem: WorldService;
  pathfindingSystem: any;
  creatureSystem: any;
  combatSystem: any;
  dialogueSystem: any;
  inventorySystem: any;
  questSystem: any;
  database: any;
  saveSystem: any;
  rng: any;
  fullGameState: any;
  weatherSystem: any;
  skillSystem: any;
  factionSystem: any;
}

export interface GameWorldCallbacks {
  addEvent: (description: string, consequence: string) => void;
  onCombatStart: (encounter: CombatEncounter | null) => void;
  onDialogueStart: (dialogue: DialogueState) => void;
  onQuestComplete: (quest: QuestData) => void;
  onLevelUp?: () => void;
  onCraftingStart?: () => void;
  forceUpdate: () => void;
}