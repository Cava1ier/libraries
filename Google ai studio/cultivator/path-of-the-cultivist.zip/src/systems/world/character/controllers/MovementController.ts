import { GameCoordinatorService } from '../../../../services/GameCoordinatorService';
import { PathfindingResult, MovementValidationResult } from '../../../movement/MovementTypes';

export class MovementController {
  constructor(private gameCoordinator: GameCoordinatorService) {}

  public handleMapClick(worldX: number, worldY: number) {
    if (this.gameCoordinator.playerState !== 'idle') return;

    const pathResult = this.gameCoordinator.movementService.findPathTo(
      { x: this.gameCoordinator.character.x, y: this.gameCoordinator.character.y, z: this.gameCoordinator.character.z },
      { x: worldX, y: worldY, z: this.gameCoordinator.character.z }
    );

    if (pathResult.success && pathResult.path.length > 1) {
      this.gameCoordinator.gameState.setCurrentPath(pathResult.path);
      this.startMovementAnimation();
    } else {
      this.gameCoordinator.eventService.addEvent('system', 'Cannot move there.', pathResult.reason || 'No valid path.');
    }
    this.gameCoordinator.updateAndRender();
  }

  public async handleDirectionalMovement(movement: { dx: number; dy: number }) {
    if (this.gameCoordinator.playerState !== 'idle') return;
    const { character, movementService } = this.gameCoordinator;
    const targetPos = { x: character.x + movement.dx, y: character.y + movement.dy, z: character.z };

    const result = await movementService.moveTo(character, targetPos);
    if (result.success) {
      this.gameCoordinator.worldUpdateManager.onMovementStep();
    } else {
      this.handleMovementBlock(result);
    }
    this.gameCoordinator.updateAndRender();
  }

  public stopMovement() {
    this.gameCoordinator.movementService.stopMovement();
    if (this.gameCoordinator.playerState === 'moving' || this.gameCoordinator.playerState === 'exploring') {
      this.gameCoordinator.gameState.setPlayerState('idle');
    }
    this.gameCoordinator.updateAndRender();
  }
  
  // FIX: Added canMove method to check player state before initiating movement.
  public canMove(): boolean {
    const state = this.gameCoordinator.gameState.getPlayerState();
    return state === 'idle' || state === 'exploring';
  }

  private async startMovementAnimation() {
    const { gameState, movementService, character, eventService } = this.gameCoordinator;
    const path = gameState.getCurrentPath();
    if (!path || path.length <= 1) return;

    gameState.setPlayerState('moving');
    eventService.addEvent('system', 'You begin your journey.', `Moving to (${path[path.length - 1].x}, ${path[path.length - 1].y}).`);

    const result = await movementService.followPath(character, path.slice(1));
    if (result.success) {
      eventService.addEvent('system', 'You have arrived.', '');
    } else {
      this.handleMovementBlock(result);
    }

    if (gameState.getPlayerState() !== 'combat' && gameState.getPlayerState() !== 'dialogue') {
      gameState.setPlayerState('idle');
    }
    this.gameCoordinator.worldUpdateManager.updateVision();
  }
  
  private handleMovementBlock(result: MovementValidationResult) {
    const { gameState, context, combatService, dialogueService, eventService } = this.gameCoordinator;
    if (result.blockedBy === 'creature' && result.encounter) {
      if (result.encounter.isHostile) {
        gameState.setPlayerState('combat');
        const encounter = combatService.startCombat(this.gameCoordinator.character.data, result.encounter);
        context.onCombatStart(encounter);
        eventService.addEvent('combat', `You are attacked by a ${result.encounter.name}!`, "Prepare for battle!");
      } else {
        gameState.setPlayerState('dialogue');
        result.encounter.passthroughTimestamp = Date.now();
        const dialogue = dialogueService.getDialogue(result.encounter);
        context.onDialogueStart(dialogue);
      }
    } else {
      eventService.addEvent('system', "Movement interrupted.", result.reason || "Something blocked your path.");
    }
  }
}