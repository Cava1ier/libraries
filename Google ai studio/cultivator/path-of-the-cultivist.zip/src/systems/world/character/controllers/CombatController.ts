import { GameCoordinatorService } from '../../../../services/GameCoordinatorService';

export class CombatController {
  constructor(private gameCoordinator: GameCoordinatorService) {}

  public handleCombatAction(action: { type: string; id?: any }) {
    const combatSystem = this.gameCoordinator.combatService;
    if (!combatSystem.currentCombat?.isActive) return;

    combatSystem.handlePlayerAction(action);
    
    this.gameCoordinator.updateAndRender();

    if (!combatSystem.currentCombat?.isActive) {
      const combatLog = combatSystem.currentCombat?.log.join(' ').toLowerCase() || '';
      const playerWon = combatLog.includes('defeated!');
      const playerFled = combatLog.includes('fled');
      
      if (playerWon && !playerFled) {
        const creature = combatSystem.currentCombat!.participants.find((p: any) => !p.isPlayer)!.entity;
        const creatureRecord = this.gameCoordinator.db.getTable('tblCreatureTypes').find(creature.typeId);
        
        if (creatureRecord?.xp_reward) {
            const result = this.gameCoordinator.character.addExperience(creatureRecord.xp_reward);
            this.gameCoordinator.eventService.addEvent('system', `You gained ${creatureRecord.xp_reward} experience.`, '');
            if (result.leveledUp && result.newLevel) {
                this.gameCoordinator.eventService.addEvent('system', `You have reached Cultivation Level ${result.newLevel}!`, 'You have attribute points to spend.');
                this.gameCoordinator.context.onLevelUp();
            }
        }
        this.gameCoordinator.questService.updateProgress('HUNT', creature.name, 1);
        this.gameCoordinator.creatureService.removeCreature(creature);
      } else if (!playerWon && !playerFled) {
        // Player was defeated
        this.gameCoordinator.handlePlayerDefeat();
      }
      
      this.gameCoordinator.gameState.setPlayerState('idle');
      this.gameCoordinator.context.onCombatStart(null);
    }
  }
}