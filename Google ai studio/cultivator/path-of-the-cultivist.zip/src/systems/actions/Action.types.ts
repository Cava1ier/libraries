


import type { Character } from '../../data/dCharacter';
// FIX: Use `import type` to break a circular dependency between Action types and the main game world class, which can resolve complex type inference issues.
// FIX: Changed dCharacterGameWorld to GameCoordinatorService to align with the new architecture.
import type { GameCoordinatorService } from '../../data/dCharacterGameWorld';
import type { GameWorldDependencies, PlayerState } from '../world/character/CharacterWorld.types';

export interface ActionContext {
  character: Character;
  dependencies: GameWorldDependencies;
  // FIX: Changed dCharacterGameWorld to GameCoordinatorService.
  gameWorld: GameCoordinatorService;
}

export interface ActionResult {
  success: boolean;
  message: string;
  console?: string;
}

export interface ActionDefinition {
  id: string;
  duration?: number;
  playerState?: PlayerState;
  startMessage: string;
  startConsole: string;
  execute: (context: ActionContext) => ActionResult;
}