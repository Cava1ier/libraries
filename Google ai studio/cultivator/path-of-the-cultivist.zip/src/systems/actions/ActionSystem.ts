import { ActionRegistry } from './ActionRegistry';
import { ActionContext } from './Action.types';
import { GameStateService } from '../world/character/managers/GameStateManager';
import { GameWorldCallbacks } from '../world/character/CharacterWorld.types';

export class ActionSystem {
    private currentActionTimeoutId: number | null = null;

    constructor(
        private stateManager: GameStateService,
        private callbacks: GameWorldCallbacks
    ) {}

    public executeAction(actionId: string, context: ActionContext) {
        const action = ActionRegistry.get(actionId);
        if (!action) {
            console.warn(`Action "${actionId}" not found.`);
            return;
        }

        if (action.duration && action.playerState) {
            this.stateManager.setPlayerState(action.playerState);
            this.stateManager.setActionProgress({ startTime: Date.now(), duration: action.duration, actionId });
            this.callbacks.addEvent(action.startMessage, action.startConsole);
            this.callbacks.forceUpdate();

            this.currentActionTimeoutId = window.setTimeout(() => {
                if (this.stateManager.playerState !== action.playerState) return; // Action was cancelled
                const result = action.execute(context);
                this.stateManager.setPlayerState('idle');
                this.callbacks.addEvent(result.message, result.console || "");
                this.callbacks.forceUpdate();
                this.currentActionTimeoutId = null;
            }, action.duration);
        } else {
            const result = action.execute(context);
            if(result.message) this.callbacks.addEvent(result.message, result.console || "");
            this.callbacks.forceUpdate();
        }
    }

    public cancelCurrentAction() {
        if (this.currentActionTimeoutId) {
            clearTimeout(this.currentActionTimeoutId);
            this.currentActionTimeoutId = null;
            this.stateManager.setPlayerState('idle');
            this.callbacks.addEvent('Action cancelled.', '');
            this.callbacks.forceUpdate();
        }
    }
}