import { ActionDefinition, ActionContext, ActionResult } from './Action.types';
import { TileConfigRegistry } from '../tiles/TileConfigRegistry';
import { dSkillSystem } from '../../data/dSkillSystem';
import { SkillType, CriticalType } from '../../types/AdventureTypes';

export class ActionRegistry {
  private static actions = new Map<string, ActionDefinition>();

  static register(action: ActionDefinition) {
    this.actions.set(action.id, action);
  }

  static get(id: string): ActionDefinition | undefined {
    return this.actions.get(id);
  }

  static initialize() {
    this.register({
      id: 'cultivate',
      duration: 5000, // This could be loaded from ConfigurationManager
      playerState: 'cultivating',
      startMessage: 'You begin to cultivate...',
      startConsole: 'This will take some time.',
      execute: (context) => this.executeCultivation(context)
    });

    this.register({
      id: 'meditate',
      duration: 2000, // This could be loaded from ConfigurationManager
      playerState: 'meditating',
      startMessage: 'You sit and meditate...',
      startConsole: 'You focus on the surrounding Qi.',
      execute: (context) => this.executeMeditation(context)
    });

    this.register({
      id: 'gather',
      duration: 3000,
      playerState: 'meditating', // Visually re-using 'meditating' as a generic 'busy' state
      startMessage: 'You search the area for useful herbs...',
      startConsole: 'Your knowledge of Herbalism is put to the test.',
      execute: (context) => this.executeGather(context)
    });

    this.register({
        id: 'explore',
        startMessage: '', startConsole: '',
        execute: (context) => {
          // FIX: Property 'autoExplore' does not exist on type 'GameCoordinatorService'. Use the explorationController instead.
          context.gameWorld.explorationController.toggleAutoExplore();
          return { success: true, message: '' };
        }
    });

    this.register({
        id: 'craft',
        startMessage: 'You approach the forge...', startConsole: '',
        execute: (context) => {
          context.gameWorld.openCraftingModal();
          return { success: true, message: '' };
        }
    });
  
    this.register({
        id: 'save',
        startMessage: '', startConsole: '',
        execute: (context) => {
          context.gameWorld.saveGame();
          return { success: true, message: '' };
        }
    });
  }

  private static executeCultivation(context: ActionContext): ActionResult {
    const { character } = context;
    const daoBonus = 1 + (character.dao_comprehension / 100);
    const qiGained = Math.round(50 * daoBonus);
    character.qi_points = Math.min(1000, character.qi_points + qiGained); // Use a limit
    
    return {
      success: true,
      message: `Cultivation complete. You gained ${qiGained} Qi.`
    };
  }

  private static executeMeditation(context: ActionContext): ActionResult {
    const { character, dependencies } = context;
    const currentTile = dependencies.worldSystem.getTile(character.x, character.y, character.z);
    const qiConcentration = TileConfigRegistry.get(currentTile?.type || 'ground')?.properties?.qi_concentration || 0.1;
    const qiGained = Math.round(15 + qiConcentration * 50);
    character.qi_points = Math.min(1000, character.qi_points + qiGained); // Use a limit
    
    return {
      success: true,
      message: `Meditation complete. You gained ${qiGained} Qi.`
    };
  }
  
  private static executeGather(context: ActionContext): ActionResult {
    const { dependencies } = context;
    const skillSystem = dependencies.skillSystem as dSkillSystem;
    const inventorySystem = dependencies.inventorySystem;
    const database = dependencies.database;

    const difficulty = 12; // Base difficulty for a generic gather
    const skillCheck = skillSystem.performSkillCheck(SkillType.Herbalism, difficulty);

    // Always gain some experience for trying
    const expGained = skillCheck.succeeded ? 10 : 3;
    skillSystem.gainExperience(SkillType.Herbalism, expGained, difficulty);

    if (skillCheck.succeeded) {
      const herbRecord = database.getTable('tblItems').find(1); // Sunpetal Herb
      let quantity = 1;
      let message = `Success! You found a Sunpetal Herb.`;

      if (skillCheck.criticalType === CriticalType.Success) {
        quantity = 3;
        message = `Critical Success! With exceptional skill, you found a bundle of 3 Sunpetal Herbs!`;
      }
      
      if (herbRecord) {
        inventorySystem.addItem(herbRecord.id, quantity, 2); // Common quality
      }

      return {
        success: true,
        message: message,
        console: `(Herbalism check: ${skillCheck.total} vs DC ${difficulty})`
      };
    } else {
      let message = `You failed to find any useful herbs.`;
      if (skillCheck.criticalType === CriticalType.Failure) {
        message = `Critical Failure! You mistook a thorny vine for a herb and pricked your finger.`;
      }
      return {
        success: false,
        message: message,
        console: `(Herbalism check: ${skillCheck.total} vs DC ${difficulty})`
      };
    }
  }
}