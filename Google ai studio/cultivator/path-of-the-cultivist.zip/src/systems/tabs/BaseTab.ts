import React from 'react';
import { GameWorldData } from '../../components/GameWorld/dataGameWorld';
import { PluginManager } from '../../systems/plugin/PluginSystem';

// Properties passed to each tab's render method to give it context.
export interface TabRenderProps {
    cls: (className: string) => string;
    data: GameWorldData;
    pluginManager: PluginManager;
}

export abstract class BaseTab {
    public readonly id: string;
    public readonly label: string;
    public styles: Record<string, string | null>;

    constructor(id: string, label: string) {
        this.id = id;
        this.label = label;
        this.styles = {};
    }

    public setStyle(propName: string, propValue: string | null): void {
        this.styles[propName] = propValue;
    }

    public setStyles(styles: Array<[string, string | null]>): void {
        styles.forEach(([propName, propValue]) => {
            this.setStyle(propName, propValue);
        });
    }

    // Each concrete tab class must implement its own render logic.
    abstract render(props: TabRenderProps): React.ReactNode;
}