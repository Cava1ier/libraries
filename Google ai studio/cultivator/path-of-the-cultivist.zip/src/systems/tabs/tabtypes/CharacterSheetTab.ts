import React from 'react';
import { BaseTab, TabRenderProps } from '../BaseTab';

export class CharacterSheetTab extends BaseTab {
    constructor() {
        super('status', 'Status');
    }

    render(props: TabRenderProps): React.ReactNode {
        const { cls, data } = props;
        // FIX: Access character, mapData, and playerState directly from the data object.
        const { character, mapData, playerState } = data;
        
        const cultivationStatus = playerState === 'cultivating' 
            ? React.createElement('p', { className: cls('stat-text'), style: {color: '#40E0D0'} }, `Status: Cultivating...`) 
            : null;

        return React.createElement('div', { className: cls('panel-scrollable') },
            React.createElement('h3', { className: cls('panel-title') }, 'Cultivator Status'),
            cultivationStatus,
            React.createElement('p', { className: cls('stat-text') }, `Name: ${character.name}`),
            React.createElement('p', { className: cls('stat-text') }, `Realm: ${character.realm}`),
            React.createElement('p', { className: cls('stat-text') }, `Position: (X: ${character.x}, Y: ${character.y}, Z: ${character.z})`),
            React.createElement('p', { className: cls('stat-text') }, `View Z: ${mapData.viewZ}`),
            React.createElement('p', { className: cls('stat-text') }, `Qi Points: ${character.qi_points}/1000`),
            React.createElement('p', { className: cls('stat-text') }, `Body Tempering: ${character.body_tempering}/100`),
            React.createElement('p', { className: cls('stat-text') }, `Soul Strength: ${character.soul_strength}/100`),
        );
    }
}