

import React from 'react';
import { BaseTab, TabRenderProps } from '../BaseTab';

export class ActionsTab extends BaseTab {
    constructor() {
        super('actions', 'Actions');
    }

    render(props: TabRenderProps): React.ReactNode {
        const { cls, data, pluginManager } = props;
        const isCultivating = data.playerState === 'cultivating';

        return React.createElement('div', { className: cls('panel-scrollable') },
            React.createElement('h3', { className: cls('panel-title') }, 'Actions'),
            React.createElement('p', { className: cls('stat-text'), style:{textAlign: 'center'} }, 'Use Arrow Keys or WASD to Move'),
            React.createElement('p', { className: cls('stat-text'), style:{textAlign: 'center'} }, 'Use Q, E, Z, C for Diagonals'),
            React.createElement('p', { className: cls('stat-text'), style:{textAlign: 'center'} }, 'Use Shift + < or > to Change View Z-Level'),
            React.createElement('p', { className: cls('stat-text'), style:{textAlign: 'center'} }, 'Press "l" to Toggle Look Mode'),
            React.createElement('button', { 
                className: cls('action-button'), 
                // FIX: 'performAction' is a method on the 'gameCoordinator' object within 'data'.
                onClick: () => data.gameCoordinator.performAction('cultivate'),
                disabled: isCultivating,
                style: { opacity: isCultivating ? 0.5 : 1, cursor: isCultivating ? 'not-allowed' : 'pointer' }
            }, 'Cultivate Qi'),
            // FIX: 'performAction' is a method on the 'gameCoordinator' object within 'data'.
            React.createElement('button', { className: cls('action-button'), onClick: () => data.gameCoordinator.performAction('explore') }, 'Observe Area'),
            React.createElement('button', { style: { marginTop: '2rem', borderColor: '#888' }, className: cls('action-button'), onClick: () => pluginManager.loadPage('menu') }, 'Return to Menu')
        );
    }
}