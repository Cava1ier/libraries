import React from 'react';
import { BaseTab, TabRenderProps } from '../BaseTab';

export class EventsTab extends BaseTab {
    constructor() {
        super('events', 'Events');
    }

    render(props: TabRenderProps): React.ReactNode {
        const { cls, data } = props;
        const { worldEvents } = data;

        return React.createElement('div', { className: cls('event-log') + ' ' + cls('panel-scrollable') },
            worldEvents.map((event, index) =>
                React.createElement('div', { key: index, className: cls('event-item') },
                    React.createElement('p', { className: cls('event-desc') }, `[${event.timestamp}] ${event.description}`),
                    React.createElement('small', { className: cls('event-consequence') }, event.consequences)
                )
            )
        );
    }
}