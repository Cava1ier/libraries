
import { dSkillSystem } from '../../data/dSkillSystem';

export interface ActionContext {
    skillSystem: dSkillSystem;
}

export interface TileData {
    x: number;
    y: number;
    z: number;
    type: string;
    biome: string;
    symbol: string;
    passable?: boolean;
}

export interface MoveResult {
    success: boolean;
    newPosition?: { x: number; y: number; z: number };
    characterUpdates?: Record<string, any>;
    event?: string;
    consequence?: string;
    inventoryAdd?: { itemName: string; quantity: number };
}

export abstract class BaseTile {
    public readonly x: number;
    public readonly y: number;
    public readonly z: number;
    public readonly type: string;
    public readonly biome: string;
    public readonly symbol: string;

    constructor(data: TileData) {
        this.x = data.x;
        this.y = data.y;
        this.z = data.z;
        this.type = data.type;
        this.biome = data.biome;
        this.symbol = data.symbol;
    }
    
    public get id(): string {
        return `${this.x},${this.y},${this.z}`;
    }

    abstract canMoveTo(character: any, context?: ActionContext): boolean;
    abstract onEnter(character: any, context?: ActionContext): MoveResult;
}
