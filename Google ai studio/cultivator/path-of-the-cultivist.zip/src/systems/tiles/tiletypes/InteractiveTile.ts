
import { BaseTile, MoveResult, TileData, ActionContext } from '../BaseTile';
import { SkillType, CriticalType } from '../../../types/AdventureTypes';

interface SkillCheckConfig {
    type: 'skill_check_gather';
    skill: SkillType;
    difficulty: number;
    rewards: {
        criticalSuccess: { itemName: string; quantity: number };
        success: { itemName: string; quantity: number };
        failure: { message: string };
    };
}

// The interaction property can be a function or a config object
type InteractionProperty = ((character: any, context?: ActionContext) => MoveResult) | SkillCheckConfig;

interface InteractiveTileData extends TileData {
    interaction: InteractionProperty;
}

export class InteractiveTile extends BaseTile {
    private interaction: InteractionProperty;

    constructor(data: InteractiveTileData) {
        super(data);
        this.interaction = data.interaction;
    }
    
    canMoveTo(character: any, context?: ActionContext): boolean {
        return true;
    }

    onEnter(character: any, context?: ActionContext): MoveResult {
        if (typeof this.interaction === 'function') {
            // Function-based interactions define their own outcomes, including movement.
            return this.interaction(character, context);
        }
        
        // Handle data-driven interaction configs
        if (this.interaction.type === 'skill_check_gather' && context?.skillSystem) {
            const config = this.interaction;
            const skillCheck = context.skillSystem.performSkillCheck(config.skill, config.difficulty);
            
            if (skillCheck.criticalType === CriticalType.Success) {
                // If gathering is successful, the move is successful.
                return { success: true, event: `Critical Success! You gathered extra resources.`, inventoryAdd: config.rewards.criticalSuccess };
            } else if (skillCheck.succeeded) {
                return { success: true, event: `Success! You gathered resources.`, inventoryAdd: config.rewards.success };
            } else {
                // If gathering fails, the move is unsuccessful. The character should not move onto the node.
                return { success: false, event: 'Gathering Failed.', consequence: config.rewards.failure.message };
            }
        }
        
        // Default success for interactions that don't have explicit failure states, allows movement.
        return { success: true };
    }
}
