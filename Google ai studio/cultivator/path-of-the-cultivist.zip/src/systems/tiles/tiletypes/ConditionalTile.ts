
import { BaseTile, MoveResult, TileData, ActionContext } from '../BaseTile';

interface ConditionalTileData extends TileData {
    condition: (character: any, context?: ActionContext) => boolean;
    passableWhenTrue: boolean;
    failMessage: { event: string, consequence: string };
}

export class ConditionalTile extends BaseTile {
    private condition: (character: any, context?: ActionContext) => boolean;
    private passableWhenTrue: boolean;
    private failMessage: { event: string, consequence: string };

    constructor(data: ConditionalTileData) {
        super(data);
        this.condition = data.condition;
        this.passableWhenTrue = data.passableWhenTrue;
        this.failMessage = data.failMessage || { event: "Blocked", consequence: "You cannot pass." };
    }
    
    canMoveTo(character: any, context?: ActionContext): boolean {
        const conditionMet = this.condition(character, context);
        return this.passableWhenTrue ? conditionMet : !conditionMet;
    }

    onEnter(character: any, context?: ActionContext): MoveResult {
        if (this.canMoveTo(character, context)) {
            return {
                success: true,
                newPosition: { x: this.x, y: this.y, z: this.z }
            };
        } else {
            return {
                success: false,
                ...this.failMessage
            };
        }
    }
}
