
import { BaseTile, MoveResult, TileData, ActionContext } from '../BaseTile';

// The data for this tile must include its functional property, elevationChange.
interface ElevationChangeTileData extends TileData {
    elevationChange: number;
}

export class ElevationChangeTile extends BaseTile {
    private elevationChange: number;

    constructor(data: ElevationChangeTileData) {
        super(data);
        // The elevationChange property is required for this tile's logic and is
        // supplied by the TileFactory from the TileConfigRegistry.
        this.elevationChange = data.elevationChange;
    }
    
    canMoveTo(character: any, context?: ActionContext): boolean {
        // Can only move onto a slope from the same z-level.
        return character.z === this.z;
    }

    onEnter(character: any, context?: ActionContext): MoveResult {
        if (!this.canMoveTo(character)) {
            return { success: false, event: "You can't reach the slope from here.", consequence: "Your elevation is different." };
        }
        
        const newZ = this.z + this.elevationChange;
        const action = this.elevationChange > 0 ? 'ascend' : 'descend';
        
        return {
            success: true,
            newPosition: { x: this.x, y: this.y, z: newZ },
            event: `You ${action} the ${this.type.replace('_', ' ')}.`,
            consequence: `Moved to elevation ${newZ}.`
        };
    }
}
