
import { BaseTile, MoveResult, TileData, ActionContext } from '../BaseTile';

export class StandardTile extends BaseTile {
    constructor(data: TileData) {
        super(data);
    }
    
    canMoveTo(character: any, context?: ActionContext): boolean {
        return true;
    }

    onEnter(character: any, context?: ActionContext): MoveResult {
        return {
            success: true,
            newPosition: { x: this.x, y: this.y, z: this.z }
        };
    }
}
