

import { MoveResult } from './BaseTile';
import { DatabaseService } from '../../services/DatabaseService';
import { SkillType, CriticalType } from '../../types/AdventureTypes';

export interface TileConfig {
    type: string;
    symbol: string;
    tileClass: 'standard' | 'blocking' | 'elevation' | 'interactive' | 'conditional';
    properties?: Record<string, any>;
    styleValues: (string | null)[];
}

export class TileConfigRegistry {
    private static configs = new Map<string, TileConfig>();

    public static register(config: TileConfig) {
        this.configs.set(config.type, config);
    }

    public static get(type: string): TileConfig | undefined {
        return this.configs.get(type);
    }
    
    public static getAllConfigs(): Map<string, TileConfig> {
        return new Map(this.configs);
    }

    public static initializeDefaultConfigs(database: DatabaseService) {
        const nl = null;
        const terrainTable = database.getTable('tblTerrainTypes');
        
        if (!terrainTable) {
            console.error("Critical: tblTerrainTypes not found in database. Cannot initialize tile symbols.");
            return;
        }
        
        const getSymbol = (type: string, fallback: string): string => {
            const record = terrainTable.query((r: any) => r.type === type)[0];
            return record ? record.symbol : fallback;
        };

        const baseInteractions: Record<string, any> = {
            'cave_entrance': { interaction: (character: any): MoveResult => ({ success: true, event: "You found a mysterious cave.", consequence: "A cool, damp air flows from within." }) },
            'dungeon_entrance': { interaction: (character: any): MoveResult => ({ success: true, event: "You discover a dark cave entrance.", consequence: "A sense of danger emanates from within." }) },
            'dragon_lair': { 
                interaction: (character: any): MoveResult => ({ 
                    success: false, 
                    event: "You feel an ancient, powerful aura that repels you.", 
                    consequence: "Your cultivation is far too weak to approach." 
                }) 
            },
            'herb_node': { 
                interaction: {
                    type: 'skill_check_gather',
                    skill: SkillType.Herbalism,
                    difficulty: 10,
                    rewards: {
                        criticalSuccess: { itemName: 'Sunpetal Herb', quantity: 3 },
                        success: { itemName: 'Sunpetal Herb', quantity: 1 },
                        failure: { message: "You fumbled and couldn't gather the herb." }
                    }
                }
            },
            'spiritwood_tree': {
                interaction: {
                    type: 'skill_check_gather',
                    skill: SkillType.Herbalism, // Using Herbalism for general foraging
                    difficulty: 12,
                    rewards: {
                        criticalSuccess: { itemName: 'Spiritwood Log', quantity: 3 },
                        success: { itemName: 'Spiritwood Log', quantity: 1 },
                        failure: { message: "The wood is too tough to harvest." }
                    }
                }
            },
            'iron_vein_ore': {
                interaction: {
                    type: 'skill_check_gather',
                    skill: SkillType.Climbing, // Placeholder for a 'Mining' skill, using a physical skill
                    difficulty: 14,
                    rewards: {
                        criticalSuccess: { itemName: 'Iron Ore', quantity: 3 },
                        success: { itemName: 'Iron Ore', quantity: 1 },
                        failure: { message: "You lack the strength to break the rock." }
                    }
                }
            },
            'healing_spring': {
                interaction: (character: any): MoveResult => {
                    const healAmount = 50;
                    const newQi = Math.min(1000, (character.qi_points || 0) + healAmount);
                    return {
                        success: true,
                        characterUpdates: { qi_points: newQi },
                        event: "You step into a shimmering spring.",
                        consequence: `The water's pure Qi heals you for ${healAmount} points.`
                    };
                }
            },
            'spirit_gate': {
                condition: (character: any): boolean => (character.dao_comprehension || 0) >= 50,
                passableWhenTrue: true,
                failMessage: {
                    event: "A shimmering barrier blocks you.",
                    consequence: "Your Dao Comprehension is not high enough to pass."
                }
            }
        };

        terrainTable.findAll().forEach((record: any) => {
            const properties = {
                qi_concentration: record.qi_concentration,
                movementCost: record.movementCost,
                climbable: record.climbable === 'true' || record.climbable === 1,
                climbDifficulty: record.climbDifficulty,
                ...baseInteractions[record.type]
            };
            
            this.register({
                type: record.type,
                symbol: record.symbol,
                tileClass: record.tileClass,
                properties: properties,
                styleValues: [record.color || nl, record.bg_color || nl, record.animation === 'null' ? nl : record.animation]
            });
        });
    }
}