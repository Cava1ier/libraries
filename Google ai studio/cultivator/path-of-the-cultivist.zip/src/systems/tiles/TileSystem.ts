import { BaseTile, MoveResult } from './BaseTile';
import { TilesFactory } from './TileFactory';
import { GameDatabase } from '../database/Database';

export class TileSystem {
    private tiles: Map<string, BaseTile> = new Map();
    private visibilityCache: Map<string, BaseTile | null> = new Map();

    public async loadTilesFromDB(database: GameDatabase, onProgress: (percentage: number) => void): Promise<void> {
        this.tiles.clear();
        this.visibilityCache.clear();
        const tileRecords = database.getTable('world_tiles').findAll();
        const totalTiles = tileRecords.length;
        if (totalTiles === 0) {
            onProgress(100);
            return;
        }

        const chunkSize = 2000;
        for (let i = 0; i < totalTiles; i += chunkSize) {
            const chunk = tileRecords.slice(i, i + chunkSize);
            for (const record of chunk) {
                const tile = TilesFactory.createTile(record);
                this.tiles.set(tile.id, tile);
            }

            const percentage = Math.round(((i + chunkSize) / totalTiles) * 100);
            onProgress(Math.min(percentage, 100));
            await new Promise(resolve => setTimeout(resolve, 0));
        }
    }
    
    public getTile(x: number, y: number, z: number): BaseTile | undefined {
        return this.tiles.get(`${x},${y},${z}`);
    }

    public getVisibleTile(x: number, y: number, startZ: number): BaseTile | null {
        const cacheKey = `${x},${y},${startZ}`;
        if (this.visibilityCache.has(cacheKey)) {
            return this.visibilityCache.get(cacheKey)!;
        }

        for (let z = startZ; z >= 0; z--) {
            const tile = this.getTile(x, y, z);
            if (tile && tile.type !== 'air') {
                this.visibilityCache.set(cacheKey, tile);
                return tile;
            }
        }
        
        this.visibilityCache.set(cacheKey, null);
        return null;
    }
    
    public handleMove(character: any, targetX: number, targetY: number): MoveResult {
        const targetTile = this.getVisibleTile(targetX, targetY, character.z);
        
        if (!targetTile) {
            return { success: false, event: "You see only empty sky.", consequence: "You cannot move there." };
        }
        
        // A player cannot "cut corners" around impassable tiles.
        // This checks adjacent tiles for passability before allowing a diagonal move.
        const dx = targetX - character.x;
        const dy = targetY - character.y;
        if (Math.abs(dx) === 1 && Math.abs(dy) === 1) {
            const cardinalTileX = this.getVisibleTile(character.x + dx, character.y, character.z);
            const cardinalTileY = this.getVisibleTile(character.x, character.y + dy, character.z);
            
            if ((cardinalTileX && !cardinalTileX.canMoveTo(character)) || (cardinalTileY && !cardinalTileY.canMoveTo(character))) {
                return { success: false, event: "Path blocked.", consequence: "You cannot move diagonally past the obstacle." };
            }
        }

        // After validating general movement rules, let the target tile handle the specific interaction.
        // This allows tiles to have unique onEnter behaviors (e.g., elevation changes, traps, events).
        return targetTile.onEnter(character);
    }
}