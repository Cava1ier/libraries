

import { Character } from '../../data/dCharacter';
// FIX: Replaced `WorldSystem` with `WorldService` to align with the application's service-oriented architecture.
import { WorldService } from '../../services/WorldService';
import { LineOfSightCalculator } from './LineOfSightCalculator';

export class VisionSystem {
  constructor(
    private character: Character,
    private worldSystem: WorldService
  ) {}

  public calculateLineOfSight(
    discoveredTiles: Set<string>
  ): { lineOfSight: Set<string>; discovered: Set<string> } {
    const result = LineOfSightCalculator.calculate(this.character, this.worldSystem);
    result.discovered.forEach(tileKey => discoveredTiles.add(tileKey));
    return { lineOfSight: result.lineOfSight, discovered: discoveredTiles };
  }
}