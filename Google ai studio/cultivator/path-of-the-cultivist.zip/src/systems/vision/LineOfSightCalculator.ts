

import { Character } from '../../data/dCharacter';
// FIX: Replaced `WorldSystem` with `WorldService` to align with the application's service-oriented architecture.
import { WorldService } from '../../services/WorldService';

export class LineOfSightCalculator {
    public static calculate(
        character: Character,
        worldSystem: WorldService,
        visionRadius: number = 10
    ): { lineOfSight: Set<string>; discovered: Set<string> } {
        const lineOfSight = new Set<string>();
        const discovered = new Set<string>();
        const { x: cx, y: cy, z: cz } = character;

        // The player's own tile is always visible and discovered
        const playerTileKey = `${cx},${cy}`;
        lineOfSight.add(playerTileKey);
        discovered.add(playerTileKey);

        for (let i = -visionRadius; i <= visionRadius; i++) {
            for (let j = -visionRadius; j <= visionRadius; j++) {
                if (i === 0 && j === 0) continue;
                if (i * i + j * j > visionRadius * visionRadius) continue;

                const targetX = cx + i;
                const targetY = cy + j;
                const line = this.getLine(cx, cy, targetX, targetY);

                for (const point of line) {
                    const tile = worldSystem.getTile(point.x, point.y, cz);
                    const tileKey = `${point.x},${point.y}`;
                    
                    lineOfSight.add(tileKey);
                    discovered.add(tileKey);

                    // Stop line of sight if it hits a blocking tile
                    if (tile && !tile.canMoveTo(character.data)) {
                        break;
                    }
                }
            }
        }
        return { lineOfSight, discovered };
    }

    private static getLine(x0: number, y0: number, x1: number, y1: number): { x: number; y: number }[] {
        const points: { x: number; y: number }[] = [];
        const dx = Math.abs(x1 - x0);
        const dy = Math.abs(y1 - y0);
        const sx = (x0 < x1) ? 1 : -1;
        const sy = (y0 < y1) ? 1 : -1;
        let err = dx - dy;

        while (true) {
            points.push({ x: x0, y: y0 });
            if ((x0 === x1) && (y0 === y1)) break;
            const e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
        return points;
    }
}