

// FIX: Replaced `PathfindingSystem` with `PathfindingService` to align with the application's service-oriented architecture.
import { PathfindingService } from '../../services/PathfindingService';
import { WorldSystem } from '../world/WorldSystem';
import { Position } from '../generation/character/Character.types';
import { PathfindingResult } from './MovementTypes';

export class Pathfinder {
  constructor(private pathfindingSystem: PathfindingService) {}

  public findPath(
    start: Position, 
    end: Position, 
    maxIterations: number = 1000
  ): PathfindingResult {
    try {
      const path = this.pathfindingSystem.findPath(start, end);
      
      if (!path || path.length <= 1) {
        return { path: [], success: false, reason: "No valid path found" };
      }

      if (path.length > maxIterations) {
        return { path: [], success: false, reason: "Path too long" };
      }

      return { path: path.map(p => ({...p, z: start.z})), success: true };
    } catch (error) {
      console.error("Pathfinding error:", error);
      return { path: [], success: false, reason: "Pathfinding error" };
    }
  }

  public isValidDestination(position: Position, worldSystem: WorldSystem): boolean {
    const tile = worldSystem.getTile(position.x, position.y, position.z);
    return !!tile?.canMoveTo({});
  }
}