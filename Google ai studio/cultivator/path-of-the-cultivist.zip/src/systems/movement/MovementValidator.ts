


// FIX: Replaced `WorldSystem` with `WorldService` to align with the application's service-oriented architecture.
import { WorldService, WORLD_DEPTH } from '../../services/WorldService';
import { dCreatureSystem } from '../../data/dCreatureSystem';
import { Position } from '../generation/character/Character.types';
import { MovementValidationResult } from './MovementTypes';
import { Character } from '../../data/dCharacter';
import { TileConfigRegistry } from '../tiles/TileConfigRegistry';
import { dSkillSystem } from '../../data/dSkillSystem';
import { SkillType } from '../../types/AdventureTypes';
import { SkillService } from '../../services/SkillService';

export class MovementValidator {
  constructor(
    private worldSystem: WorldService,
    private creatureSystem: dCreatureSystem,
    // FIX: Changed parameter type from dSkillSystem to SkillService to match application architecture.
    private skillSystem: SkillService,
  ) {}

  public validateMovement(
    currentPos: Position,
    targetPos: Position,
    characterData: any
  ): MovementValidationResult {
    if (!this.isWithinBounds(targetPos)) {
      return { success: false, blockedBy: 'terrain', reason: "Out of bounds" };
    }

    const creature = this.creatureSystem.getCreatureAt(targetPos.x, targetPos.y, targetPos.z);
    if (creature) {
      return { 
        success: false, 
        blockedBy: 'creature', 
        encounter: creature,
        reason: `Blocked by ${creature.name}`
      };
    }

    const tile = this.worldSystem.getTile(targetPos.x, targetPos.y, targetPos.z);
    if (!tile?.canMoveTo(characterData)) {
      return { success: false, blockedBy: 'tile', reason: "Tile not accessible" };
    }

    // Diagonal movement check
    const dx = targetPos.x - currentPos.x;
    const dy = targetPos.y - currentPos.y;
    if (Math.abs(dx) === 1 && Math.abs(dy) === 1) {
        const cardinalTileX = this.worldSystem.getTile(currentPos.x + dx, currentPos.y, currentPos.z);
        const cardinalTileY = this.worldSystem.getTile(currentPos.x, currentPos.y + dy, currentPos.z);
        if ((cardinalTileX && !cardinalTileX.canMoveTo(characterData)) || (cardinalTileY && !cardinalTileY.canMoveTo(characterData))) {
            return { success: false, blockedBy: 'tile', reason: "Cannot move diagonally past an obstacle." };
        }
    }

    return { success: true, blockedBy: 'none' };
  }

  public validateClimb(character: Character, dz: number): MovementValidationResult {
    const { x, y, z } = character;
    const currentTile = this.worldSystem.getTile(x, y, z);
    const currentConfig = TileConfigRegistry.get(currentTile?.type || '');
    
    if (!currentConfig?.properties?.climbable) {
      return { success: false, blockedBy: 'tile', reason: "You can't climb here. There is nothing to hold on to." };
    }

    const targetZ = z + dz;
    if (targetZ < 0 || targetZ >= WORLD_DEPTH) {
      return { success: false, blockedBy: 'terrain', reason: "You can't climb any further." };
    }
    
    const climbDifficulty = currentConfig.properties.climbDifficulty || 10;
    const skillCheck = this.skillSystem.performSkillCheck(SkillType.Climbing, climbDifficulty);
    
    if (!skillCheck.succeeded) {
        return { success: false, blockedBy: 'tile', reason: `Your climbing skill is not enough. (Needed ${climbDifficulty}, Rolled ${skillCheck.total})` };
    }

    const targetTile = this.worldSystem.getTile(x, y, targetZ);
    if (dz > 0 && targetTile && !targetTile.canMoveTo(character.data)) {
      return { success: false, blockedBy: 'tile', reason: "Something is blocking your path upwards." };
    }

    return { success: true, blockedBy: 'none' };
  }

  private isWithinBounds(position: Position): boolean {
    return position.z >= 0 && position.z < WORLD_DEPTH;
  }
}