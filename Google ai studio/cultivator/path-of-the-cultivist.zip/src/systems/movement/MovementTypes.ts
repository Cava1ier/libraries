
import { Position } from '../generation/character/Character.types';
import { CreatureData } from '../../types/AdventureTypes';
// FIX: Imported GameConfiguration to create a type alias, unifying the different movement config types.
import { GameConfiguration } from '../world/character/managers/ConfigurationManager';

// FIX: This type is now an alias, ensuring consistency across different parts of the application.
export type MovementConfig = GameConfiguration['movement'];

export interface PathfindingResult {
  path: Position[];
  success: boolean;
  reason?: string;
}

export interface MovementValidationResult {
  success: boolean;
  blockedBy: 'creature' | 'terrain' | 'tile' | 'none';
  encounter?: CreatureData;
  reason?: string;
}