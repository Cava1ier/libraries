export class AppComponentLoader {
    private static _styleRegistry: any = null;

    public static get styleRegistry(): any {
        if (!this._styleRegistry) {
            // Lazy initialization. This will be called when styleRegistry is first accessed,
            // which happens after the component mounts, ensuring the global script has loaded.
            if (typeof (window as any).StyleRegistry === 'undefined') {
                throw new Error("StyleRegistry is not defined on the window object. Ensure lib/StyleRegistry.js is loaded correctly.");
            }
            this._styleRegistry = new (window as any).StyleRegistry('cultivist');
        }
        return this._styleRegistry;
    }

    public static cls(prefix: string, className: string): string {
        return `cultivist-${prefix}-${className}`;
    }
}
