
import { RNGSystem } from '../../rng/RNGSystem';
import { GameDatabase } from '../../database/Database';
import { GeneratedCharacter } from '../../generation/character/Character.types';
import { Relationship, RelationshipType, RelationshipEvent } from '../../../types/SocialTypes';

export class RelationshipGenerator {
    constructor(private rng: RNGSystem, private db: GameDatabase) {}

    public generateRelationshipsForCharacter(character: GeneratedCharacter, existingCharacters: GeneratedCharacter[], maxRelationships: number = 3): Relationship[] {
        const relationships: Relationship[] = [];
        const candidates = this.findRelationshipCandidates(character, existingCharacters);

        for (let i = 0; i < Math.min(maxRelationships, candidates.length); i++) {
            const candidate = candidates[i];
            const relationshipType = this.determineRelationshipType(character, candidate);
            if (relationshipType) {
                const relationship = this.createRelationship(character, candidate, relationshipType);
                relationships.push(relationship);
            }
        }
        return relationships;
    }

    private findRelationshipCandidates(character: GeneratedCharacter, existingCharacters: GeneratedCharacter[]): GeneratedCharacter[] {
        return existingCharacters
            .filter(other => other.name !== character.name)
            .map(other => ({
                character: other,
                compatibility: this.calculateCompatibility(character, other)
            }))
            .sort((a, b) => b.compatibility - a.compatibility)
            .slice(0, 10)
            .map(item => item.character);
    }

    private calculateCompatibility(char1: GeneratedCharacter, char2: GeneratedCharacter): number {
        const oceanCompatibility = (Math.abs(char1.ocean_e - char2.ocean_e) < 30 ? 10 : 0) + ((char1.ocean_a + char2.ocean_a) / 4) - ((char1.ocean_n + char2.ocean_n) / 8);
        const distance = Math.sqrt(Math.pow(char1.x - char2.x, 2) + Math.pow(char1.y - char2.y, 2));
        const proximityBonus = Math.max(0, 50 - distance);
        const realmCompatibility = char1.realm === char2.realm ? 20 : 0;
        return oceanCompatibility + proximityBonus + realmCompatibility;
    }

    private determineRelationshipType(char1: GeneratedCharacter, char2: GeneratedCharacter): RelationshipType | null {
        const compatibility = this.calculateCompatibility(char1, char2);
        const random = this.rng.next() % 100;

        if (char1.ocean_a < 40 && char2.ocean_a < 40 && random < 30) return RelationshipType.RIVALRY;
        if (Math.abs(char1.cultivation_level - char2.cultivation_level) >= 2 && random < 20) return RelationshipType.MENTOR_STUDENT;
        if (compatibility > 60 && char1.ocean_a > 50 && char2.ocean_a > 50 && random < 40) return RelationshipType.FRIENDSHIP;
        // FIX: Replaced 'conflict_type' with 'conflict_strength' to match the GeneratedCharacter type.
        if (compatibility > 40 && char1.conflict_strength === char2.conflict_strength && random < 25) return RelationshipType.ALLIANCE;
        
        return null;
    }

    private createRelationship(char1: GeneratedCharacter, char2: GeneratedCharacter, type: RelationshipType): Relationship {
        const baseStrengths: Record<RelationshipType, number> = {
            [RelationshipType.FRIENDSHIP]: 50, [RelationshipType.RIVALRY]: -30,
            [RelationshipType.MENTOR_STUDENT]: 40, [RelationshipType.ALLIANCE]: 30,
            [RelationshipType.FAMILY]: 70, [RelationshipType.ROMANTIC]: 60,
            [RelationshipType.MASTER_SERVANT]: 20, [RelationshipType.ENEMY]: -70,
            [RelationshipType.BUSINESS]: 10, [RelationshipType.SECT_MEMBER]: 25,
        };
        const baseStrength = baseStrengths[type] || 0;
        const compatibility = this.calculateCompatibility(char1, char2);
        const finalStrength = Math.max(-100, Math.min(100, baseStrength + (compatibility - 50)));

        const history: RelationshipEvent[] = [{
            type: 'meeting', description: 'First met under unknown circumstances.',
            strengthChange: 0, timestamp: Date.now()
        }];

        return {
            id: `${char1.name}_${char2.name}_${type}`,
            sourceCharacterId: char1.name,
            targetCharacterId: char2.name,
            type,
            strength: finalStrength,
            history,
            tags: [],
            isActive: true,
            createdAt: Date.now(),
            lastInteraction: Date.now()
        };
    }
}